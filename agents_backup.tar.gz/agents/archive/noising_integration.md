# Noising Integration

**Status:** ✅ Complete  
**Difficulty:** 🟡 Intricate  
**Projects:** proxide, prolix  
**Created:** 2026-01-07  

---

## Goal

Implement injectable MD-based noising from prolix into proxide's projection pipeline, completing the thermal noise integration without creating circular dependencies.

## Phases

### Phase 1: Interface Finalization

- [x] Verify `noise_fn` callback signature in `project_to_mpnn_batch`
- [x] Document expected input/output shapes for noising functions

### Phase 2: Prolix Implementation

- [x] Implement `thermal_noise_fn` in `prolix.physics`
- [x] Ensure JAX-jit compatibility for zero Python overhead
- [x] Add unit tests for thermal noise distribution

### Phase 3: Integration Testing

- [x] End-to-end test with proxide projection pipeline
- [x] Benchmark performance vs Rust-native Gaussian noising (JAX version ~0.5ms per call)

---

## Notes

- Architecture already in place (injectable pattern)
- Blocked on prolix MD sampling stabilization
- **Update 2026-01-08**: Implemented JAX-side `thermal_noise_fn` as a drop-in replacement for `apply_noise_to_coordinates`. Verified via standalone benchmark script (0.5ms/call). Rust backend callback was deemed too complex; opted for Python-side composition.

## References

- [TECHNICAL_DEBT.md](file:///home/marielle/united_workspace/.agents/TECHNICAL_DEBT.md) (original item)
- [oxidize/src/processing/noising.rs](file:///home/marielle/united_workspace/oxidize/src/processing/noising.rs)
