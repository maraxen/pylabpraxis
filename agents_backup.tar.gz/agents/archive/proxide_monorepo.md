# Proxide Monorepo Refactoring

**Status:** ✅ Complete  
**Difficulty:** 🔴 Complex  
**Projects:** proxide, oxide (oxidize)  
**Created:** 2026-01-07  
**Completed:** 2026-01-08

---

## Goal

Merge the oxide (Rust backend) and proxide (Python wrapper) repositories into a unified monorepo structure, simplifying build processes, versioning, and enabling atomic commits for cross-language changes.

## Phases

### Phase 1: Planning

- [x] Document current repository structure and build processes
- [x] Design unified monorepo layout
- [x] Plan migration strategy (preserve git history if possible)

### Phase 2: Repository Merge

- [x] Create unified repository structure
- [x] Migrate Rust code (oxide → proxide/oxidize)
- [x] Update maturin build configuration
- [x] Consolidate CI/CD pipelines

### Phase 3: Validation

- [x] Verify build process works end-to-end
- [x] Update all dependent packages' references
- [x] Update documentation

---

## Notes

- This is a significant architectural change requiring careful planning
- Benefits: simplified build, easier versioning, atomic cross-language commits
- Consider impact on downstream dependencies (prolix, PrxteinMPNN)

## References

- [proxide](file:///home/marielle/united_workspace/proxide)
- [oxidize](file:///home/marielle/united_workspace/proxide/oxidize)
