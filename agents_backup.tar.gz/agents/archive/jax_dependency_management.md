# JAX Dependency Management

**Status:** ✅ Complete  
**Difficulty:** 🟢 Easy Win  
**Projects:** All  
**Created:** 2026-01-07  
**Updated:** 2026-01-08

---

## Goal

Make JAX accelerator backends (TPU/CUDA) environment-conditional rather than hardcoded in `pyproject.toml`, preventing installation issues across different hardware configurations.

## Phases

### Phase 1: Research

- [x] Document current JAX dependency declarations per repo
- [x] Research pip extra dependencies vs environment markers

### Phase 2: Implementation

- [x] Modify pyproject.toml to use optional extras or environment markers
- [x] Update installation docs with hardware-specific instructions
- [x] Test installation on CPU-only, CUDA, and TPU environments

---

## Notes

- Current issue: hardcoded `jax[tpu]` or `jax[cuda12]` breaks on incompatible hardware
- Consider using `pip install .[cuda]` or `pip install .[tpu]` pattern

## References

- [JAX installation docs](https://github.com/google/jax#installation)
