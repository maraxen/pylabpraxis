# Pre-commit Hooks Configuration

**Status:** ✅ Complete
**Difficulty:** 🟢 Easy Win  
**Projects:** All  
**Created:** 2026-01-07  

---

## Goal

Define and standardize pre-commit hooks for all repositories to ensure consistent code quality enforcement.

## Standard Hooks

- `trailing-whitespace`
- `end-of-file-fixer`
- `check-yaml`
- `check-added-large-files`

## Project-Specific Hooks

- `ruff` (linting and formatting)
- `ty` (type checking) where applicable

## Phases

### Phase 1: Template Creation

- [x] Create standard .pre-commit-config.yaml template
- [x] Document hook configuration in codestyles/

### Phase 2: Per-Repo Rollout

- [x] PrxteinMPNN pre-commit setup
- [x] proxide pre-commit setup
- [x] prolix pre-commit setup
- [x] trex pre-commit setup
- [x] proteinsmc pre-commit setup
- [x] projects/asr pre-commit setup

---

## Notes

- Coordinate with per-repo health audits
- Ensure hooks don't conflict with existing CI checks

## References

- [pre-commit.com](https://pre-commit.com/)
