# Configurable DType Precision

**Status:** ✅ Complete
**Difficulty:** 🟡 Intricate
**Projects:** projects/asr, trex
**Created:** 2026-01-07
**Updated:** 2026-01-08

---

## Goal

Enable global and per-operation `dtype` configuration across `projects/asr` and `trex` to support various hardware environments (CPUs, GPUs, TPUs) and precision requirements (float32, bfloat16, float64).

## Tasks

- [x] **Type Definition Audit**: Identify all locations where `float32` or `bfloat16` are hard-coded in JAX array creation and type annotations.
- [x] **Centralized Configuration**: Implement a configuration mechanism (e.g., in `asr.types` and `trex.types`) to define the default floating-point type.
- [x] **Refactor Array Creation**: Replace `jnp.float32` etc. with the configured type in functions like `jnp.zeros`, `jnp.ones`, `jax.random.normal`.
- [x] **Update Type Annotations**: Ensure `jaxtyping` annotations use the correct generic types or are updated to reflect configurable precision.
- [x] **Validation**: Verify that the codebase remains stable and performs as expected with both `float32` and `bfloat16`.

---

## References

- [.agents/TECHNICAL_DEBT.md](/.agents/TECHNICAL_DEBT.md)
- [projects/asr/src/asr/types.py](/projects/asr/src/asr/types.py)
