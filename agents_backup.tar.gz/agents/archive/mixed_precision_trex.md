# Mixed Precision for TREX

**Status:** ✅ Complete  
**Difficulty:** 🟡 Intricate  
**Projects:** trex, projects/asr  
**Created:** 2026-01-07  

---

## Goal

Implement proper mixed-precision training to improve performance while maintaining optimizer convergence. Keep optimizer state in float32 while using bfloat16 for forward pass computation.

## Phases

### Phase 1: Research & Design

- [x] Review optax mixed-precision utilities
- [x] Design precision wrapper for Adam state
- [x] Document precision casting points in forward pass

### Phase 2: Implementation

- [x] Implement precision wrapper for optimizer state (float32)
- [x] Add bfloat16 casting for forward pass only
- [x] Modify `nk_sweep.py:get_compute_dtype()` to use mixed precision

### Phase 3: Validation

- [x] Compare convergence: pure float32 vs mixed precision
- [x] Benchmark memory usage improvement
- [x] Verify Hamming error remains at ~0.04 level

---

## Notes

- Current workaround: always use float32 (works but suboptimal memory usage)
- bfloat16 alone causes convergence failure (0.69 vs 0.04 Hamming error)
- Root cause: Adam accumulators lose precision with 7-bit mantissa

## References

- [projects/asr/docs/NOTES.md](file:///home/marielle/united_workspace/projects/asr/docs/NOTES.md)
