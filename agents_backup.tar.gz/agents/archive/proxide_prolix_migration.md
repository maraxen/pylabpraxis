# Proxide/Prolix Code Migration

**Status:** ✅ Complete
**Difficulty:** 🟡 Intricate
**Projects:** prxteinmpnn, proxide, prolix
**Created:** 2026-01-07

---

## Goal

Remove duplicated code from PrxteinMPNN by migrating to proxide and prolix as dependencies. This consolidates parsing and physics code into their canonical locations and reduces maintenance burden.

## Phases

### Phase 1: Proxide Migration

Migrate parsing and force field code from PrxteinMPNN to proxide:

- [x] Add proxide to prxteinmpnn dependencies
- [x] Update imports in `io/parsing/dispatch.py`
- [x] Migrate `physics/force_fields.py` usage
- [x] Migrate `utils/residue_constants.py` usage
- [x] Delete deprecated modules from prxteinmpnn

**Files to migrate:**

- `prxteinmpnn/src/prxteinmpnn/io/parsing/` (most files)
- `prxteinmpnn/src/prxteinmpnn/physics/force_fields.py`
- `prxteinmpnn/src/prxteinmpnn/utils/residue_constants.py`

### Phase 2: Prolix Migration

Migrate physics calculations from PrxteinMPNN to prolix:

- [x] Add prolix to prxteinmpnn dependencies
- [x] Update imports in `physics/features.py`
- [x] Migrate electrostatics calculations
- [x] Migrate vdW calculations
- [x] Remove jax_md dependency from prxteinmpnn
- [x] Update all affected tests

**Files to migrate:**

- `prxteinmpnn/src/prxteinmpnn/physics/electrostatics.py`
- `prxteinmpnn/src/prxteinmpnn/physics/vdw.py`
- `prxteinmpnn/src/prxteinmpnn/physics/constants.py`

### Phase 3: Cleanup

- [x] Verify all tests pass
- [x] Update documentation
- [x] Archive migration notes

---

## Notes

- `prxteinmpnn/physics/features.py` (PrxteinMPNN-specific node features) stays in PrxteinMPNN
- This work requires proxide to be stable (Rust migration complete ✅)
- Consider submodule development workflow for cross-repo changes

## References

- [prxteinmpnn TECHNICAL_DEBT.md](../projects/prxteinmpnn/TECHNICAL_DEBT.md) - Item #7
- [TRAINING_MERGE.md](../projects/prxteinmpnn/archive/TRAINING_MERGE.md) - Sections 12-16
