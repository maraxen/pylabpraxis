# Agent Prompt: 02_jax_dependency_management

Examine .agents/README.md for development context.

**Status:** ✅ Complete  
**Batch:** [260108](README.md)  
**Backlog:** [jax_dependency_management.md](../../backlog/jax_dependency_management.md)  

---

## Task

Make JAX accelerator backends (TPU/CUDA) environment-conditional in `pyproject.toml` files across all repositories, preventing installation issues across different hardware configurations.

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [jax_dependency_management.md](../../backlog/jax_dependency_management.md) | Work item tracking |
| [codestyles/jax.md](../../codestyles/jax.md) | JAX-specific conventions |

---

## Implementation Steps

### Phase 1: Research

1. Document current JAX dependency declarations in each repo's `pyproject.toml`
2. **Environment Inference Research**:
   - Investigate if `uv` environment markers or alternative indexes can be used for automatic backend detection (CPU vs CUDA).
   - Reference: [uv documentation on indexes](https://docs.astral.sh/uv/configuration/indexes/) and [resolution strategy](https://docs.astral.sh/uv/concepts/resolution/).
3. Review [JAX installation docs](https://github.com/google/jax#installation) for pip extras patterns.

### Phase 2: Implementation

1. **Root Synchronization**:
   - Define a central JAX version and preferred backend constraints in the root `united_workspace/pyproject.toml`.
   - Consider using `tool.uv.overrides` or adding JAX to the root `project.dependencies` to ensure all workspace members stay in sync with the CUDA version if that is the workspace standard.

2. Modify `pyproject.toml` in each repository to use optional extras:

   ```toml
   [project.optional-dependencies]
   cuda = ["jax[cuda12]"]
   tpu = ["jax[tpu]"]
   cpu = ["jax"]
   ```

3. Update base dependencies to just `jax` (CPU-only)

4. Update installation docs (README.md) with hardware-specific instructions:
   - CPU: `pip install .`
   - CUDA: `pip install .[cuda]`
   - TPU: `pip install .[tpu]`

### Phase 3: Verification

1. Test installation on available environments

---

## Project Conventions

- **Commands**: Use `uv run` for all Python commands
- **Execute from workspace root**

See [codestyles/](../../codestyles/) for language-specific guidelines.

---

## On Completion

- [ ] Update backlog item status in [jax_dependency_management.md](../../backlog/jax_dependency_management.md)
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md)
- [ ] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [JAX Installation](https://github.com/google/jax#installation) - Official docs
