# Agent Prompt: 01_jax_recompilation_phases_2_3

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started  
**Batch:** [260108](README.md)  
**Backlog:** [jax_recompilation_audit.md](../../backlog/jax_recompilation_audit.md)  

---

## Task

Complete Phases 2-3 of the JAX Recompilation Audit: design padding strategies and implement them across repositories.

### Phase 2: Design Padding Strategies

1. **Design padding utilities** for variable-length inputs based on the existing `projects/asr/src/asr/oed/padding.py` reference implementation
2. **Implement mask propagation** for padded computations—ensure masks flow through JAX operations correctly
3. **Validate memory tradeoffs** vs compilation overhead (document findings)

### Phase 3: Per-Repo Implementation

Implement padding strategies in each repository, prioritizing by recompilation hotspot severity:

1. **trex**: Focus on `nk_model.py` and `tree.py` hotspots
2. **proxide**: Address any identified dynamic shapes
3. **prolix**: MD simulation padding where applicable
4. **PrxteinMPNN**: Sequence/batch padding
5. **proteinsmc**: SMC-specific padding

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [jax_recompilation_audit.md](../../backlog/jax_recompilation_audit.md) | Backlog tracking |
| [padding.py](file:///home/marielle/united_workspace/projects/asr/src/asr/oed/padding.py) | Reference padding implementation |
| [codestyles/jax.md](../../codestyles/jax.md) | Static shape guidelines |
| Per-repo hotspots | `.agents/projects/{repo}/RECOMPILATION_HOTSPOTS.md` |

---

## Project Conventions

- **Commands**: Use `uv run` for all Python commands
- **Linting**: `uv run ruff check src/ --fix`
- **Testing**: `uv run pytest tests/ -v`
- **Type Check**: `uv run ty check`

See [codestyles/jax.md](../../codestyles/jax.md) for JAX-specific patterns, especially:

- Static shapes with `static_argnums`
- Padding strategies for variable-length inputs
- Avoiding recompilation triggers

---

## On Completion

- [ ] Update backlog item status (mark Phase 2/3 tasks complete)
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md) if all phases complete
- [ ] Release GPU in [status.json](../../status.json) if used
- [ ] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [projects/trex/](../../projects/trex/) - Primary target repository
- [JAX JIT documentation](https://jax.readthedocs.io/en/latest/jax-101/02-jitting.html)
