# Agent Prompt: 02_proxide_monorepo_refactoring

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started  
**Batch:** [260108](README.md)  
**Backlog:** [proxide_monorepo.md](../../backlog/proxide_monorepo.md)  

---

## Task

Plan and execute the merge of oxide (Rust backend) and proxide (Python wrapper) repositories into a unified monorepo.

### Phase 1: Planning

1. **Document current structure**: Catalog both repositories' directory layouts, build processes, and CI configurations
2. **Design unified layout**: Propose a monorepo structure (e.g., `proxide/rust/` for Rust code, `proxide/python/` for Python, or similar)
3. **Plan migration**: Determine git history preservation strategy (subtree merge, manual copy, etc.)

### Phase 2: Repository Merge

1. **Create unified structure**: Set up the new directory layout
2. **Migrate Rust code**: Move oxide into the proxide repo structure
3. **Update maturin config**: Ensure `pyproject.toml` and `Cargo.toml` work in the new layout
4. **Consolidate CI/CD**: Merge GitHub Actions workflows

### Phase 3: Validation

1. **Verify builds**: Ensure `maturin develop` and `maturin build` work
2. **Update dependents**: Update proxide references in prolix, PrxteinMPNN
3. **Update documentation**: Revise READMEs and installation instructions

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [proxide_monorepo.md](../../backlog/proxide_monorepo.md) | Backlog tracking |
| [proxide/](file:///home/marielle/united_workspace/proxide) | Python wrapper repository |
| [oxidize/](file:///home/marielle/united_workspace/oxidize) | Rust backend repository |
| [proxide/pyproject.toml](file:///home/marielle/united_workspace/proxide/pyproject.toml) | Python build config |
| [oxidize/Cargo.toml](file:///home/marielle/united_workspace/oxidize/Cargo.toml) | Rust build config |

---

## Project Conventions

- **Rust**: Follow [codestyles/rust.md](../../codestyles/rust.md)
- **Python**: Use `uv run` for all Python commands
- **Maturin**: Use `maturin develop` for local development builds

> [!CAUTION]
> This is a significant architectural change. Create a detailed plan document before executing any repository modifications. Consider creating a new branch for the merge work.

---

## On Completion

- [ ] Update backlog item status
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md)
- [ ] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [projects/proxide/](../../projects/proxide/) - Proxide project docs
- [maturin documentation](https://www.maturin.rs/)
