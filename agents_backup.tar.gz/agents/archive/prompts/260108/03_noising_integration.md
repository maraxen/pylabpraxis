# Agent Prompt: 03_noising_integration

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started  
**Batch:** [260108](README.md)  
**Backlog:** [noising_integration.md](../../backlog/noising_integration.md)  

---

## Task

Implement injectable MD-based noising from prolix into proxide's projection pipeline, completing the thermal noise integration.

### Phase 1: Interface Finalization

1. **Verify `noise_fn` callback signature** in `project_to_mpnn_batch` (proxide)
2. **Document expected I/O shapes** for noising functions

### Phase 2: Prolix Implementation

1. **Implement `thermal_noise_fn`** in `prolix.physics`:
   - Accept atomic coordinates and temperature
   - Return noised coordinates following Boltzmann distribution
   - Ensure JAX-jit compatibility (zero Python overhead)
2. **Add unit tests** for thermal noise distribution properties

### Phase 3: Integration Testing

1. **End-to-end test**: Wire noising into proxide projection and validate
2. **Benchmark**: Compare performance vs Rust-native Gaussian noising in oxidize

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [noising_integration.md](../../backlog/noising_integration.md) | Backlog tracking |
| [oxidize/src/processing/noising.rs](file:///home/marielle/united_workspace/oxidize/src/processing/noising.rs) | Reference Rust noising |
| [proxide projection pipeline](file:///home/marielle/united_workspace/proxide/src/proxide/) | Target integration point |
| [prolix physics](file:///home/marielle/united_workspace/prolix/src/prolix/physics/) | Target implementation location |

---

## Project Conventions

- **Commands**: Use `uv run` for all Python commands
- **Linting**: `uv run ruff check src/ --fix`
- **Testing**: `uv run pytest tests/ -v`
- **Type Check**: `uv run ty check`

See [codestyles/jax.md](../../codestyles/jax.md) for JAX-specific guidelines.

> [!NOTE]
> This item was noted as "partially blocked on prolix MD sampling stabilization." Check the current state of prolix before proceeding with Phase 2.

---

## On Completion

- [ ] Update backlog item status
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md)
- [ ] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [projects/prolix/](../../projects/prolix/) - Prolix project docs
- [projects/proxide/](../../projects/proxide/) - Proxide project docs
