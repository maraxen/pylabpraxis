# Agent Prompt: 04_codestyle_audit

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started  
**Batch:** [260108](README.md)  
**Backlog:** [codestyle_audit.md](../../backlog/codestyle_audit.md)  

---

## Task

Audit and optimize the code style documents in `.agents/codestyles/` to ensure they focus on what linters don't catch (JAX idioms, architectural patterns) and remove redundancy with Ruff/rustfmt rules.

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [codestyle_audit.md](../../backlog/codestyle_audit.md) | Work item tracking |
| [codestyles/python.md](../../codestyles/python.md) | Python conventions |
| [codestyles/jax.md](../../codestyles/jax.md) | JAX-specific conventions |
| [codestyles/rust.md](../../codestyles/rust.md) | Rust/PyO3 conventions |
| [codestyles/general.md](../../codestyles/general.md) | Cross-language practices |

---

## Implementation Steps

### Phase 1: Research

1. Review each codestyle document for content
2. Identify rules that Ruff already enforces (remove redundancy)
3. Research additional best practices:
   - JAX: vmap patterns, recompilation triggers, pytree best practices
   - Rust/PyO3: memory safety patterns, error handling
   - Python: patterns beyond PEP8

### Phase 2: Audit & Consolidate

1. For each file, ensure focus on:
   - **Things linters don't catch**
   - JAX-specific idioms and recompilation triggers
   - Architectural patterns (PyTree structures, state management)
   - Cross-package integration patterns

2. Remove or condense any rules that duplicate linter behavior

3. Add missing guidance discovered during research

### Phase 3: Documentation

1. Ensure each file has clear examples (not just rules)
2. Cross-reference between files where appropriate

---

## Project Conventions

- **Commands**: Use `uv run` for all Python commands

See [codestyles/](../../codestyles/) for the files being audited.

---

## On Completion

- [ ] Update backlog item status in [codestyle_audit.md](../../backlog/codestyle_audit.md)
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md)
- [ ] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [Ruff Rules](https://docs.astral.sh/ruff/rules/) - What Ruff already checks
- [JAX FAQ](https://jax.readthedocs.io/en/latest/faq.html) - Common JAX patterns
