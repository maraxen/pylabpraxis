# Agent Prompt: 03_docstring_standardization

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started  
**Batch:** [260108](README.md)  
**Backlog:** [docstring_standardization.md](../../backlog/docstring_standardization.md)  

---

## Task

Create a comprehensive docstring template with examples and add it to `codestyles/python.md`. This establishes the standard for all future docstring updates across repositories.

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [docstring_standardization.md](../../backlog/docstring_standardization.md) | Work item tracking |
| [codestyles/python.md](../../codestyles/python.md) | Add template here |
| [.agents/README.md](../../README.md) | Documentation Standards section |
| [projects/asr/src/asr/types.py](file:///home/marielle/united_workspace/projects/asr/src/asr/types.py) | Example of current style |

---

## Standard Format

```python
def example_function(x: Float[Array, "batch seq"], k: int) -> Float[Array, "batch"]:
    """Compute the mean along the sequence dimension.

    Process:
        1. Sum elements along axis 1: (batch, seq) → (batch,)
        2. Divide by sequence length to get mean

    $$\\text{mean} = \\frac{1}{N} \\sum_{i=1}^{N} x_i$$

    NOTES:
        This function handles edge cases where seq=0 by returning zeros.
        Moved from inline comment for clarity.

    Args:
        x: Input array of shape (batch, seq).
        k: Number of top elements to consider (unused in this example).

    Returns:
        Mean values of shape (batch,).

    Example:
        >>> result = example_function(jnp.ones((4, 10)), k=5)
        >>> result.shape
        (4,)
    """
```

---

## Implementation Steps

### Phase 1: Template & Guidelines

1. Create complete docstring template with all sections
2. Add to `codestyles/python.md` under a "Docstring Format" heading
3. Include examples for:
   - Mathematical functions (with MathJax)
   - I/O functions
   - Simple utility functions

---

## Project Conventions

- **Commands**: Use `uv run` for all Python commands
- **Linting**: `uv run ruff check src/ --fix`

See [codestyles/](../../codestyles/) for language-specific guidelines.

---

## On Completion

- [ ] Update backlog item status in [docstring_standardization.md](../../backlog/docstring_standardization.md)
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md) (mark Phase 1 complete)
- [ ] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Documentation Standards section
- [Google Python Style Guide](https://google.github.io/styleguide/pyguide.html#38-comments-and-docstrings)
