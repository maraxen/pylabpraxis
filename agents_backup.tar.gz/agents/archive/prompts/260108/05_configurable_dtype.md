# Agent Prompt: 05_configurable_dtype

Examine .agents/README.md for development context.

**Status:** ✅ Complete  
**Batch:** [260108](README.md)  
**Backlog:** [configurable_dtype.md](../../backlog/configurable_dtype.md)  

---

## Task

Enable global `dtype` configuration across `projects/asr` and `trex` to support various hardware environments (float32, bfloat16, float64). Replace hardcoded dtype references with a centralized configuration.

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [configurable_dtype.md](../../backlog/configurable_dtype.md) | Work item tracking |
| [projects/asr/src/asr/types.py](file:///home/marielle/united_workspace/projects/asr/src/asr/types.py) | Existing type definitions |
| [codestyles/jax.md](../../codestyles/jax.md) | JAX conventions |
| [projects/asr/docs/NOTES.md](file:///home/marielle/united_workspace/projects/asr/docs/NOTES.md) | bfloat16 convergence notes |

---

## Implementation Steps

### Phase 1: Type Definition Audit

1. Search for hardcoded dtype references:

   ```bash
   grep -r "float32\|bfloat16\|float64" projects/asr/src/ trex/src/
   ```

2. Document all locations requiring updates

### Phase 2: Centralized Configuration

1. Implement in `projects/asr/src/asr/types.py`:

   ```python
   from typing import Literal
   import jax.numpy as jnp

   DTypeStr = Literal["float32", "bfloat16", "float64"]

   # Default configuration (can be overridden at runtime)
   _DEFAULT_DTYPE: DTypeStr = "float32"

   def get_default_dtype() -> jnp.dtype:
       """Return the configured default floating-point dtype."""
       return jnp.dtype(_DEFAULT_DTYPE)

   def set_default_dtype(dtype: DTypeStr) -> None:
       """Set the default floating-point dtype."""
       global _DEFAULT_DTYPE
       _DEFAULT_DTYPE = dtype
   ```

2. Similarly update `trex/src/trex/types.py` (or create if needed)

### Phase 3: Refactor Array Creation

1. Replace explicit dtype references:

   ```python
   # Before
   jnp.zeros((n, m), dtype=jnp.float32)
   
   # After
   from asr.types import get_default_dtype
   jnp.zeros((n, m), dtype=get_default_dtype())
   ```

2. Update random number generation similarly

### Phase 4: Validation

1. Run existing tests with both float32 and bfloat16
2. Verify NK sweep Hamming error remains ~0.04 with float32
3. Document any dtype-dependent behavior

---

## Project Conventions

- **Commands**: Use `uv run` for all Python commands
- **Testing**: `uv run pytest tests/ -v`
- **Type Check**: `uv run ty check`

See [codestyles/jax.md](../../codestyles/jax.md) for JAX guidelines.

---

## On Completion

- [x] Update backlog item status in [configurable_dtype.md](../../backlog/configurable_dtype.md)
- [x] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md)
- [x] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [projects/asr/README.md](../../projects/asr/README.md) - ASR project guidelines
- [trex/README.md](../../projects/trex/README.md) - TREX project guidelines
