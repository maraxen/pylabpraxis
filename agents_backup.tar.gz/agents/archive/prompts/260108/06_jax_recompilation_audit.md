# Agent Prompt: 06_jax_recompilation_audit

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started  
**Batch:** [260108](README.md)  
**Backlog:** [jax_recompilation_audit.md](../../backlog/jax_recompilation_audit.md)  

---

## Task

Audit all codebases for JAX recompilation issues caused by dynamic shapes. Document hotspots and design padding/masking strategies to maintain static shapes. This is Phase 1 (Audit) of a larger effort.

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [jax_recompilation_audit.md](../../backlog/jax_recompilation_audit.md) | Work item tracking |
| [codestyles/jax.md](../../codestyles/jax.md) | JAX static shape guidelines |
| [projects/asr/src/asr/oed/utils.py](file:///home/marielle/united_workspace/projects/asr/src/asr/oed/utils.py) | Existing padding utilities (`pad_to_length`, `create_mask`) |

---

## Implementation Steps

### Phase 1: Audit (Primary Focus)

1. **Identify dynamic shape patterns** in each repository:

   ```bash
   # Look for common dynamic shape patterns
   grep -rn "\.shape\[" prxteinmpnn/src/ proxide/src/ prolix/src/ trex/src/
   grep -rn "jnp.where\|jnp.select" prxteinmpnn/src/ proxide/src/ prolix/src/ trex/src/
   ```

2. **Profile recompilation frequency**:
   - Add `JAX_LOG_COMPILES=1` to detect recompilations during test runs
   - Document which functions trigger frequent recompiles

3. **Document shape-changing hotspots** per repository:
   - Create `.agents/projects/{repo}/RECOMPILATION_HOTSPOTS.md` for each repo
   - List functions, their dynamic shape causes, and severity

### Phase 2: Design (Recommendations)

1. **Design padding strategies** based on existing patterns:
   - Reference `projects/asr/src/asr/oed/utils.py` for working examples
   - Document recommended padding utilities per repo

2. **Document mask propagation patterns**:
   - How to handle padded values in computations
   - Best practices for avoiding padding-related bugs

---

## Repositories to Audit

| Repo | Priority | Notes |
|:-----|:---------|:------|
| trex | High | Core ASR functionality, known issues |
| projects/asr | High | Active development, has working patterns |
| proteinsmc | Medium | SMC sampling may have dynamic shapes |
| prxteinmpnn | Medium | Variable-length sequences |
| prolix | Low | Physics calculations likely static |
| proxide | Low | I/O layer, less JAX-intensive |

---

## Project Conventions

- **Commands**: Use `uv run` for all Python commands
- **Profiling**: `JAX_LOG_COMPILES=1 uv run pytest tests/ -v`
- **Execute from workspace root**

See [codestyles/jax.md](../../codestyles/jax.md) for static shape guidelines.

---

## On Completion

- [ ] Update backlog item status in [jax_recompilation_audit.md](../../backlog/jax_recompilation_audit.md)
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md)
- [ ] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [JAX FAQ: JIT Compilation](https://jax.readthedocs.io/en/latest/faq.html#how-do-i-control-jit-compilation) - Recompilation docs
- [codestyles/jax.md](../../codestyles/jax.md) - Project JAX conventions
