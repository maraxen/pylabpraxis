# Agent Prompt: 01_precommit_hooks

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started  
**Batch:** [260108](README.md)  
**Backlog:** [precommit_hooks.md](../../backlog/precommit_hooks.md)  

---

## Task

Configure pre-commit hooks across all repositories to ensure consistent code quality enforcement. Create a standard `.pre-commit-config.yaml` template and roll it out to all projects.

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [precommit_hooks.md](../../backlog/precommit_hooks.md) | Work item tracking |
| [codestyles/python.md](../../codestyles/python.md) | Python style conventions |
| [codestyles/general.md](../../codestyles/general.md) | General conventions |

---

## Implementation Steps

### Phase 1: Template Creation

1. Create `.agents/templates/.pre-commit-config.yaml.template` with:
   - Standard hooks: `trailing-whitespace`, `end-of-file-fixer`, `check-yaml`, `check-added-large-files`
   - `ruff` for linting/formatting
   - `ty` for type checking (optional, per-project)

2. Document hook configuration in `codestyles/python.md`

### Phase 2: Per-Repo Rollout

1. Create `.pre-commit-config.yaml` in each repository:
   - `prxteinmpnn/`
   - `proxide/`
   - `prolix/`
   - `trex/`
   - `projects/proteinsmc/` (if applicable)

2. Test hooks work correctly: `pre-commit run --all-files`

---

## Project Conventions

- **Commands**: Use `uv run` for all Python commands
- **Linting**: `uv run ruff check src/ --fix`
- **Type Check**: `uv run ty check`

See [codestyles/](../../codestyles/) for language-specific guidelines.

---

## On Completion

- [ ] Update backlog item status in [precommit_hooks.md](../../backlog/precommit_hooks.md)
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md)
- [ ] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [pre-commit.com](https://pre-commit.com/) - Documentation
