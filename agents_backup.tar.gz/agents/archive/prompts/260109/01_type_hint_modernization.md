# Agent Prompt: 01_type_hint_modernization

Examine .agents/README.md for development context.

**Status:** ✅ Complete  
**Batch:** [260109](../260109/README.md)  
**Backlog:** [type_hint_modernization.md](../../backlog/type_hint_modernization.md)  

---

## Task

Replace generic `jnp.ndarray` or `jax.Array` type hints with precise `jaxtyping` annotations across all repositories, improving code documentation and enabling static shape checking.

### Phase 1: Audit & Define Types

1. **Scan all repos** for generic array type hints (`jnp.ndarray`, `jax.Array`, `Array`)
2. **Create/update `types.py`** in each repository with common shape definitions:
   - `Scalar = Int[Array, ""]`
   - `ScalarFloat = Float[Array, ""]`
   - Other common shapes as needed (e.g., `BatchedArray`, `SequenceArray`)
3. **Document files** requiring updates per repository

### Phase 2: Per-Repo Implementation

Replace generic hints with jaxtyping annotations in:

- [x] PrxteinMPNN
- [x] proxide
- [x] prolix
- [x] trex
- [x] proteinsmc

**Reference implementation**: See `projects/asr/src/asr/types.py` for established patterns.

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [type_hint_modernization.md](../../backlog/type_hint_modernization.md) | Work item tracking |
| [projects/asr/src/asr/types.py](file:///home/marielle/united_workspace/projects/asr/src/asr/types.py) | Reference implementation |
| [codestyles/python.md](../../codestyles/python.md) | Python conventions |

---

## Project Conventions

- **Commands**: Use `uv run` from workspace root for all Python commands
- **Linting**: `uv run ruff check {repo}/src/ --fix`
- **Testing**: `uv run pytest {repo}/tests/ -v`
- **Type Check**: `uv run ty check`

See [codestyles/](../../codestyles/) for language-specific guidelines.

---

## Verification

1. Run `uv run ruff check` on each modified repo
2. Run `uv run ty check` on each modified repo
3. Run `uv run pytest` on each modified repo to ensure no regressions

---

## On Completion

- [x] Update backlog item status
- [x] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md)
- [x] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [jaxtyping documentation](https://docs.kidger.site/jaxtyping/)
