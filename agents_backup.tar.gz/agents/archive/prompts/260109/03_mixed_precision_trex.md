# Agent Prompt: 03_mixed_precision_trex

Examine .agents/README.md for development context.

**Status:** ✅ Complete  
**Batch:** [260109](../260109/README.md)  
**Backlog:** [mixed_precision_trex.md](../../backlog/mixed_precision_trex.md)  

---

## Task

Implement proper mixed-precision training for TREX to improve memory efficiency while maintaining optimizer convergence. Keep optimizer state in float32 while using bfloat16 for forward pass computation.

### Background

- **Current issue**: Pure bfloat16 causes convergence failure (0.69 vs 0.04 Hamming error)
- **Root cause**: Adam accumulators lose precision with bfloat16's 7-bit mantissa
- **Solution**: Mixed precision - float32 for optimizer state, bfloat16 for forward pass only

### Phase 1: Research & Design

1. Review optax mixed-precision utilities (`optax.mixed_precision`) [x]
2. Design precision wrapper for Adam state (keep in float32) [x]
3. Document precision casting points in forward pass [x]

### Phase 2: Implementation

1. Implement precision wrapper for optimizer state [x]
2. Add bfloat16 casting for forward pass only [x]
3. Modify `nk_sweep.py:get_compute_dtype()` to use mixed precision pattern [x]
4. Ensure loss computation maintains float32 for numerical stability [x]

### Phase 3: Validation

1. Compare convergence: pure float32 vs mixed precision [x]
2. Benchmark memory usage improvement [x]
3. Verify Hamming error remains at ~0.04 level (not 0.69) [x]

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [mixed_precision_trex.md](../../backlog/mixed_precision_trex.md) | Work item tracking |
| [projects/asr/scripts/nk_sweep.py](file:///home/marielle/united_workspace/projects/asr/scripts/nk_sweep.py) | Sweep script to modify |
| [trex/src/trex/nk_model.py](file:///home/marielle/united_workspace/trex/src/trex/nk_model.py) | Core model |
| [projects/asr/docs/NOTES.md](file:///home/marielle/united_workspace/projects/asr/docs/NOTES.md) | Background on issue |
| [codestyles/jax.md](../../codestyles/jax.md) | JAX best practices |

---

## Project Conventions

- **Commands**: Use `uv run` from workspace root for all Python commands
- **Testing**: `uv run pytest trex/tests/ -v` and `uv run pytest projects/asr/tests/ -v`
- **Sweep command**: `uv run python projects/asr/scripts/nk_sweep.py --help`

See [codestyles/jax.md](../../codestyles/jax.md) for JAX-specific guidelines.

---

## Verification

1. Run NK sweep with mixed precision:

   ```bash
   uv run python projects/asr/scripts/nk_sweep.py --n-vals 50 --k-vals 2 --mutation-rate 0.01 --use-mixed-precision
   ```

2. Compare Hamming error: should be ~0.04 (not 0.69)
3. Verify memory usage is reduced vs pure float32

---

## On Completion

- [x] Update backlog item status
- [x] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md)
- [x] Add notes to [NOTES.md](file:///home/marielle/united_workspace/.agents/NOTES.md) if new patterns discovered
- [x] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [optax mixed precision docs](https://optax.readthedocs.io/en/latest/api/transformations.html#optax.mixed_precision)
- [projects/trex/README.md](../../projects/trex/README.md) - Project guidelines
