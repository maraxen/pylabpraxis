# Agent Prompt: 02_proxide_prolix_migration

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started  
**Batch:** [260109](../260109/README.md)  
**Backlog:** [proxide_prolix_migration.md](../../backlog/proxide_prolix_migration.md)  

---

## Task

Remove duplicated code from PrxteinMPNN by migrating to proxide and prolix as dependencies. This consolidates parsing and physics code into their canonical locations.

### Phase 1: Proxide Migration

Migrate parsing and force field code from PrxteinMPNN to proxide:

1. Add `proxide` to prxteinmpnn dependencies in `pyproject.toml`
2. Update imports in `io/parsing/dispatch.py` to use proxide parsers
3. Migrate `physics/force_fields.py` usage to proxide
4. Migrate `utils/residue_constants.py` usage to proxide
5. Delete deprecated modules from prxteinmpnn

**Files to migrate from PrxteinMPNN:**

- `prxteinmpnn/src/prxteinmpnn/io/parsing/` (most files)
- `prxteinmpnn/src/prxteinmpnn/physics/force_fields.py`
- `prxteinmpnn/src/prxteinmpnn/utils/residue_constants.py`

### Phase 2: Prolix Migration

Migrate physics calculations from PrxteinMPNN to prolix:

1. Add `prolix` to prxteinmpnn dependencies
2. Update imports in `physics/features.py`
3. Migrate electrostatics calculations
4. Migrate vdW calculations
5. Remove jax_md dependency from prxteinmpnn if no longer needed
6. Update all affected tests

**Files to migrate:**

- `prxteinmpnn/src/prxteinmpnn/physics/electrostatics.py`
- `prxteinmpnn/src/prxteinmpnn/physics/vdw.py`
- `prxteinmpnn/src/prxteinmpnn/physics/constants.py`

> [!IMPORTANT]
> `prxteinmpnn/physics/features.py` (PrxteinMPNN-specific node features) stays in PrxteinMPNN

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [proxide_prolix_migration.md](../../backlog/proxide_prolix_migration.md) | Work item tracking |
| [prxteinmpnn/pyproject.toml](file:///home/marielle/united_workspace/PrxteinMPNN/pyproject.toml) | Dependencies to update |
| [projects/prxteinmpnn/TECHNICAL_DEBT.md](../../projects/prxteinmpnn/TECHNICAL_DEBT.md) | Original debt item #7 |

---

## Project Conventions

- **Commands**: Use `uv run` from workspace root for all Python commands
- **Linting**: `uv run ruff check PrxteinMPNN/src/ --fix`
- **Testing**: `uv run pytest PrxteinMPNN/tests/ -v`
- **Type Check**: `uv run ty check`

See [codestyles/](../../codestyles/) for language-specific guidelines.

---

## Verification

1. Run `uv run pytest PrxteinMPNN/tests/ -v` to ensure all tests pass
2. Verify imports work correctly: `uv run python -c "from prxteinmpnn.io.parsing import dispatch"`
3. Run linting: `uv run ruff check PrxteinMPNN/src/`

---

## On Completion

- [ ] Update backlog item status
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md)
- [ ] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [projects/prxteinmpnn/README.md](../../projects/prxteinmpnn/README.md) - Project guidelines
