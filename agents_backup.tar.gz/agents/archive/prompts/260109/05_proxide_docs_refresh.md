# Agent Prompt: 05_proxide_docs_refresh

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started  
**Batch:** [260109](../260109/README.md)  
**Backlog:** [projects/proxide/TECHNICAL_DEBT.md](../../projects/proxide/TECHNICAL_DEBT.md)  

---

## Task

Refresh and update the proxide documentation to reflect current API, architecture, and usage patterns after the Rust migration.

### Scope

1. **README.md Update**:
   - Update installation instructions (maturin, Rust toolchain requirements)
   - Refresh architecture overview to reflect Rust backend
   - Update example usage with current API
   - Add performance notes for Rust vs Python

2. **API Documentation**:
   - Ensure all public functions have docstrings
   - Follow docstring standards from [codestyles/python.md](../../codestyles/python.md)
   - Document Rust-Python interface boundaries

3. **Migration Notes**:
   - Document what changed from pure Python to Rust
   - List any breaking changes for downstream users

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [projects/proxide/TECHNICAL_DEBT.md](../../projects/proxide/TECHNICAL_DEBT.md) | Debt items including docs |
| [proxide/README.md](file:///home/marielle/united_workspace/proxide/README.md) | Main docs to update |
| [codestyles/python.md](../../codestyles/python.md) | Docstring standards |
| [projects/proxide/README.md](../../projects/proxide/README.md) | Agent project guide |

---

## Project Conventions

- **Commands**: Use `uv run` from workspace root for all Python commands
- **Linting**: `uv run ruff check proxide/src/ --fix`
- **Testing**: `uv run pytest proxide/tests/ -v`
- **Type Check**: `uv run ty check`

See [codestyles/](../../codestyles/) for language-specific guidelines.

---

## Verification

1. Build docs locally if sphinx/mkdocs is configured
2. Review README renders correctly on GitHub
3. Verify code examples in README work: `uv run python -c "from proxide import AtomicSystem"`

---

## On Completion

- [ ] Update [projects/proxide/TECHNICAL_DEBT.md](../../projects/proxide/TECHNICAL_DEBT.md) - mark docs item complete
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md) - mark Proxide Docs Refresh complete
- [ ] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [projects/proxide/README.md](../../projects/proxide/README.md) - Project guidelines
- [proxide/PYTHON_REMOVAL_OXIDIZE_REPLACEMENT.md](../projects/proxide/PYTHON_REMOVAL_OXIDIZE_REPLACEMENT.md) - Migration docs
