# Agent Prompt: Phase -1 JAX Performance Review

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started
**Batch:** [260107](README.md)
**Backlog:** [asr_nk_experiments.md](../../backlog/asr_nk_experiments.md)

---

## Task

Audit `trex` and `proteinsmc` code for JAX performance optimization before scaling NK experiments. Focus on:

1. **CPU/GPU Transfers**: Identify and minimize host-device data movement
2. **Jitted Execution**: Maximize time in jitted code, avoid returning to Python
3. **Recompilation Limits**: Use static shapes, `static_argnums`, shape polymorphism
4. **Batching Strategy**: Ensure `vmap` used for parameter sweeps
5. **Scan vs Loop**: Verify `lax.scan` used for sequential ops over Python loops

Document findings in a report and apply fixes.

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [asr_nk_experiments.md](../../backlog/asr_nk_experiments.md) | Backlog tracking |
| [nk_model.py](file:///home/marielle/united_workspace/trex/src/trex/nk_model.py) | NK landscape implementation |
| [sankoff.py](file:///home/marielle/united_workspace/trex/src/trex/sankoff.py) | Differentiable Sankoff |
| [tree.py](file:///home/marielle/united_workspace/trex/src/trex/tree.py) | Core TREX optimizer |
| [proteinsmc/sampling/](file:///home/marielle/united_workspace/proteinsmc/src/proteinsmc/sampling/) | SMC implementations |

---

## Project Conventions

- **Commands**: Use `uv run` for all Python commands
- **Linting**: `uv run ruff check src/ --fix`
- **Testing**: `uv run pytest tests/ -v`
- **Type Check**: `uv run ty check`

See [codestyles/](../../codestyles/) for JAX-specific patterns.

---

## On Completion

- [ ] Create performance findings report
- [ ] Apply identified fixes
- [ ] Mark Phase -1 complete in [backlog](../../backlog/asr_nk_experiments.md)
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md)
- [ ] Mark this prompt complete in [batch README](README.md)

---

## References

- [trex/README.md](../../projects/trex/README.md) - TREX project guidelines
- [proteinsmc/README.md](../../projects/proteinsmc/README.md) - ProteinSMC guidelines
