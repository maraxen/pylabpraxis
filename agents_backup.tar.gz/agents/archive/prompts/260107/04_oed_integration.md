# Agent Prompt: Phase 2 OED Integration

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started
**Batch:** [260107](README.md)
**Backlog:** [asr_nk_experiments.md](../../backlog/asr_nk_experiments.md)

---

## Task

Integrate Optimal Experimental Design (OED) infrastructure from proteinsmc:

1. **Adapt OED Infrastructure**: Port proteinsmc OED modules for ASR context
2. **Define ASR Metrics**: Create custom fitness and diversity metrics relevant to ancestral sequence reconstruction

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [asr_nk_experiments.md](../../backlog/asr_nk_experiments.md) | Backlog tracking |
| [proteinsmc/oed/](file:///home/marielle/united_workspace/proteinsmc/src/proteinsmc/oed/) | OED infrastructure |
| [proteinsmc/oed/metrics.py](file:///home/marielle/united_workspace/proteinsmc/src/proteinsmc/oed/metrics.py) | Existing metrics |
| Phase 1 results | Integration target |

---

## Project Conventions

- **Commands**: Use `uv run` for all Python commands
- **Linting**: `uv run ruff check src/ --fix`
- **Testing**: `uv run pytest tests/ -v`
- **Type Check**: `uv run ty check`

---

## On Completion

- [ ] Adapt OED infrastructure for ASR
- [ ] Define and implement ASR-relevant metrics
- [ ] Integration tests passing
- [ ] Mark Phase 2 complete in [backlog](../../backlog/asr_nk_experiments.md)
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md) - mark item complete
- [ ] Mark this prompt complete in [batch README](README.md)

---

## References

- [proteinsmc/README.md](../../projects/proteinsmc/README.md) - ProteinSMC guidelines
- [trex/README.md](../../projects/trex/README.md) - TREX guidelines
