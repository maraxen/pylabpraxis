# Agent Prompt: Phase 0 Baseline Performance

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started
**Batch:** [260107](README.md)
**Backlog:** [asr_nk_experiments.md](../../backlog/asr_nk_experiments.md)

---

## Task

Establish baseline ASR performance on NK fitness landscapes:

1. **Extended Parameter Sweep**: Run across N, K, q, μ parameter space
2. **Epistatic Site Error Metrics**: Define and implement metrics for measuring reconstruction accuracy at epistatic sites
3. **Fitness Valley Traversal Metrics**: Define metrics for evaluating how well methods traverse fitness valleys

Generate visualizations and baseline performance data.

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [asr_nk_experiments.md](../../backlog/asr_nk_experiments.md) | Backlog tracking |
| [nk_model.py](file:///home/marielle/united_workspace/trex/src/trex/nk_model.py) | NK landscape implementation |
| [W2_NK_MODEL_PLAN.md](file:///home/marielle/united_workspace/projects/asr/docs/W2_NK_MODEL_PLAN.md) | Detailed experiment plan |
| [scripts/nk_sweep.py](file:///home/marielle/united_workspace/projects/asr/scripts/nk_sweep.py) | Parameter sweep script |

---

## Project Conventions

- **Commands**: Use `uv run` for all Python commands
- **Linting**: `uv run ruff check src/ --fix`
- **Testing**: `uv run pytest tests/ -v`
- **Type Check**: `uv run ty check`

See [codestyles/](../../codestyles/) for JAX patterns.

---

## On Completion

- [ ] Complete parameter sweep
- [ ] Implement epistatic site error metrics
- [ ] Implement fitness valley metrics
- [ ] Generate baseline visualizations
- [ ] Mark Phase 0 complete in [backlog](../../backlog/asr_nk_experiments.md)
- [ ] Mark this prompt complete in [batch README](README.md)

---

## References

- [trex/README.md](../../projects/trex/README.md) - TREX guidelines
