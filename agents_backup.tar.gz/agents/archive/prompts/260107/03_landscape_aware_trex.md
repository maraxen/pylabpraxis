# Agent Prompt: Phase 1 Landscape-Aware TREX

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started
**Batch:** [260107](README.md)
**Backlog:** [asr_nk_experiments.md](../../backlog/asr_nk_experiments.md)

---

## Task

Integrate landscape-aware optimization into TREX:

1. **Lambda Sweep Integration**: Implement λ parameter sweep for landscape-aware regularization
2. **Comparative Analysis**: Compare landscape-aware TREX vs baseline methods from Phase 0

Generate comparative visualizations and performance analysis.

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [asr_nk_experiments.md](../../backlog/asr_nk_experiments.md) | Backlog tracking |
| [trex.py](file:///home/marielle/united_workspace/trex/src/trex/trex.py) | Core TREX optimizer |
| [nk_model.py](file:///home/marielle/united_workspace/trex/src/trex/nk_model.py) | NK landscape |
| Phase 0 baseline results | Comparison baseline |

---

## Project Conventions

- **Commands**: Use `uv run` for all Python commands
- **Linting**: `uv run ruff check src/ --fix`
- **Testing**: `uv run pytest tests/ -v`
- **Type Check**: `uv run ty check`

---

## On Completion

- [ ] Implement lambda sweep
- [ ] Run comparative analysis
- [ ] Generate performance visualizations
- [ ] Mark Phase 1 complete in [backlog](../../backlog/asr_nk_experiments.md)
- [ ] Mark this prompt complete in [batch README](README.md)

---

## References

- [trex/README.md](../../projects/trex/README.md) - TREX guidelines
