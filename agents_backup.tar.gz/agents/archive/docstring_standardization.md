# Docstring Standardization

**Status:** ✅ Complete  
**Difficulty:** 🟢 Easy Win  
**Projects:** All  
**Created:** 2026-01-07  
**Updated:** 2026-01-08  

---

## Goal

Standardize docstrings across all repositories to follow the imperative style with process/shapes/MathJax format. Move excessive inline comments into docstrings.

## Standard Format

1. **Imperative Summary**: Short sentence describing the function
2. **Process**: Step-by-step description (including array shapes)
3. **MathJax**: Formal mathematical notation for operations
4. **NOTES**: (Optional) Detailed explanations moved from inline comments
5. **Args**: Detailed arguments list
6. **Returns**: Return value description
7. **Example**: Usage example

## Phases

### Phase 1: Template & Guidelines

- [x] Finalize docstring template with examples
- [x] Add to codestyles/python.md

### Phase 2: Per-Repo Implementation

> **Note:** Per-repo docstring updates are ongoing via repository health audits. See `prompts/reuse/maintenance/docstring_audit.md`.

- [x] PrxteinMPNN docstring updates (via health audits)
- [x] proxide docstring updates (via health audits)
- [x] prolix docstring updates (via health audits)
- [x] trex docstring updates (via health audits)
- [x] proteinsmc docstring updates (via health audits)

---

## Notes

- Per-file task, can be done incrementally
- Coordinate with per-repo health audits

## References

- [.agents/README.md](file:///home/marielle/united_workspace/.agents/README.md) (Documentation Standards section)
