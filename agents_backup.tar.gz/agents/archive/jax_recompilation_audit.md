# JAX Recompilation Audit

**Status:** ✅ Complete  
**Difficulty:** 🔴 Complex  
**Projects:** All  
**Created:** 2026-01-07  

---

## Goal

Audit all codebases for JAX recompilation issues and implement masking/padding strategies to maintain static shapes where possible.

## Phases

### Phase 1: Audit ✅

- [x] Identify dynamic shape patterns in each repository
- [x] Profile recompilation frequency in critical paths
- [x] Document shape-changing hotspots

### Phase 2: Design Padding Strategies

- [x] Design padding utilities for variable-length inputs
- [x] Implement mask propagation for padded computations
- [x] Validate memory usage vs compilation overhead tradeoffs

### Phase 3: Per-Repo Implementation

- [x] PrxteinMPNN padding implementation
- [x] proxide padding implementation (documented existing)
- [x] prolix padding implementation (documented existing)
- [x] trex padding implementation
- [x] proteinsmc padding implementation

---

## Notes

- projects/asr already has padding utilities in `src/asr/oed/padding.py`
- Must balance OOM risk against recompilation overhead
- Reference codestyles/jax.md for static shape guidelines

## References

- [codestyles/jax.md](file:///home/marielle/united_workspace/.agents/codestyles/jax.md)
- [projects/asr/src/asr/oed/padding.py](file:///home/marielle/united_workspace/projects/asr/src/asr/oed/padding.py) (padding examples)
- Per-repo hotspot docs: `.agents/projects/{repo}/RECOMPILATION_HOTSPOTS.md`
