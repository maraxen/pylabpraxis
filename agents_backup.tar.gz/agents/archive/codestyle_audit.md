# Code Style Documentation Audit

**Status:** ✅ Complete
**Difficulty:** 🟢 Easy Win
**Projects:** workspace-wide
**Created:** 2026-01-07

---

## Goal

Audit and optimize the code style documents in `.agents/codestyles/` to ensure they are complete, well-researched, and not redundant with linter rules.

## Considerations

- Standard linting (Ruff, rustfmt, clippy) already enforces most conventions
- Focus code style docs on things **linters don't catch**:
  - JAX-specific idioms and recompilation triggers
  - Architectural patterns (PyTree structures, state management)
  - Cross-package integration patterns
- Research language-specific best practices online
- Keep docs concise - avoid duplicating what linters enforce

## Tasks

- [x] Research Python style guides beyond Ruff (Google, project-specific patterns)
- [x] Research JAX best practices (recompilation, vmap patterns)
- [x] Research Rust/PyO3 best practices
- [x] Audit current docs for redundancy with linter rules
- [x] Consolidate or expand as needed
- [x] Add any missing language-specific guidance

---

## References

- [codestyles/python.md](../codestyles/python.md)
- [codestyles/jax.md](../codestyles/jax.md)
- [codestyles/rust.md](../codestyles/rust.md)
- [codestyles/general.md](../codestyles/general.md)
