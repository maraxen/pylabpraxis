# Type Hint Modernization

**Status:** ✅ Complete  
**Difficulty:** 🟡 Intricate  
**Projects:** PrxteinMPNN, proxide, prolix, trex, proteinsmc  
**Created:** 2026-01-07  
**Completed:** 2026-01-09  

---

## Goal

Replace generic `jnp.ndarray` or `jax.Array` type hints with precise `jaxtyping` annotations across all repositories, improving code documentation and enabling static shape checking.

## Phases

### Phase 1: Audit

- [x] Scan all repos for generic array type hints
- [x] Document files requiring updates per repository

### Phase 2: Type Definition

- [x] Create/update `types.py` in each repository
- [x] Define common shapes (Scalar, ScalarFloat, BatchedArray, etc.)

### Phase 3: Per-Repo Implementation

- [x] PrxteinMPNN type migration
- [x] proxide type migration
- [x] prolix type migration
- [x] trex type migration
- [x] proteinsmc type migration

---

## Notes

- projects/asr already has `types.py` with `Scalar`, `ScalarFloat` defined
- Coordinate with per-repo health audits

## References

- [projects/asr/src/asr/types.py](file:///home/marielle/united_workspace/projects/asr/src/asr/types.py)
