# Development Matrix

Central tracking table for all development items across the workspace.

## Active Items

| Priority | Difficulty | Item | Project(s) | Status | Backlog | Updated |
|:---------|:-----------|:-----|:-----------|:-------|:--------|:--------|
| High | 🔴 Complex | ASR NK Model Experiments | trex, proteinsmc | 🟡 In Progress | [asr_nk_experiments.md](backlog/asr_nk_experiments.md) | 2026-01-07 |
| High | 🟡 Intricate | JAX Scatter Warning Investigation | workspace | 🟡 In Progress | [jax_scatter_warning.md](backlog/jax_scatter_warning.md) | 2026-01-07 |
| Medium | 🟡 Intricate | Unify NK/Potts Implementations | proteinsmc, projects/asr, trex | 🟢 Planned | [unify_nk_potts.md](backlog/unify_nk_potts.md) | 2026-01-07 |
| Medium | 🟡 Intricate | HMC/NUTS DType Conversion | proteinsmc | 🟡 In Progress | [projects/proteinsmc/TECHNICAL_DEBT.md](projects/proteinsmc/TECHNICAL_DEBT.md) | 2026-01-07 |

| Low | 🟢 Easy Win | Prolix CI Pipeline Enhancement | prolix | 🟢 Planned | [projects/prolix/TECHNICAL_DEBT.md](projects/prolix/TECHNICAL_DEBT.md) | 2026-01-07 |
| Low | 🟡 Intricate | Knowledge System Planning | workspace | 🟢 Planned | [knowledge_system_planning.md](backlog/knowledge_system_planning.md) | 2026-01-07 |
| Medium | 🟡 Intricate | Skipped Tests Investigation | PrxteinMPNN, proxide, prolix, trex, proteinsmc | 🟢 Planned | [skipped_tests_investigation.md](backlog/skipped_tests_investigation.md) | 2026-01-08 |

## Ongoing Maintenance

Per-repository health audits with scheduled reviews. Update "Last Review" in each backlog item.

| Repo | Health Audit | Last Review |
|:-----|:-------------|:------------|
| PrxteinMPNN | [health_audit_prxteinmpnn.md](backlog/health_audit_prxteinmpnn.md) | — |
| proxide | [health_audit_proxide.md](backlog/health_audit_proxide.md) | — |
| prolix | [health_audit_prolix.md](backlog/health_audit_prolix.md) | — |
| trex | [health_audit_trex.md](backlog/health_audit_trex.md) | — |
| proteinsmc | [health_audit_proteinsmc.md](backlog/health_audit_proteinsmc.md) | — |

## Completed Items

> See [Q1 2026 Code Quality Initiative](archive/q1_2026_code_quality_initiative.md) for a consolidated summary.

| Item | Project(s) | Completed | Backlog |
|:-----|:-----------|:----------|:--------|
| AtomicSystem Hierarchical Refactor | proxide | 2025-12 | [archive/atomic_system_refactor.md](archive/atomic_system_refactor.md) |
| Proxide Rust Migration | proxide | 2025-12 | [projects/proxide/PYTHON_REMOVAL_OXIDIZE_REPLACEMENT.md](projects/proxide/PYTHON_REMOVAL_OXIDIZE_REPLACEMENT.md) |
| PrxteinMPNN Training Infrastructure | prxteinmpnn | 2025-12 | [projects/prxteinmpnn/archive/TRAINING_MERGE.md](projects/prxteinmpnn/archive/TRAINING_MERGE.md) |
| Code Style Documentation Audit | workspace | 2026-01-07 | [archive/codestyle_audit.md](archive/codestyle_audit.md) |
| Configurable DType Precision | projects/asr, trex | 2026-01-08 | [archive/configurable_dtype.md](archive/configurable_dtype.md) |
| JAX Dependency Management | All | 2026-01-08 | [archive/jax_dependency_management.md](archive/jax_dependency_management.md) |
| Docstring Standardization | All | 2026-01-08 | [archive/docstring_standardization.md](archive/docstring_standardization.md) |
| Pre-commit Hooks Configuration | All | 2026-01-08 | [archive/precommit_hooks.md](archive/precommit_hooks.md) |
| Proxide/Prolix Code Migration | prxteinmpnn | 2026-01-07 | [archive/proxide_prolix_migration.md](archive/proxide_prolix_migration.md) |
| Mixed Precision for TREX | trex, projects/asr | 2026-01-08 | [archive/mixed_precision_trex.md](archive/mixed_precision_trex.md) |
| Type Hint Modernization | All | 2026-01-09 | [archive/type_hint_modernization.md](archive/type_hint_modernization.md) |
| JAX Recompilation Audit | All | 2026-01-08 | [archive/jax_recompilation_audit.md](archive/jax_recompilation_audit.md) |
| Proxide Monorepo Refactoring | proxide, oxide | 2026-01-08 | [archive/proxide_monorepo.md](archive/proxide_monorepo.md) |
| Noising Integration | proxide, prolix | 2026-01-08 | [archive/noising_integration.md](archive/noising_integration.md) |

---

## Legends

### Difficulty (for agent dispatch)

| Level | Icon | Description |
|:------|:-----|:------------|
| Complex | 🔴 | Requires careful planning, likely debugging, iterative problem-solving |
| Intricate | 🟡 | Many parts involved, but tasks are well-specified and clear |
| Easy Win | 🟢 | Straightforward, minimal ambiguity |

### Status

| Status | Meaning |
|:-------|:--------|
| 🟢 Planned | Not started |
| 🟡 In Progress | Active development |
| 🔴 Blocked | Waiting on dependency or decision |
| ✅ Complete | Finished and verified |

---

## Instructions

**When updating this matrix:**

1. Add new items with a backlog document link
2. Update status as work progresses
3. Move completed items to the "Completed" table
4. Keep `Updated` column current
