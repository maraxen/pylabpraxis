# JAX Code Style

JAX-specific idioms and patterns. **Critical for avoiding recompilation issues.**

---

## Core Principles

1. **Pure functions** - No side effects in jitted code
2. **Immutable data** - Never mutate arrays in place
3. **Static shapes** - Avoid dynamic shapes that trigger recompilation
4. **PyTree-compatible** - Use registered containers

## PyTree Registration

For custom data structures to work with JAX transformations (`jit`, `vmap`), they must be registered as PyTrees.

### Recommended: `flax.struct`

The easiest way is using `flax.struct.dataclass`:

```python
from flax import struct

@struct.dataclass
class ModelConfig:
    layers: int
    probs: float = struct.field(pytree_node=False) # Static metadata
```

### Automatic Registration

If you cannot use `flax`:

```python
import jax.tree_util

class MyNode:
    def __init__(self, x, y):
        self.x = x
        self.y = y

jax.tree_util.register_pytree_node(
    MyNode,
    lambda node: ((node.x, node.y), None), # flatten
    lambda aux, children: MyNode(*children) # unflatten
)
```

---

## Debugging 🐛

Traced values cannot be printed with standard `print()`.

| Method | Usage | Effect |
|:-------|:------|:-------|
| `print(x)` | Compilation time | Prints `Traced<ShapedArray...>` info |
| `jax.debug.print("{}", x)` | Runtime | Prints actual value during execution |
| `jax.debug.breakpoint()` | Runtime | Pauses execution for inspection |

```python
# ✅ Inspect values inside JIT
def log_step(x):
    jax.debug.print("Current value: {}", x)
    return x * 2
```

---

## Recompilation Triggers ⚠️

These cause JIT recompilation and hurt performance:

| Trigger | Problem | Solution |
|:--------|:--------|:---------|
| Changing array shapes | New trace per shape | Pad to fixed shapes |
| Changing dtypes | New trace per dtype | Standardize dtypes |
| Python control flow | Traced values in `if`/`for` | Use `jax.lax.cond`, `scan` |
| Python containers | `list`/`dict` of arrays | Use PyTree-registered classes |
| Non-static config | Config changes re-trace | Use `static_argnums` |

---

## Control Flow

```python
# ❌ Python control flow with traced values
def bad_abs(x):
    if x > 0:  # x is traced - causes error or recompile
        return x
    return -x

# ✅ JAX control flow
def good_abs(x):
    return jax.lax.cond(x > 0, lambda: x, lambda: -x)
```

### Loops

```python
# ❌ Python loop
def bad_sum(xs):
    total = 0
    for x in xs:
        total = total + x
    return total

# ✅ jax.lax.scan for stateful iteration
def good_sum(xs):
    def step(carry, x):
        return carry + x, None
    total, _ = jax.lax.scan(step, 0.0, xs)
    return total

# ✅ jax.lax.fori_loop for simple indexed loops
def good_sum_fori(xs):
    def body(i, total):
        return total + xs[i]
    return jax.lax.fori_loop(0, len(xs), body, 0.0)
```

---

## Array Updates

```python
# ❌ In-place mutation (not allowed)
array[0] = 5

# ✅ Functional update
array = array.at[0].set(5)

# ✅ Batch updates
array = array.at[indices].add(values)
```

---

## Static Arguments

Mark configuration as static to avoid recompilation:

```python
from functools import partial

# ✅ static_argnums for JIT
@partial(jax.jit, static_argnums=(1,))
def train_step(state, config):
    ...

# ✅ static_broadcasted_argnums for vmap
@partial(jax.vmap, in_axes=(0, None))
def batched_fn(data, config):
    ...
```

---

## Shape Handling

```python
# ❌ Dynamic shapes cause recompilation
def process(data):
    n = data.shape[0]  # n varies → recompiles
    return jnp.zeros(n)

# ✅ Fixed shapes with padding
MAX_SIZE = 1024

def process_fixed(data, mask):
    # data always shape (MAX_SIZE, ...), mask indicates valid
    return jnp.where(mask, data, 0.0)
```

---

## Randomness

Always thread PRNG keys explicitly:

```python
# ✅ Explicit key management
def sample(key, params):
    key1, key2 = jax.random.split(key)
    x = jax.random.normal(key1, shape=(100,))
    y = jax.random.uniform(key2, shape=(100,))
    return x, y

# ❌ Global random state (not JAX-compatible)
import numpy as np
np.random.seed(42)  # Don't do this in JAX code
```

---

## Batching with vmap

```python
# ✅ Vectorize over batch dimension
@jax.vmap
def per_sample_loss(x, y):
    return jnp.sum((x - y) ** 2)

# Usage: automatically batched
losses = per_sample_loss(batch_x, batch_y)  # shape: (batch,)
```

---

## Testing

Use `chex` for JAX-aware assertions:

```python
import chex

def test_shapes():
    result = my_function(data)
    chex.assert_shape(result, (batch_size, features))
    chex.assert_trees_all_close(result, expected, atol=1e-5)
```

---

## Mathematical Implementations

For complex mathematical operations, provide:

1. **Step-by-step process** explanation in the docstring.
2. **Array shapes** explicitly mentioned at each stage.
3. **MathJax** for LaTeX-based mathematical notation and annotations.

```python
def compute_soft_cost(p: Array, q: Array) -> Array:
  """Compute the soft cost between two probability distributions.

  Process:
  1. Compute the log-odds ratio between p and q.
     - Shapes: p: (n,), q: (n,) -> log_odds: (n,)
  2. Apply a temperature-scaled softmax to the log-odds.
     - Shapes: log_odds: (n,) -> weights: (n,)
  3. Return the weighted sum of Euclidean distances.

  Math:
  $$
  C(p, q) = \sum_{i=1}^n \text{softmax}\left(\frac{\log(p_i/q_i)}{\tau}\right) \cdot \|p_i - q_i\|^2
  $$
  """
  ...
```
