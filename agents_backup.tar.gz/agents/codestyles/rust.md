# Rust Code Style

Standards for Rust code in `oxidize` (proxide's Rust extension).

---

## Tools

| Tool | Purpose |
|:-----|:--------|
| **rustfmt** | Formatting |
| **clippy** | Linting |
| **cargo test** | Testing |

---

## Formatting

> [!NOTE]
> Formatting is enforced by **rustfmt**. We defer to its defaults (4 space indent, trailing commas).

---

## Safety

Avoid `unsafe` unless absolutely necessary (e.g., FFI, zero-copy optimization).

- **Documentation**: All `unsafe` blocks must have a `// SAFETY:` comment explaining why it is safe.
- **Review**: `unsafe` changes require extra scrutiny.

```rust
// SAFETY: access is bounded by length check above
unsafe { ... }
```

---

## Error Handling

### Rust → Python Conversion

Use `PyResult` boundaries to convert Rust errors into Python exceptions automatically.

```rust
use pyo3::exceptions::PyValueError;

fn do_thing(x: i32) -> PyResult<i32> {
    if x < 0 {
        return Err(PyValueError::new_err("x must be positive"));
    }
    Ok(x)
}
```

Prefer `Result` over panics for fallible operations:

```rust
// ✅ Return Result for fallible operations
pub fn parse_pdb(content: &str) -> Result<Protein, ParseError> {
    ...
}

// ❌ Avoid panicking in library code
pub fn parse_pdb(content: &str) -> Protein {
    content.parse().unwrap()  // Will crash on invalid input
}
```

---

## PyO3 Bindings

When exposing Rust to Python:

```rust
use pyo3::prelude::*;

#[pyfunction]
fn compute_distances(coords: PyReadonlyArray2<f32>) -> PyResult<Py<PyArray2<f32>>> {
    let coords = coords.as_array();
    // ... computation ...
    Ok(result.into_pyarray(py).to_owned())
}

#[pymodule]
fn oxidize(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(compute_distances, m)?)?;
    Ok(())
}
```

---

## NumPy Interop

Use `numpy` crate types for zero-copy array access:

```rust
use numpy::{PyArray2, PyReadonlyArray2};

// ✅ Zero-copy read
fn process(arr: PyReadonlyArray2<f32>) {
    let view = arr.as_array();  // ndarray::ArrayView2
}

// ✅ Return new array to Python
fn create_output(py: Python) -> Py<PyArray2<f32>> {
    let arr = ndarray::Array2::<f32>::zeros((10, 3));
    arr.into_pyarray(py).to_owned()
}
```

---

## Performance

- Use `rayon` for parallel iteration
- Prefer stack allocation for small fixed-size arrays
- Use `#[inline]` for hot path functions

```rust
use rayon::prelude::*;

// ✅ Parallel iteration
fn compute_all(data: &[Atom]) -> Vec<f32> {
    data.par_iter()
        .map(|atom| compute_energy(atom))
        .collect()
}
```

---

## Testing

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_pdb() {
        let content = include_str!("../test_data/1ubq.pdb");
        let protein = parse_pdb(content).unwrap();
        assert_eq!(protein.n_atoms, 660);
    }
}
```

Run tests: `cargo test --lib` in `oxidize/` directory.
