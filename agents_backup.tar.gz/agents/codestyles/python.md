# Python Code Style

Standards for Python code across the unified workspace.

---

## Tools

| Tool | Purpose | Config |
|:-----|:--------|:-------|
| **Ruff** | Linting + formatting | `select = ["ALL"]`, `line-length = 100` |
| **ty** | Type checking | Strict mode |

---

## Pre-commit Hooks

All repositories use pre-commit hooks to enforce code quality before commits are made.

- **Config:** `.pre-commit-config.yaml`
- **Installation:** `pre-commit install`
- **Manual Run:** `pre-commit run --all-files`

Standard hooks include `trailing-whitespace`, `end-of-file-fixer`, `check-yaml`, `check-added-large-files`, and `ruff` (for both linting and formatting).

---

## Formatting

> [!NOTE]
> Formatting is enforced by **Ruff**. We defer to its defaults.

- **Indent:** 2 spaces (default) or 4 spaces (legacy projects like `proteinsmc`).
- **Quotes, Line Length:** Enforced by Ruff.

---

## Architectural Patterns

### Functional Core, Imperative Shell

For scientific code, separate pure computation from I/O and state management:

1. **Core**: Pure functions, data-in/data-out, high testability (JAX/NumPy).
2. **Shell**: Handles file I/O, config loading, and orchestration.

### Validation

- **Dataclasses**: Use standard `dataclasses`.
- **Validation**: Use `__post_init__` for lightweight structural validation.
- **Serialization**: Prefer simple dict dumps or `flax.serialization` for JAX compatibility over complex Pydantic schemas unless building a public API.

---

## Type Hints

All code must be fully type-hinted.

```python
# ✅ Correct - specific types with jaxtyping
from jaxtyping import Float, Int, Array

def compute_energy(
    positions: Float[Array, "n_atoms 3"],
    charges: Float[Array, "n_atoms"],
) -> Float[Array, ""]:
    ...

# ❌ Incorrect - vague types
def compute_energy(x: Any) -> Any:
    ...
```

---

## Docstring Format

All functions must include a comprehensive docstring following the Google style with additional sections for process tracking and mathematical rigor. **Prefer docstrings over inline comments** for all technical explanations.

### Standard Template

```python
def function_name(param1: Type, param2: Type) -> ReturnType:
    """Imperative summary of the function.

    Process:
        1. Step-by-step logic description.
        2. Include array shapes for transformations: (A, B) → (A, C)
        3. Explain non-obvious branching or optimizations.

    $$\\text{LaTeX Mathematical Notation}$$

    NOTES:
        Detail explanations moved from inline comments. Use for "why" instead of "how".

    Args:
        param1: Description of param1.
        param2: Description of param2.

    Returns:
        Description of return value.

    Example:
        >>> result = function_name(val1, val2)
        >>> result
        expected_output
    """
```

### Examples

#### Mathematical Function (JAX)

```python
def compute_ms_mean(x: Float[Array, "batch seq"], mask: Int[Array, "batch seq"]) -> Float[Array, "batch"]:
    """Compute the masked mean along the sequence dimension.

    Process:
        1. Apply binary mask to input: (B, S) * (B, S) → (B, S)
        2. Sum elements along seq axis: (B, S) → (B,)
        3. Divide by valid counts per batch to get mean.

    $$\\mu_i = \\frac{\\sum_{j=1}^{N} x_{ij} \cdot m_{ij}}{\\sum_{j=1}^{N} m_{ij}}$$

    Args:
        x: Input array of values.
        mask: Binary mask (1 for valid, 0 for padding).

    Returns:
        Mean values for each batch item.
    """
```

#### I/O & Utility Function

```python
def load_protein_structure(path: Path) -> Protein:
    """Load a protein structure from a PDB file.

    Process:
        1. Read raw file content into memory.
        2. Parse atomic coordinates and residue identities.
        3. Validate against standard residue topologies.

    NOTES:
        This parser supports PDB v3.3 standards. Future updates should include
        mmCIF support as per the 2026 roadmap.

    Args:
        path: Path to the .pdb file.

    Returns:
        A Protein data structure.

    Raises:
        FileNotFoundError: If the path does not exist.
        ValueError: If the file format is invalid.
    """
```

---

## Imports

Order: stdlib → third-party → local, alphabetized within groups.

```python
import dataclasses
from pathlib import Path

import jax
import jax.numpy as jnp
from jaxtyping import Array, Float

from proxide.core import Protein
```

---

## Data Structures

```python
# Configuration (static, hashable) - use frozen dataclass
@dataclasses.dataclass(frozen=True)
class SamplerConfig:
    temperature: float = 1.0
    n_steps: int = 1000

# Dynamic state (JAX-compatible) - use flax.struct
@flax.struct.dataclass
class SamplerState:
    particles: jax.Array
    log_weights: jax.Array
```
