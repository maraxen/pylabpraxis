# General AI Agent Guidelines

Cross-language best practices for AI agents working in this workspace.

---

## Before Starting Work

1. **Check `status.json`** - Verify GPU/resources available
2. **Update `status.json`** - Mark GPU as in-use if needed
3. **Review project-specific docs** - See `projects/{repo}/README.md`
4. **Check `DEVELOPMENT_MATRIX.md`** - Understand current priorities

---

## During Work

### Code Changes

- **Small, focused commits** - One logical change per commit
- **Run tests first** - `uv run pytest` before making changes
- **Run tests after** - Verify nothing broke
- **Use linters** - `uv run ruff check --fix` before finishing

### Command Execution

```bash
# ✅ Always use uv run
uv run python script.py
uv run pytest tests/ -v

# ✅ Timeout long-running commands
timeout 60 uv run pytest tests/ -v
timeout 180 maturin develop --release

# ❌ Avoid bare python
python script.py
```

### Multi-line Scripts

Write to files instead of inline:

```bash
# ✅ Correct
cat > /tmp/test_script.py << 'EOF'
import jax
print(jax.devices())
EOF
uv run python /tmp/test_script.py

# ❌ Avoid - shell quoting issues
python -c "
import jax
print(jax.devices())
"
```

---

## After Completing Work

1. **Update `DEVELOPMENT_MATRIX.md`** - Mark items complete or update status
2. **Update `status.json`** - Release GPU if held
3. **Run full test suite** - Verify no regressions
4. **Update backlog** - Add notes, mark phases complete

---

## Architecture

### Sans-IO Pattern

For complex domains (e.g. physics simulations), separate protocol logic from I/O to simplify testing.

- **Protocol**: State machine receiving bytes/events and returning bytes/events. Pure logic (JAX/Rust).
- **IO**: Asynchronous or synchronous wrapper handling sockets/files.

### Dependency Order

Respect compliance with the dependency graph:

```
proxide → prolix → proteinsmc
       ↘ prxteinmpnn ↗
trex (standalone)
```

**Key insight**: `proxide` is foundational - changes ripple to all packages.

---

## Language-Specific Guides

Refer to detailed guides for language-specific idioms:

- [Python Styles](python.md) - Architecture, Validation, Types
- [JAX Styles](jax.md) - Recompilation, Arrays, PyTrees
- [Rust Styles](rust.md) - Safety, PyO3, Performance

---

## Documentation Standards

- **Prefer docstrings over inline comments** - Explanations for logic and implementation details should be in docstrings. Inline comments should only be used when absolutely necessary and never for large-scale notes.
- **Large scale notes** - Use the `NOTES:` prefix within docstrings for extensive notes or background context.
- **Mathematical implementations** - Documentation must include a step-by-step process explanation, details on array shapes, and MathJax for the actual math and annotations.
- **Update docs with code** - Don't leave stale docs
- **Archive completed work** - Move to `archive/` directory
- **Use status markers** - 🟢 Planned, 🟡 In Progress, 🔴 Blocked, ✅ Complete

---

## Error Recovery

If something goes wrong:

1. **Stop and assess** - Don't compound the error
2. **Revert if needed** - `git checkout -- file` or `git reset`
3. **Document the issue** - Add to `TECHNICAL_DEBT.md` if systemic
4. **Ask for help** - Use notify_user if blocked
