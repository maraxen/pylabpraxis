# Type Checking Resolution Task: `ty` Type Hints

## Overview

This task covers the resolution of type checking issues identified by `ty` (Astral's new type checker) across all four codebases in the united workspace. The type checker has been configured and is now running in place of pyright.

**Date Generated**: 2025-12-23
**Type Checker**: ty v0.0.5
**Total Diagnostics**: 331 across all codebases

| Codebase | Diagnostics |
| :--- | :--- |
| PrxteinMPNN | 107 |
| proxide | 65 |
| prolix | 118 |
| proteinsmc | 41 |

---

## Resolution Principles

When resolving type hints, apply these principles in order of preference:

### 1. **Preciseness Over Permissiveness**

Prefer specific, descriptive types that accurately reflect the data's structure. Type hints serve as documentation and enable better tooling support. **Always define type aliases in your types module** rather than using inline jaxtyping annotations.

**Prefer (in types.py):**

```python
# In src/myproject/types.py
from jaxtyping import Float, Array

Atom37Coordinates = Float[Array, "n_residues 37 3"]
```

**Then use in your code:**

```python
# In src/myproject/features.py
from myproject.types import Atom37Coordinates

def process_features(features: Atom37Coordinates) -> Atom37Coordinates:
    ...
```

**Over:**

```python
def process_features(features: Any) -> Any:
    ...
```

**Why?** Predefined type aliases are:

- DRYer (no repetition across files)
- More semantic and self-documenting
- Better compatibility with type checkers
- Easier to maintain when shapes change

### 2. **Semantic Type Aliases**

Use domain-specific type aliases that convey meaning. The codebases already define useful aliases in their `types.py` modules.

**Example from proxide:**

```python
AtomicCoordinates = Float[Array, "n_residues n_atoms 3"]
ResidueIndex = Int[Array, "n_residues"]
ChainIndex = Int[Array, "n_residues"]
```

### 3. **Union Types for Dual-Backend Support**

When code accepts both JAX arrays and NumPy arrays, use explicit union types rather than `ArrayLike` which can be too permissive.

```python
from jax import Array
import numpy as np
from numpy.typing import NDArray

ArrayOrNumpy = Array | NDArray[np.floating]
```

### 4. **Protocol Types for Structural Typing**

When an object needs specific attributes but may come from different sources, define a Protocol.

```python
from typing import Protocol

class HasCoordinates(Protocol):
    coordinates: Array
    atom_mask: Array
```

### 5. **TypeVar for Generic Functions**

When a function preserves the type of its input, use TypeVar.

```python
from typing import TypeVar
ArrayT = TypeVar("ArrayT", Array, np.ndarray)

def normalize(data: ArrayT) -> ArrayT: ...
```

---

## Issue Categories and Resolution Strategies

### Category A: JitWrapped Union Type Mismatches

**Symptoms:**

- `Union variant '((...) -> Unknown, /) -> JitWrapped' is incompatible`
- `Attempted to call union type 'JitWrapped | (((...) -> Unknown, /) -> JitWrapped)'`
- Functions decorated with `@jax.jit` being incorrectly typed

**Root Cause:** JAX's `@jit` decorator returns a `JitWrapped` object, but `ty` doesn't fully understand the signature preservation.

**Resolution Strategy:**

1. Add explicit return type annotations to JIT-compiled functions
2. Use `typing.cast()` at call sites when the return type is known
3. Create wrapper functions with explicit signatures when needed

**Example Fix:**

```python
# Step 1: Define type aliases in types.py
# In src/myproject/types.py
from jaxtyping import Float, Array

Coordinates3D = Float[Array, "n 3"]
DistanceMatrix = Float[Array, "n n"]

# Step 2: Use them in your JIT-compiled functions
# In src/myproject/geometry.py
from typing import cast
from myproject.types import Coordinates3D, DistanceMatrix

# Before (problematic)
@jax.jit
def compute_distances(coords):
    return jnp.linalg.norm(coords[:, None] - coords[None, :], axis=-1)

# After (fixed with type aliases)
@jax.jit
def compute_distances(coords: Coordinates3D) -> DistanceMatrix:
    return jnp.linalg.norm(coords[:, None] - coords[None, :], axis=-1)

# At call site if still needed (usually not after proper annotations):
result = cast(DistanceMatrix, compute_distances(coords))
```

**Files with this issue:**

- `PrxteinMPNN/src/prxteinmpnn/ensemble/ci.py`
- `PrxteinMPNN/src/prxteinmpnn/ensemble/clustering.py`
- `PrxteinMPNN/src/prxteinmpnn/utils/normalize.py`
- `proxide/src/proxide/physics/electrostatics.py`
- `proxide/src/proxide/physics/vdw.py`
- `proteinsmc/src/proteinsmc/utils/annealing.py`

---

### Category B: Array Type Mismatches (JAX vs NumPy)

**Symptoms:**

- `Expected 'Array', found 'ndarray[tuple[Any, ...], dtype[Any]]'`
- `Expected 'Array', found 'ndarray[tuple[Any, ...], dtype[Unknown]]'`

**Root Cause:** Functions expecting JAX arrays receive NumPy arrays (or vice versa).

**Resolution Strategy:**

1. Convert arrays explicitly at boundaries: `jnp.asarray()` or `np.asarray()`
2. Update type hints to accept both: `Array | NDArray`
3. Use TypeVar when the type should be preserved

**Example Fix:**

```python
# Before
def process(coords: Array) -> Array:
    return coords * 2

# After (option 1 - accept both)
def process(coords: Array | NDArray[np.floating]) -> Array:
    coords = jnp.asarray(coords)  # Normalize to JAX
    return coords * 2

# After (option 2 - preserve type)
from typing import TypeVar
ArrayT = TypeVar("ArrayT", bound=Array | np.ndarray)

def process(coords: ArrayT) -> ArrayT:
    return coords * 2
```

**Files with this issue:**

- `proxide/src/proxide/io/streaming/array_record.py` (54 instances)
- `PrxteinMPNN/src/prxteinmpnn/training/train_diffusion.py`
- `prolix/src/prolix/visualization/trajectory.py`

---

### Category C: Return Type Mismatches

**Symptoms:**

- `Return type does not match returned value`
- `expected 'X', found 'Y'`

**Root Cause:** The declared return type doesn't match what the function actually returns.

**Resolution Strategy:**

1. Analyze what the function actually returns
2. Update the return type annotation to match
3. If returning different types conditionally, use Union types
4. Consider if the function needs refactoring to return a consistent type

**Example Fix:**

```python
# Before (problematic)
def get_energies(self) -> dict[str, np.ndarray]:
    # ... code that may return None for 'kinetic' key
    return {"potential": pot, "kinetic": kin if has_kin else None}

# After (fixed with accurate return type)
def get_energies(self) -> dict[str, np.ndarray | None]:
    return {"potential": pot, "kinetic": kin if has_kin else None}
```

**Files with this issue:**

- `PrxteinMPNN/src/prxteinmpnn/scoring/score.py`
- `prolix/src/prolix/visualization/trajectory.py`
- `proteinsmc/src/proteinsmc/utils/esm.py`

---

### Category D: Unresolved Imports

**Symptoms:**

- `Cannot resolve imported module 'X'`
- `Module 'X' has no member 'Y'`

**Root Cause:** Optional dependencies not installed, or module not exposed in `__init__.py`.

**Resolution Strategy:**

1. For truly optional deps (flask, rdkit, foldcomp): Wrap in try/except with `TYPE_CHECKING` guard
2. For private modules (_oxidize): Use `# type: ignore[unresolved-import]`
3. For missing exports: Update `__init__.py` to expose the member

**Example Fix:**

```python
# Before
from flask import Flask, jsonify

# After (for optional dependency)
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flask import Flask, jsonify
else:
    try:
        from flask import Flask, jsonify
        HAS_FLASK = True
    except ImportError:
        Flask = None
        jsonify = None
        HAS_FLASK = False

# For native extensions
from proxide import _oxidize  # type: ignore[unresolved-import]
```

**Files with this issue:**

- `proxide/src/proxide/md/bridge/utils.py` (_oxidize)
- `prolix/src/prolix/viewer_server.py` (flask)
- `proxide/src/proxide/io/sources/foldcomp_source.py` (foldcomp)

---

### Category E: Missing Attributes / Protocols

**Symptoms:**

- `Attribute 'X' may be missing on object of type 'Y | None'`
- `Object of type 'Y' has no attribute 'X'`

**Root Cause:** Optional types being accessed without None-checks, or missing Protocol definitions.

**Resolution Strategy:**

1. Add explicit None checks before attribute access
2. Define or update Protocol classes to include required attributes
3. Use type narrowing with `assert` or `isinstance()`

**Example Fix:**

```python
# Before (problematic)
def process(spec: SimulationSpec | None):
    box = spec.box  # Error: spec might be None

# After (with guard)
def process(spec: SimulationSpec | None):
    if spec is None:
        raise ValueError("SimulationSpec is required")
    box = spec.box  # Now safe

# Or using assert for type narrowing
def process(spec: SimulationSpec | None):
    assert spec is not None, "SimulationSpec required"
    box = spec.box
```

**Files with this issue:**

- `prolix/src/prolix/simulate.py` (SimulationSpec attributes)
- `prolix/src/prolix/visualization/viewer.py` (py2Dmol.view attributes)

---

### Category F: Context Manager Protocols

**Symptoms:**

- `Object of type 'X' cannot be used with 'with' because it does not implement '__enter__' and '__exit__'`

**Root Cause:** Class used as context manager doesn't implement context manager protocol.

**Resolution Strategy:**
Implement `__enter__` and `__exit__` methods, or use `contextlib.contextmanager`.

**Example Fix:**

```python
# Add to TrajectoryReader class
from typing import Self

class TrajectoryReader:
    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
```

**Files with this issue:**

- `prolix/src/prolix/viewer_server.py`
- `prolix/src/prolix/visualization/trajectory.py`

---

### Category G: Argument Count/Name Mismatches

**Symptoms:**

- `Too many positional arguments: expected 1, got N`
- `Argument 'X' does not match any known parameter`
- `No argument provided for required parameter`

**Root Cause:** JIT-compiled function signatures not being properly inferred.

**Resolution Strategy:**

1. Ensure all JIT-compiled functions have explicit parameter annotations
2. Use `static_argnames` correctly
3. Add explicit type annotations to decorated functions

**Example Fix:**

```python
# In types.py
from jaxtyping import Int, Array

InteractionMatrix = Int[Array, "n k"]

# In your code
from myproject.types import InteractionMatrix, PRNGKeyArray

# Before
@partial(jit, static_argnames=("n", "k"))
def generate_nk_interactions(key, n, k):
    ...

# After (with explicit annotations using type aliases)
@partial(jit, static_argnames=("n", "k"))
def generate_nk_interactions(
    key: PRNGKeyArray,
    n: int,
    k: int
) -> InteractionMatrix:
    ...
```

**Files with this issue:**

- `proteinsmc/src/proteinsmc/utils/nk_landscape.py`
- `proteinsmc/src/proteinsmc/utils/annealing.py`

---

## File-Specific Guidance

### High Priority Files (50+ issues or critical path)

1. **`proxide/src/proxide/io/streaming/array_record.py`** - 54 issues
   - Focus: Standardize array type handling at deserialization
   - Pattern: All `np.array()` calls should have explicit dtype and shape hints

2. **`prolix/src/prolix/simulate.py`** - Multiple None-check issues
   - Focus: Add null checks for `SimulationSpec` attributes
   - Pattern: Either make `spec` non-optional or add early validation

3. **`PrxteinMPNN/src/prxteinmpnn/ensemble/ci.py`** - JitWrapped issues
   - Focus: Add explicit return types to JIT-compiled clustering functions
   - Pattern: Use `cast()` for intermediate results if needed

### Medium Priority Files (10-50 issues)

1. **`PrxteinMPNN/src/prxteinmpnn/utils/normalize.py`** - JIT function calls
2. **`proxide/src/proxide/physics/electrostatics.py`** - Force computation types
3. **`proxide/src/proxide/physics/vdw.py`** - Van der Waals computation types

### Lower Priority Files (< 10 issues)

1. **`proteinsmc/src/proteinsmc/utils/esm.py`** - HuggingFace API call
2. **`prolix/src/prolix/visualization/viewer.py`** - py2Dmol integration

---

## Running Type Checks

To verify fixes, run ty on each codebase:

```bash
# From united_workspace root
uv run ty check PrxteinMPNN/src/prxteinmpnn
uv run ty check proxide/src/proxide
uv run ty check prolix/src/prolix
uv run ty check proteinsmc/src/proteinsmc
```

## Success Criteria

1. Zero errors (exit code 0) from ty for each codebase
2. No use of `Any` type except where truly necessary (external API boundaries)
3. Meaningful type aliases used throughout
4. All JIT-compiled functions have explicit return type annotations
5. All Protocol classes properly define required attributes

---

## Resources

- [ty Documentation](https://docs.astral.sh/ty/)
- [jaxtyping for tensor shape annotations](https://github.com/google/jaxtyping)
- [Python typing module](https://docs.python.org/3/library/typing.html)
- Existing type definitions in each codebase's `types.py` module

---

## Notes for Resolution Agent

- Work through one category at a time, starting with Category A (JitWrapped) as it unlocks many downstream fixes
- Test changes incrementally with `ty check` to verify fixes
- If a fix for one issue breaks something else, document it and consider the broader refactoring needed
- When in doubt about the correct type, look at the function's implementation and callers
- Prioritize core library functions in `proxide` as they are imported by multiple downstream projects
