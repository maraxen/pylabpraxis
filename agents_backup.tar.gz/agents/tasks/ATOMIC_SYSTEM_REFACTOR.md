# AtomicSystem Hierarchical Refactor

## Status: In Progress

**Owner**: Agent
**Created**: 2024-12-24
**Blocked by**: None

---

## Goal

Refactor flat `AtomicSystem` to hierarchical structure (`MolecularTopology`, `AtomicState`, `AtomicConstants`) and integrate across proxide, PrxteinMPNN, and prolix.

---

## Completed

- [x] Create `MolecularTopology`, `AtomicState`, `AtomicConstants` in `atomic_system.py`
- [x] Implement `__getattr__` backward compatibility
- [x] Create `projector.py` with `MPNNBatch` dataclass
- [x] Decouple `Protein` from `AtomicSystem` inheritance
- [x] Update proxide core tests (11/11 pass)

---

## Remaining Work

### Phase 1: Rust Projection (oxidize)

- [ ] Implement `project_to_mpnn_batch()` in `oxidize/src/formats/protein.rs`
  - [ ] Filter atoms by `molecule_type == 0` (protein only)
  - [ ] Group by `residue_index` → extract backbone atoms
  - [ ] Compute RBF features (use existing `radial_basis.rs`)
  - [ ] Compute physics features from charges/sigmas/epsilons
  - [ ] Ensure feature order matches MPNN expectations

### Phase 2: Prolix Integration

- [ ] Update `prolix/simulate.py` to use hierarchical `AtomicSystem`
- [ ] Refactor internal calls to accept `(topology, state, constants)` as separate PyTrees
  - Enables `vmap` across `AtomicState` replicates while keeping topology/constants static
  - Potential memory gains by not duplicating static data across replicas
- [ ] Test with existing prolix physics tests

### Phase 3: PrxteinMPNN Integration

- [ ] Update `proxide/ops/transforms.py`:
  - [ ] `pad_and_collate_proteins()` → outputs `MPNNBatch`
  - [ ] `_pad_protein()` → `_pad_mpnn_batch()`
- [ ] Update dataloader to produce `MPNNBatch` directly
- [ ] Update `trainer.py` to consume `MPNNBatch`
- [ ] Identify all Protein iterator usages and migrate to MPNNBatch

### Phase 4: ArrayRecord Regeneration

- [ ] Regenerate PDB sample ArrayRecord with new format
- [ ] Regenerate full training dataset
- [ ] Upload updated ArrayRecord + JSONL index to HuggingFace Hub

### Phase 5: Protein Class Cleanup

- [ ] Remove legacy `AtomicSystem` fields from `Protein`
- [ ] Keep `Protein` for flexible output formatting
- [ ] Simplify `Protein.from_rust_dict()` to not duplicate AtomicSystem fields

### Phase 6: Testing

- [ ] All proxide tests pass
- [ ] All PrxteinMPNN run tests pass
- [ ] All PrxteinMPNN training tests pass
- [ ] All prolix tests pass

---

## Design Notes

### Prolix PyTree Separation

```python
# Currently:
simulate(system: AtomicSystem, ...)

# New pattern:
simulate(topology: MolecularTopology, state: AtomicState, constants: AtomicConstants, ...)

# Enables efficient vmap:
batched_simulate = jax.vmap(
    simulate,
    in_axes=(None, 0, None, 0)  # vmap over state replicates and keys only
)
```

**Memory benefit**: Static topology/constants not duplicated across batch dimension.

### MPNNBatch Fields

```python
@dataclass
class MPNNBatch:
    aatype: jax.Array           # (N_res,)
    residue_index: jax.Array    # (N_res,)
    chain_index: jax.Array      # (N_res,)
    mask: jax.Array             # (N_res,)
    rbf_features: jax.Array     # (N_res, K, F)
    neighbor_indices: jax.Array # (N_res, K)
    physics_features: jax.Array | None  # (N_res, F)
```

No coordinates - geometry encoded via RBF features.

---

## Files to Modify

| File | Changes |
|------|---------|
| `oxidize/src/formats/protein.rs` | Add `project_to_mpnn_batch()` |
| `proxide/ops/transforms.py` | Output `MPNNBatch` instead of `Protein` |
| `proxide/core/containers.py` | Simplify `Protein`, remove legacy fields |
| `prolix/simulate.py` | Accept separate PyTree args |
| `PrxteinMPNN/trainer.py` | Consume `MPNNBatch` |

---

## Related Docs

- [TECHNICAL_DEBT.md](file:///home/marielle/united_workspace/.agents/TECHNICAL_DEBT.md) - Noising integration notes
