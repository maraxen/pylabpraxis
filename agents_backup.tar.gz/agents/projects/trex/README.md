# TREX Agent Guidelines

Project-specific conventions and quick reference for AI agents.

---

## Overview

Differentiable algorithms for phylogenetic tree search using JAX. Provides JIT-compiled, gradient-based alternatives to traditional heuristic search algorithms for ancestral sequence reconstruction (ASR) and phylogenetics.

## Architecture

```text
src/trex/
├── sankoff.py       # Differentiable Sankoff algorithm (max parsimony)
├── trex.py          # Core TREX optimization framework
├── nk_model.py      # NK landscape fitness model
├── tree.py          # Tree data structures and operations
└── utils/           # Shared utilities
```

## Key Files

| File | Purpose |
|:-----|:--------|
| `src/trex/sankoff.py` | Differentiable maximum parsimony via Sankoff's algorithm |
| `src/trex/trex.py` | Tree relaxation/optimization core |
| `src/trex/nk_model.py` | NK fitness landscape for benchmarking |

## Common Tasks

### Running Tests

```bash
uv run pytest tests/ -v
```

### Type Checking

```bash
uv run ty check src/trex
```

### Linting

```bash
uv run ruff check src/ --fix
```

## Conventions

- **JAX Idioms**: All numerical code uses JAX functional style (`jit`, `vmap`, `scan`)
- **Immutability**: Favor immutable data structures, explicit state passing
- **Static Args**: Use `static_argnums` for non-JAX parameters in transformations
- **Docstrings**: Google-style with comprehensive type hints
- **Linting**: Ruff with `select = ["ALL"]`, line-length 100, indent-width 2

## Integration Points

| Dependency | Usage |
|:-----------|:------|
| proteinsmc | OED infrastructure for experimental design |
| jax | Core numerical computation |
| optax | Gradient-based optimization |

## Technical Debt

No standalone TECHNICAL_DEBT.md - project is relatively new. Guidelines in AGENTS.md.
