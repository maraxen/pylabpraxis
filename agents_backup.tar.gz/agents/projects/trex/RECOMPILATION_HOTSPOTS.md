# TREX Recompilation Hotspots

**Priority:** High  
**Last Updated:** 2026-01-07  

---

## Summary

TREX has 25+ dynamic shape patterns primarily in benchmark functions, NK model computations, and Sankoff algorithm. The `seq_mask` parameter has already been integrated into key functions for mask propagation.

---

## Hotspots

| File | Function | Pattern | Severity | Notes |
|:-----|:---------|:--------|:---------|:------|
| `nk_model.py` | `get_fitness` | `sequence.shape[0]`, `interactions.shape[1]` | 🔴 High | Core fitness computation; `seq_mask` already added |
| `evals/benchmark.py` | `run_trex_optimization_configurable` | `leaf_sequences.shape[1]` | 🔴 High | Main optimization loop |
| `evals/benchmark.py` | `_compute_loss_landscape_aware_stacked` | `masked_sequences.shape[1]` | 🔴 High | Loss computation; `seq_mask` already added |
| `evals/benchmark.py` | `run_trex_landscape_aware_configurable` | `leaf_sequences.shape[1]` | 🔴 High | Landscape-aware training |
| `sankoff.py` | `run_dp` | `adjacency_matrix.shape[0]` | 🔴 High | DP traversal |
| `sankoff.py` | `run_sankoff` | `sequences.shape[1]` | 🔴 High | Sankoff entry point |
| `tree.py` | `compute_tree_cost` | `sequences.shape[0]` | 🟡 Medium | Tree cost computation |
| `tree.py` | `discretize_tree_topology` | `adjacency.shape[0]` | 🟡 Medium | Topology discretization |
| `ground_truth.py` | `mutate_sequence` | `sequence.shape[0]` | 🟢 Low | Ground truth simulation |

---

## Existing Mitigations

1. **`seq_mask` parameter** added to `get_fitness` and `_compute_loss_landscape_aware_stacked`
2. **Stacked array approach** in `_update_seq_stacked` for vmap compatibility

---

## Recommended Actions (Phase 2+)

1. Integrate bucketed padding from `projects/asr/src/asr/oed/padding.py`
2. Add `padded_n` parameter to Sankoff functions
3. Consider static `MAX_NODES` constant for tree operations
