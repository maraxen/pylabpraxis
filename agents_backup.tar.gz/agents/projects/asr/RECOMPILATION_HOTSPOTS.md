# ASR (projects/asr) Recompilation Hotspots

**Priority:** High  
**Last Updated:** 2026-01-07  

---

## Summary

ASR has working padding infrastructure in `src/asr/oed/padding.py` with bucketed shapes. 25+ dynamic shape patterns remain in metric computation and GP functions. This repository serves as the reference implementation for other repos.

---

## Hotspots

| File | Function | Pattern | Severity | Notes |
|:-----|:---------|:--------|:---------|:------|
| `oed/experiment.py` | `run_oed_iteration` | `adj_matrix.shape[0]` | 🔴 High | OED main loop |
| `oed/gp.py` | `predict` | `k.shape[0]`, `candidates_x.shape[0]` | 🟡 Medium | GP prediction |
| `oed/gp.py` | `fit_gp_models` | `y.shape[1]` | 🟡 Medium | GP fitting |
| `nk_utils.py` | `compute_hamming_by_depth` | `predicted.shape[-1]`, `depths.shape[0]` | 🟡 Medium | Depth metrics |
| `nk_utils.py` | `compute_ancestor_fitness_weighted` | Multiple shape patterns | 🟡 Medium | Fitness metrics |
| `nk_utils.py` | `generate_tree_structure` | `adj_matrix.shape[0]` | 🟡 Medium | Tree generation |
| `potts.py` | `compute_potts_hamiltonian` | `sequence.shape[0]` | 🟢 Low | Potts model |

---

## Existing Infrastructure

### [padding.py](file:///home/marielle/united_workspace/projects/asr/src/asr/oed/padding.py)

**Buckets defined:**

- `N_BUCKETS = (32, 64, 100)` - Sequence length
- `K_BUCKETS = (2, 4, 8)` - Epistasis parameter
- `Q_BUCKETS = (4, 20)` - Alphabet size

**Available utilities:**

- `get_bucket(value, buckets)` - Find smallest fitting bucket
- `pad_sequence(sequence, target_n)` - Pad sequences
- `pad_sequences_batch(sequences, target_n)` - Batch padding
- `create_sequence_mask(real_n, padded_n)` - Create validity mask
- `pad_fitness_table(...)` - Pad NK fitness tables
- `pad_interactions(...)` - Pad interaction indices
- `masked_mean(values, mask)` - Mean over valid elements
- `masked_sum(values, mask)` - Sum over valid elements

---

## Recommended Actions (Phase 2+)

1. Integrate padding into GP functions for consistent candidate batch sizes
2. Use `masked_mean` in all metric computations
3. Document padding workflow in project README
