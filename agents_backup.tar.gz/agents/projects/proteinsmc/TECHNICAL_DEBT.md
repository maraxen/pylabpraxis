# ProteinSMC Technical Debt

## Active Issues

### 1. HMC/NUTS Data Type Conversions

**Status:** 🟡 In Progress
**Priority:** Medium

**Issue:** HMC/NUTS samplers require float32 inputs for gradient computation, but sequences are stored as int8 for memory efficiency.

**Current State:** 4 tests failing in `test_initialization_factory.py` (HMC/NUTS initialization with int8 sequences).

**Future Solution:** Implement modular data type conversion layer that:

1. Detects sampler requirements (gradient-based vs. discrete)
2. Automatically converts int8 sequences to float32 when needed
3. Converts results back to int8 for storage
4. Minimizes memory overhead through lazy conversion

**References:**

- `tests/sampling/test_initialization_factory.py` lines 96-179

---

### 2. Parallel Replica SMC Edge Cases

**Status:** 🟡 In Progress
**Priority:** Medium

**Resolved Issues:**

- ✅ Key Management: Fixed with `jax.random.split(key, n_islands)`
- ✅ Update Parameters: Fixed with proper shape `(population_size,)` arrays
- ✅ JAX PyTree: Converted to `@struct.dataclass`
- ✅ Loop Structure: Fixed `lax.fori_loop` carry

**Remaining Work:**

- Shape mismatches in migrate/exchange for single-island case (n_islands=1)
- Fitness extraction logic for StackedFitness format
- Integration tests for proper state initialization

**References:**

- `src/proteinsmc/sampling/particle_systems/parallel_replica.py`
- `src/proteinsmc/sampling/initialization_factory.py` lines 303-379

---

### 3. Dynamic DType Handling

**Status:** 🟢 Planned
**Priority:** Medium-High

**Issue:** Application-wide need for flexible dtype handling across sequences and samplers.

**Solution:** Centralized dtype management system with:

1. Canonical dtypes per data category
2. Automatic conversion utilities
3. Configuration-based dtype selection
4. Consistency validation

**Related:** Issues #1 and #2 above.

---

## Completed Items ✅

### Architectural Improvements (2025-10)

- ✅ **SamplerState Refactoring:** Converted from `equinox.nn.State` to `flax.struct.dataclass`
- ✅ **Config Serialization:** Fixed `io.py` to exclude JAX Mesh field
- ✅ **Test Coverage:** Improved from 62% to 96.2% (227/236 tests passing)
- ✅ **PRSMC Key Management:** Fixed key batching and update_parameters structure
