# proteinsmc Health Audit

**Last Updated**: 2026-01-08
**Auditor**: Antigravity
**Overall Status**: 🔴 Critical Issues

---

## Quick Summary

| Category | Status | Issues | Notes |
| :--- | :--- | :--- | :--- |
| Linting (Ruff) | 🟡 | 29 | Mostly missing docstrings in TYPE_CHECKING blocks |
| Type Checking (ty) | 🟢 | 0 | All issues resolved |
| Tests (pytest) | 🔴 | 13 failed, 321 passed, 16 skipped | Issues with Nucleotide sequence length check in updated fitness/translation logic |
| Imports | 🟢 | 0 | |
| Dependencies | 🟢 | 0 | |

---

## Linting Issues

**Command**: `uv run ruff check src/`
**Status**: 🟡 Needs Attention

### Summary

Ruff identified 29 issues. Most are `D103` (missing docstring in public function) occurring within `TYPE_CHECKING` blocks, which were recently added to handle JIT compilation typing.

### Outstanding Issues

| File | Rule | Description | Priority |
| :--- | :--- | :--- | :--- |
| `proteinsmc/sampling/gibbs.py` | `D103` | Missing docstring in TYPE_CHECKING | Low |
| `proteinsmc/scoring/mpnn.py` | `ANN401` | Dynamic typing in `_context` | Medium |
| `proteinsmc/models/structs.py` | `ANN201` | Missing return type for `replace` | Low |

---

## Type Checking Issues

**Command**: `uv run ty check src/`
**Status**: 🟢 Healthy

### Summary

All static type errors have been resolved. The repository now uses proper `TYPE_CHECKING` guards for JIT-compiled functions and correct casting for runtime logic.

---

## Test Failures

**Command**: `uv run pytest tests/`
**Status**: 🔴 Critical Issues

### Summary

- **Passed**: 321
- **Failed**: 13
- **Skipped**: 16

### Failing Tests

| Test | Error Type | Description | Priority |
| :--- | :--- | :--- | :--- |
| `proteinsmc/tests/oed/test_experiment_integration.py` | `TypeError` | "Nucleotide sequence length must be a multiple of 3" | High |
| `proteinsmc/tests/scoring/test_cai.py` | `TypeError` | "Nucleotide sequence length must be a multiple of 3" | High |
| `proteinsmc/tests/utils/test_fitness_advanced.py` | `TypeError` | "Nucleotide sequence length must be a multiple of 3" | High |

**Analysis**: The failures suggest that recent changes to `fitness.py` or `translation.py` (strict length check) are rejecting previously valid test inputs, or test inputs are malformed.

---

## Action Items

### High Priority

- [ ] Fix `TypeError: Nucleotide sequence length must be a multiple of 3` in failing tests. This is likely due to inputs in tests not matching the 3x length requirement enforced by `nucleotide_to_aa`.

### Medium Priority

- [ ] Resolve `ANN401` (`Any`) usage in `proteinsmc/scoring/mpnn.py`.

### Low Priority

- [ ] Add docstrings to `TYPE_CHECKING` blocks to satisfy `D103`.
