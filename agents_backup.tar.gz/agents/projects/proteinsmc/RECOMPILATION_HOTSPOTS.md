# ProteinSMC Recompilation Hotspots

**Priority:** Medium  
**Last Updated:** 2026-01-07  

---

## Summary

ProteinSMC has 37+ dynamic shape patterns concentrated in SMC sampling, parallel replica, and utility functions. Variable population sizes and sequence lengths are the main recompilation triggers.

---

## Hotspots

| File | Function | Pattern | Severity | Notes |
|:-----|:---------|:--------|:---------|:------|
| `sampling/smc.py` | SMC step | `state.sequence.shape[0]` | 🔴 High | Core sampling loop |
| `sampling/parallel_replica.py` | Replica step | `sequences.shape[0]` | 🔴 High | Parallel MCMC |
| `sampling/initialization_factory.py` | Population init | `initial_population.shape[0]` | 🟡 Medium | Initialization |
| `utils/mutation.py` | `mutate_population` | `population.shape[0]` | 🟡 Medium | Mutation operations |
| `utils/translation.py` | `translate_codons` | `sequence.shape[0]` | 🟡 Medium | Codon translation |
| `utils/metrics.py` | Diversity metrics | `seqs.shape[0]`, `log_weights.shape[0]` | 🟢 Low | Metric computation |
| `utils/pmap_utils.py` | Device reshaping | `x.shape[1:]`, `x.shape[2:]` | 🟡 Medium | Multi-device |
| `scoring/mpnn.py` | MPNN scoring | `processed_inputs.residue_index.shape[0]` | 🟡 Medium | Scoring |
| `scoring/esm.py` | ESM scoring | `sequence.shape[1]` | 🟡 Medium | ESM PLL |
| `utils/esm.py` | ESM model | Multiple shape patterns | 🟡 Medium | ESM layers |
| `oed/gp.py` | GP functions | `k.shape[0]`, `y.shape[1]` | 🟡 Medium | GP for OED |

---

## Key Challenges

1. **Variable population sizes** - SMC resampling changes particle counts
2. **Variable sequence lengths** - Different proteins have different lengths
3. **pmap constraints** - Must divide evenly across devices

---

## Recommended Actions (Phase 2+)

1. Define `MAX_POPULATION` and `MAX_SEQ_LEN` constants
2. Pad populations to fixed sizes with valid particle masks
3. Use bucketed sequence padding similar to `projects/asr`
4. Add `valid_particle_mask` to SMC state
