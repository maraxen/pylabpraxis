# ProteinSMC Agent Guidelines

Project-specific conventions and quick reference for AI agents.

---

## Overview

JAX-based Sequential Monte Carlo (SMC) sampling framework for protein sequence design and evolutionary studies. Provides benchmarking infrastructure for comparing sampling methods and tools for exploring fitness landscapes.

## Architecture

```text
src/proteinsmc/
├── sampling/           # Core sampling algorithms
│   ├── smc.py          # SMC sampler implementation
│   ├── particle_systems/
│   │   └── parallel_replica.py  # Island model / PRSMC
│   └── initialization_factory.py
├── oed/                # Optimal Experimental Design
│   └── metrics.py      # Fitness and diversity metrics
├── io.py               # RunManager, DataWriter (Hot→Warm→Cold storage)
├── runner.py           # Polymorphic experiment dispatch
├── experiment.py       # Experiment configuration
└── utils/              # Shared utilities
```

## Key Files

| File | Purpose |
|:-----|:--------|
| `src/proteinsmc/runner.py` | Main entry point, polymorphic sampler dispatch |
| `src/proteinsmc/io.py` | RunManager, async DataWriter, uuid7-based runs |
| `src/proteinsmc/sampling/smc.py` | Core SMC implementation |
| `src/proteinsmc/sampling/particle_systems/parallel_replica.py` | Parallel Replica SMC (island model) |

## Common Tasks

### Running Tests

```bash
uv run pytest tests/ -v
```

### Tests with Coverage

```bash
uv run pytest --cov=src --cov-report=term
```

### Linting

```bash
uv run ruff check src/ --fix
```

## Conventions

- **Type Hinting**: Full type hints required; use `jaxtyping` for JAX arrays
- **Config vs State**: Static configs inherit `BaseSamplerConfig`; dynamic state uses `flax.struct.dataclass`
- **I/O Pipeline**: Hot (safetensors + jsonl) → Warm/Cold (Parquet consolidation)
- **Immutability**: Embrace JAX functional style, avoid in-place mutations
- **Testing**: Use `pytest` + `chex` for JAX assertions

## Integration Points

| Dependency | Usage |
|:-----------|:------|
| trex | TREX optimizer for ASR experiments |
| prxteinmpnn | PrxteinMPNN fitness scoring |
| jax | Core computation |
| flax | PyTreeNode state management |

## Technical Debt

See [TECHNICAL_DEBT.md](TECHNICAL_DEBT.md) for known issues including:

- HMC/NUTS dtype conversion requirements
- PRSMC edge case handling
- Dynamic dtype management
