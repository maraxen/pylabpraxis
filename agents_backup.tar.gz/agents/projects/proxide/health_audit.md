# proxide Health Audit

**Last Updated**: 2026-01-08
**Auditor**: Antigravity
**Overall Status**: 🔴 Critical Issues

---

## Quick Summary

| Category | Status | Issues | Notes |
| :--- | :--- | :--- | :--- |
| Linting (Ruff) | 🟡 | 2 | Import/redefinition issues |
| Type Checking (ty) | 🟢 | 0 | All issues resolved |
| Tests (pytest) | 🔴 | 9 failed, 423 passed, 74 skipped | Protein object subscription errors in validation tests |
| Imports | 🟢 | 0 | |
| Dependencies | 🟢 | 0 | |

---

## Linting Issues

**Command**: `uv run ruff check src/`
**Status**: 🟡 Needs Attention

### Summary

Ruff identified 2 issues after auto-fixing others.

### Outstanding Issues

| File | Rule | Description | Priority |
| :--- | :--- | :--- | :--- |
| `proxide/core/projector.py` | `F401` | Unused import `openmm.Platform` | Low |
| `proxide/physics/features.py` | `F811` | Redefinition of `Float` | Low |

---

## Type Checking Issues

**Command**: `uv run ty check src/`
**Status**: 🟢 Healthy

### Summary

Static type checking passed successfully.

---

## Test Failures

**Command**: `uv run pytest tests/`
**Status**: 🔴 Critical Issues

### Summary

- **Passed**: 423
- **Failed**: 9
- **Skipped**: 74

### Failing Tests

| Test | Error Type | Description | Priority |
| :--- | :--- | :--- | :--- |
| `proxide/tests/validation/test_hydrogen_parity.py` | `TypeError` | "'Protein' object is not subscriptable" | High |
| `proxide/tests/validation/test_structure_parity.py` | `TypeError` | "'Protein' object is not subscriptable" | High |

**Analysis**: The `Protein` container seems to have lost `__getitem__` or similar capability, causing parity tests to fail when trying to index into it (likely for masking or slicing).

---

## Action Items

### High Priority

- [ ] Fix `Protein` object subscription causing 9 test failures in parity checks.

### Low Priority

- [ ] Resolve remaining linting errors (unused imports/redefinitions).
