# Proxide Recompilation Hotspots

**Priority:** Low  
**Last Updated:** 2026-01-07  

---

## Summary

Proxide has 50+ dynamic shape patterns primarily in I/O and geometry operations. The `ops/transforms.py` module already contains padding infrastructure for batching proteins of different lengths.

---

## Hotspots

| File | Function | Pattern | Severity | Notes |
|:-----|:---------|:--------|:---------|:------|
| `ops/transforms.py` | `pad_protein` | `protein.coordinates.shape[0]` | 🔴 High | Padding logic |
| `ops/transforms.py` | `batch_proteins` | Multiple shape queries | 🔴 High | Batching |
| `physics/features.py` | Feature extraction | `backbone_positions.shape[0]` | 🟡 Medium | Feature building |
| `physics/vdw.py` | VdW energy | `values.shape`, `backbone_positions.shape[0]` | 🟡 Medium | VdW computation |
| `physics/electrostatics.py` | Electrostatics | `backbone_positions.shape[0]` | 🟡 Medium | Coulomb |
| `geometry/radial_basis.py` | RBF features | `backbone_coordinates.shape[0]` | 🟡 Medium | Radial basis |
| `geometry/alignment.py` | Alignment | `traceback.shape[0]` | 🟢 Low | Sequence alignment |
| `io/streaming/*.py` | Data loading | Shape validation | 🟢 Low | I/O validation |
| `io/parsing/*.py` | Parsing | Shape handling | 🟢 Low | File parsing |

---

## Existing Infrastructure

### `ops/transforms.py` Padding Functions

```python
# Existing padding utilities
pad_protein(protein, max_length, md_dims=None)
batch_proteins(proteins, max_length=None, md_dims=None)
```

**Features:**

- Handles coordinates, bonds, angles, exclusion masks
- Supports MD-specific dimensions (`max_bonds`, `max_angles`, `max_atoms`)
- Creates `mask` array for valid residues

---

## Key Observations

1. **I/O layer** - Primarily handles shape validation, not computation
2. **Upstream of JAX-heavy code** - Shapes determined before passing to prolix/PrxteinMPNN
3. **Batching infrastructure exists** - Already has padding for proteins

---

## Recommended Actions (Phase 2+)

1. ✅ Existing infrastructure is adequate - `_pad_protein` and `pad_and_collate_proteins` handle all padding needs
2. Document usage patterns in project README if needed
3. Standardize padding dimensions with downstream consumers (PrxteinMPNN uses same constants)
4. Low priority - no action required
