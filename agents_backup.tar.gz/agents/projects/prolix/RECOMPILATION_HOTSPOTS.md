# Prolix Recompilation Hotspots

**Priority:** Low  
**Last Updated:** 2026-01-07  

---

## Summary

Prolix has 59+ dynamic shape patterns primarily in physics calculations. However, most simulations operate on fixed system sizes (constant atom count per protein), so recompilation impact is lower in practice.

---

## Hotspots

| File | Function | Pattern | Severity | Notes |
|:-----|:---------|:--------|:---------|:------|
| `physics/system.py` | Energy computation | `charges.shape[0]`, `r.shape[0]` | 🟡 Medium | System construction |
| `physics/pme.py` | PME electrostatics | `r.shape[0]` | 🟡 Medium | Ewald summation |
| `physics/generalized_born.py` | GB solvation | `positions.shape[0]`, `distances.shape[0]` | 🟡 Medium | Solvation |
| `simulate.py` | Simulation loop | `r_init.shape[0]`, `stacked_state.shape[0]` | 🟡 Medium | MD integration |
| `physics/cmap.py` | CMAP potentials | `cmap_grids.shape[0]` | 🟢 Low | CMAP energy |
| `physics/neighbor_list.py` | Neighbor lists | `excl_indices.shape[1]` | 🟢 Low | Neighbor finding |
| `physics/settle.py` | SETTLE constraints | `water_indices.shape[0]` | 🟢 Low | Water constraints |
| `physics/virtual_sites.py` | Virtual sites | `vs_def.shape[0]` | 🟢 Low | Virtual particles |
| `physics/sasa.py` | SASA calculation | `positions.shape[0]` | 🟢 Low | Surface area |

---

## Key Observations

1. **Fixed system size** - Once a system is defined, atom count is constant
2. **Per-system compilation** - First run compiles, subsequent runs reuse
3. **Batch simulations** - Multiple trajectories use same compiled code

---

## Recommended Actions (Phase 2+)

1. ✅ Document expected one-time compilation per system size (done in this doc)
2. Consider atom count buckets for multi-protein pipelines: `(1000, 5000, 10000, 50000)` - only if needed
3. Add `n_atoms` as `static_argnum` where applicable - already works due to fixed system sizes
4. Low priority relative to trex/proteinsmc - no action required

> **Note**: Prolix simulations use fixed system sizes. Once a system is defined (e.g., a specific protein with N atoms), the atom count is constant for all subsequent simulations. This means compilation happens once per system size, and the compiled code is reused for all trajectories. This is acceptable behavior.
