# Prolix Agent Guidelines

Project-specific conventions and quick reference for AI agents.

---

## Overview

JAX-based molecular dynamics and physics library. Provides electrostatics, van der Waals calculations, implicit solvent (GBSA), integrators, and minimization routines for molecular simulation.

## Architecture

```text
src/prolix/
├── physics/          # Core physics calculations
│   ├── electrostatics.py   # Coulomb, PME
│   ├── vdw.py              # Lennard-Jones
│   └── constants.py        # Physical constants
├── simulate.py       # Main simulation loop
├── pt/               # Parallel tempering
└── integrators/      # MD integrators (Langevin, etc.)
```

## Key Files

| File | Purpose |
|:-----|:--------|
| `src/prolix/simulate.py` | Main simulation loop |
| `src/prolix/physics/electrostatics.py` | Coulomb and PME calculations |
| `src/prolix/physics/vdw.py` | Lennard-Jones interactions |

## Common Tasks

### Running Tests

```bash
uv run pytest tests/ -v
```

### Linting

```bash
uv run ruff check src/ --fix
```

## Conventions

- **Agent Coordination**: Use `agent_tasks.jsonl` for multi-agent task tracking (see below)
- **Debugging Artifacts**: Store outputs in `outputs/` directory
- **uv run**: Always use `uv run` for Python commands

## Agent Coordination

### Task Log Format

Append to `.agents/projects/prolix/agent_tasks.jsonl` when starting/completing tasks:

```json
{
  "timestamp": "2025-12-06T15:50:00-05:00",
  "agent_id": "unique_agent_identifier",
  "task": "Short task name",
  "status": "IN_PROGRESS|COMPLETED|BLOCKED",
  "files_in_scope": ["path/to/file1.py"],
  "summary": "Brief description"
}
```

### Scope Boundaries

| Agent Task | File Scope |
|:-----------|:-----------|
| Code Optimization | `src/prolix/physics/*` |
| Simulation Loop | `src/prolix/simulate.py` |
| Parallel Tempering | `src/prolix/pt/*` |

## Integration Points

| Dependency | Usage |
|:-----------|:------|
| proxide | Structure parsing, force field loading |
| jax | Core numerical computation |
| OpenMM | Validation reference |

## Technical Debt

See [TECHNICAL_DEBT.md](TECHNICAL_DEBT.md) for known issues including:

- Test standardization
- CI pipeline (Rust builds)
- Full nonbonded parity validation
