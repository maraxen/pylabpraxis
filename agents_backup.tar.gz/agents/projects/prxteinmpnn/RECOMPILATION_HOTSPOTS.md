# PrxteinMPNN Recompilation Hotspots

**Priority:** Medium  
**Last Updated:** 2026-01-07  

---

## Summary

PrxteinMPNN has the highest concentration of dynamic shape patterns (128+). Variable protein lengths drive most recompilation. This is inherent to per-protein inference but can be mitigated with length-bucketed batching.

---

## Hotspots

| File | Function | Pattern | Severity | Notes |
|:-----|:---------|:--------|:---------|:------|
| `model/mpnn.py` | Core MPNN forward | `logits.shape[0]`, `mask.shape[0]` | 🔴 High | Main model |
| `model/encoder.py` | `MessagePassingLayer` | `edge_features.shape[0]` | 🔴 High | Encoder layers |
| `model/encoder.py` | `EncDecLayer` | `node_features.shape` | 🔴 High | EncDec layers |
| `model/decoder.py` | Decoder | `layer_edge_features.shape[1]` | 🟡 Medium | Decoding |
| `model/features.py` | Feature extraction | `structure_coordinates.shape[0]` | 🔴 High | Feature building |
| `model/features_direct.py` | Direct features | `structure_coordinates.shape[0]` | 🔴 High | Direct path |
| `model/diffusion_mpnn.py` | Diffusion model | `mask.shape[0]` | 🟡 Medium | Diffusion variant |
| `run/jacobian.py` | Jacobian computation | Multiple reshape operations | 🔴 High | Jacobian analysis |
| `run/conformational_inference.py` | CI sampling | `batched_ensemble.coordinates.shape[0]` | 🟡 Medium | Conformational |

---

## Key Challenges

1. **Per-protein inference** - Each protein has unique length
2. **Neighbor graph construction** - `k_neighbors` varies with protein size
3. **Jacobian computation** - Requires consistent shapes for batching
4. **HDF5 output** - Handles variable shapes via resizing

---

## Existing Mitigations

1. **Length bucketing in `jacobian.py`** - `max_len` computation and padding for batched Jacobians
2. **Mask arrays** - `mask` parameter throughout model

---

## Recommended Actions (Phase 2+)

1. Define protein length buckets: `(100, 200, 400, 800, 1200)`
2. Pad all proteins to bucket ceiling before inference
3. Include `residue_mask` in all feature computations
4. Pre-compile models for each bucket size
5. Consider JIT caching for common protein lengths
