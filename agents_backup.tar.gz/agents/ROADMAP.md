# Project Roadmap

High-level milestones for the united workspace. Synced with [DEVELOPMENT_MATRIX.md](DEVELOPMENT_MATRIX.md).

---

## Q1 2026

### ASR Framework Validation

- [ ] Phase 0: Baseline NK model parameter sweeps
- [ ] Phase 1: Landscape-aware TREX integration
- [ ] Phase 2: OED infrastructure adaptation

---

## Ongoing Maintenance

Infrastructure and code quality tasks with scheduled reviews. See [DEVELOPMENT_MATRIX.md](DEVELOPMENT_MATRIX.md) for tracking.

- Repository Health Audits (per-repo, quarterly review)
  - Use [maintenance prompts](prompts/reuse/maintenance/) for consistent checks
- Skipped Tests Investigation (workspace-wide audit)

---

## Completed

### Q1 2026

> See [Q1 2026 Code Quality Initiative](archive/q1_2026_code_quality_initiative.md) for details.

- [x] **Pre-commit Hooks Configuration** - Standardized across all repos
- [x] **Type Hint Modernization** - `jaxtyping` annotations workspace-wide
- [x] **Docstring Standardization** - Template and guidelines established
- [x] **JAX Dependency Management** - Environment-conditional backends
- [x] **JAX Recompilation Audit** - Padding strategies implemented
- [x] **Configurable DType Precision** - Global dtype configuration
- [x] **Mixed Precision for TREX** - Float32 optimizer, bfloat16 forward pass
- [x] **Proxide Monorepo Refactoring** - oxide/proxide unified
- [x] **Proxide/Prolix Migration** - PrxteinMPNN code consolidated
- [x] **Noising Integration** - Injectable MD-based noising
- [x] **Code Style Audit** - Codestyle docs optimized

### Q4 2025

- [x] **AtomicSystem Hierarchical Refactor** (proxide) - Dec 2025
- [x] **Proxide Rust Migration** - Pure Rust parsers for PDB, mmCIF, XTC, DCD, TRR, HDF5
- [x] **PrxteinMPNN Training Infrastructure** - Grain-based pipeline, mixed precision
- [x] **Type Checker Migration** - All packages now use `ty`

---

## Instructions

**Update this roadmap when:**

- Major milestones are completed
- New quarterly goals are defined
- Scope changes significantly

Keep in sync with [DEVELOPMENT_MATRIX.md](DEVELOPMENT_MATRIX.md) for detailed item tracking.
