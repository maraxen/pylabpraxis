# Skipped Tests Investigation

**Status:** 🟢 Planned
**Difficulty:** 🟡 Intricate
**Projects:** PrxteinMPNN, proxide, prolix, trex, proteinsmc
**Created:** 2026-01-08

---

## Goal

Audit and investigate all skipped tests across the workspace repositories. Determine why each test is skipped, whether the reason is still valid, and either enable the test (fixing it if necessary) or document a clear path to resolution.

## Tasks

- [ ] **PrxteinMPNN**: Audit skipped tests and investigate root causes.
- [ ] **proxide**: Audit skipped tests and investigate root causes.
- [ ] **prolix**: Audit skipped tests and investigate root causes.
- [ ] **trex**: Audit skipped tests and investigate root causes.
- [ ] **proteinsmc**: Audit skipped tests and investigate root causes.
- [ ] **Final Report**: Document findings and resolutions for each repository.

---

## References

- [.agents/DEVELOPMENT_MATRIX.md](/.agents/DEVELOPMENT_MATRIX.md)
- [pytest Documentation on Skipping Tests](https://docs.pytest.org/en/stable/how-to/skipping.html)
