# Unify NK/Potts Implementations

**Status:** 🟢 Planned
**Difficulty:** 🟡 Intricate
**Projects:** proteinsmc, projects/asr, trex
**Created:** 2026-01-07

---

## Goal

Consolidate the NK and Potts model implementations across the workspace into a single, optimized version that combines the performance of `trex`/`asr` with the robust logging/saving capabilities of `proteinsmc`.

## Challenges

- `projects/asr` and `trex` have more optimized kernels (faster execution).
- `proteinsmc` has a better system for writing evolutionary trajectories to `ArrayRecord`.
- Need to maintain compatibility with existing sweeps and OED infrastructure.

## Implementation Strategy

The target architecture should follow the "Prolix Strategy" to maximize JAX performance and data saving efficiency:

1. **Inner Loop**: Use `jax.lax.scan` for the primary evolutionary steps.
2. **Granularity**: Use nested loops (like `jax.lax.for_iloop`) inside the scan if necessary for sub-step operations. This is basically what timestep resolution we will save over.
3. **Data Logging**: Scanned outputs should be returned to the host and written to `ArrayRecord` *outside* the primary Python loop to avoid excessive host-device transfers and Python overhead.
4. **Single Source of Truth**: Move the core logic into a shared utility or a primary project (e.g., `trex` or a shared `jax_bio` lib) and have other projects import from there.

## Tasks

- [ ] **Audit Implementations**: Compare `proteinsmc/nk_model.py` and `trex/nk_model.py` to identify unique features.
- [ ] **Port Optimizations**: Ensure all `trex`/`asr` performance optimizations (e.g., vectorization, scan usage) are present in the unified version.
- [ ] **Integrate ArrayRecord**: Port the trajectory saving logic from `proteinsmc` to the unified model.
- [ ] **Refactor Projects**: Update `proteinsmc` and `projects/asr` to use the new unified implementation.
- [ ] **Verify Equivalence**: Ensure that the unified model produces identical results to the previous versions.

---

## References

- [.agents/TECHNICAL_DEBT.md](/.agents/TECHNICAL_DEBT.md)
- [proteinsmc NK implementation](/home/marielle/united_workspace/projects/proteinsmc/src/proteinsmc/models/nk.py)
- [trex NK implementation](/home/marielle/united_workspace/trex/src/trex/nk_model.py)
