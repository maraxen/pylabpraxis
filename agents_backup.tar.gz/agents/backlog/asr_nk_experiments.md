# ASR NK Model Experiments

**Status:** 🟡 In Progress
**Difficulty:** 🔴 Complex
**Projects:** trex, proteinsmc
**Created:** 2026-01-07

---

## Goal

Validate ancestral sequence reconstruction (ASR) methods using NK fitness landscapes with configurable epistasis (K parameter).

## Phases

### Phase -1: JAX Performance Review

Audit trex and proteinsmc code for JAX optimization opportunities before scaling experiments.

- [x] **CPU/GPU Transfers**: Identify and minimize host-device data movement
- [x] **Jitted Execution**: Maximize time in jitted code, avoid returning to Python
- [x] **Recompilation Limits**: Use static shapes, `static_argnums`, shape polymorphism where needed
- [x] **Batching Strategy**: Ensure `vmap` used appropriately for parameter sweeps
- [x] **Scan vs Loop**: Verify `lax.scan` used for sequential operations over Python loops
- [x] Document findings and apply fixes before proceeding (See `technical_debt.md` for deferred linting)

### Phase 0: Baseline Performance

- [x] Extended parameter sweep (N, K, q, μ) - completed
- [x] Define epistatic site error metrics
- [x] Define fitness valley traversal metrics
- [x] **Visualization & Analysis**:
  - Confirmed TREX/Sankoff equivalence in current regime.
  - Identified need to disable `coupled_mutation_prob` (defaulted to 0.5, now set to 0.0).
  - Produced "Regime Interaction" and "Functional Collapse" plots.

### Phase 1: Landscape-Aware TREX

- [ ] Lambda sweep integration
- [ ] Comparative analysis vs baseline methods

### Phase 2: OED Integration

- [x] Adapt proteinsmc OED infrastructure
- [x] Define ASR-relevant custom metrics

---

## References

- [W2_NK_MODEL_PLAN.md](/home/marielle/united_workspace/projects/asr/docs/W2_NK_MODEL_PLAN.md)
- [nk_model.py](/home/marielle/united_workspace/trex/src/trex/nk_model.py)
