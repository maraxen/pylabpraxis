# United Workspace Agent Coordination

Central coordination hub for AI agents working across the unified protein design ecosystem.

---

## 🚀 Quick Start

1. **Check status**: Review [status.json](status.json) for GPU/resource availability
2. **Check priorities**: Review [DEVELOPMENT_MATRIX.md](DEVELOPMENT_MATRIX.md) for current work
3. **Read project docs**: See [projects/{repo}/README.md](projects/) for repo-specific guidelines
4. **Follow code styles**: See [codestyles/](codestyles/) for language-specific conventions

---

## 📁 Directory Structure

```
.agents/
├── README.md                  # This file
├── DEVELOPMENT_MATRIX.md      # Central tracking table (priority, difficulty, status)
├── ROADMAP.md                 # High-level milestones
├── status.json                # Environment status for coordination
├── NOTES.md                   # Lessons learned and saved development knowledge
├── TECHNICAL_DEBT.md          # Quick-capture technical debt scratchpad
├── backlog/                   # Detailed plans per development item
├── codestyles/                # Language-specific code style guides
│   ├── python.md
│   ├── jax.md                 # ⚠️ Critical for avoiding recompilation
│   ├── rust.md
│   └── general.md             # Cross-language AI agent practices
├── projects/                  # Per-repository documentation
│   ├── prxteinmpnn/
│   ├── proxide/
│   ├── prolix/
│   ├── trex/
│   └── proteinsmc/
├── prompts/                   # Agent prompts
│   ├── reuse/                 # Reusable prompt templates
│   └── YYMMDD/                # Dated prompt batches
├── references/                # External reference documents and best practices
│   ├── testing/               # Testing-related references
│   ├── performance/           # Performance optimization references
│   ├── jax/                   # JAX-specific references
│   └── architecture/          # Architecture and design references
├── templates/                 # Document templates
│   ├── agent_prompt.md        # NEW: Template for detailed agent dispatch
│   ├── backlog_item.md
│   ├── project_readme.md
│   ├── prompt_batch.md
│   ├── reference_document.md  # Template for reference documents
│   └── reusable_prompt.md
└── archive/                   # Completed work
```

---

## 📋 Development Tracking

### DEVELOPMENT_MATRIX.md

Central table with **Priority**, **Difficulty**, and **Status** for all items:

| Priority | Difficulty | Item | Status |
|:---------|:-----------|:-----|:-------|
| High | 🔴 Complex | Example Item | 🟡 In Progress |

**Difficulty levels** (for agent dispatch):

- 🔴 **Complex**: Requires careful planning, likely debugging
- 🟡 **Intricate**: Many parts, but well-specified tasks
- 🟢 **Easy Win**: Straightforward, minimal ambiguity

**Agents must update this matrix** when completing work or changing status.

### ROADMAP.md

High-level quarterly milestones. Update at major milestone completions.

### NOTES.md

Captures individual lessons learned, specialized domain knowledge, and "gotchas" discovered during development. This serves as a raw knowledge base to be periodically distilled into [codestyles/](codestyles/) or a future structured knowledge system.

---

## 💻 Agent Workflow

### Before Work

1. Check `status.json` - mark GPU as in-use if needed
2. Review `DEVELOPMENT_MATRIX.md` for priorities
3. Read `projects/{repo}/README.md` for project conventions
4. Review relevant `backlog/` item for context

### During Work

- Follow [codestyles/](codestyles/) - especially [jax.md](codestyles/jax.md) for JAX code
- Use `uv run` for all Python commands - **Execute from base directory (workspace root)** to ensure correct environment
- Wrap long commands with `timeout`

### After Work

1. Update `DEVELOPMENT_MATRIX.md` with progress
2. Update `status.json` - release GPU if held
3. Update backlog item with notes/completions

---

## 📝 Prompts System

### Reusable Prompts

Store reusable prompt templates in `prompts/reuse/`:

- Fill placeholders like `{PROJECT}`, `{FILE}`
- Use for common recurring tasks

### Dated Prompt Batches

Staged execution of prompt sets in `prompts/YYMMDD/`:

- Each folder has a `README.md` listing prompts with status (use [prompt_batch.md](templates/prompt_batch.md))
- Individual prompts should follow the [agent_prompt.md](templates/agent_prompt.md) structure
- Mark prompts complete as they're executed
- When all complete, mark README status as "✅ All Complete"
- Archive-ready folders can be moved to `archive/`

---

## 📚 References System

The `references/` directory maintains a curated collection of external documentation, best practices, and technical resources that inform development decisions.

### Structure

References are organized by category:

- `testing/` - Testing frameworks, strategies, and optimization guides
- `performance/` - Performance profiling, optimization techniques
- `jax/` - JAX-specific patterns, gotchas, and best practices
- `architecture/` - System design, architectural patterns

### Creating Reference Documents

Use [templates/reference_document.md](templates/reference_document.md) to capture:

1. **Source and metadata** - URL, date added, category
2. **Summary** - Key points from the reference
3. **Takeaways** - Specific insights and recommendations
4. **Implementation notes** - How it applies to our codebase
5. **Related items** - Links to backlog items or other references

### When to Add a Reference

Add a reference document when:

- You discover a valuable external resource that influences design decisions
- A best practices guide is referenced multiple times in conversations
- External documentation clarifies a complex technical concept
- A performance optimization technique should be standardized across repos

**Example**: The [awesome-pytest-speedup](https://github.com/zupo/awesome-pytest-speedup) guide would be documented in `references/testing/pytest_speedup.md` with specific notes on which practices apply to our test suites.

---

## 🔗 Project Map

| Package | Purpose | Docs |
|:--------|:--------|:-----|
| **PrxteinMPNN** | Sequence design model | [projects/prxteinmpnn/](projects/prxteinmpnn/) |
| **proxide** | I/O + physics bridging | [projects/proxide/](projects/proxide/) |
| **prolix** | MD simulations | [projects/prolix/](projects/prolix/) |
| **proteinsmc** | SMC sampling | [projects/proteinsmc/](projects/proteinsmc/) |
| **trex** | Differentiable phylogenetics | [projects/trex/](projects/trex/) |

---

## 🔗 Dependency Graph

```
proteinsmc                           trex
    └─▶ PrxteinMPNN                    │ (standalone)
            ├─▶ proxide (I/O, force fields)
            └─▶ prolix (physics calculations)
                    └─▶ proxide (AtomicSystem, OpenMM export)
                            └─▶ oxidize (Rust extension)
```

**Key insight**: `proxide` is foundational - changes ripple to all packages.

---

## 📝 Documentation Standards

- **Prefer docstrings over inline comments** - Explanations belong in docstrings; inline comments should be minimal.
- **Large scale notes** - Use `NOTES:` prefix within docstrings for extensive details.
- **Mathematical implementations** - Explain step-by-step, include array shapes, and use MathJax for notation.

---

## 📚 See Also

- [/AGENTS.md](../AGENTS.md) - Coding standards and JAX idioms
- [/README.md](../README.md) - Project overview
