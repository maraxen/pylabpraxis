# References Directory

This directory maintains a curated collection of external documentation, best practices, and technical resources that inform development decisions across the unified protein design ecosystem.

---

## Purpose

The references system serves to:

1. **Centralize knowledge** - Capture valuable external resources in one location
2. **Provide context** - Document why a resource is relevant and how it applies to our codebase
3. **Enable discovery** - Make it easy for agents and developers to find relevant best practices
4. **Track implementation** - Link references to backlog items and code changes

---

## Directory Structure

```
references/
├── testing/          # Testing frameworks, strategies, and optimization
├── performance/      # Performance profiling and optimization techniques
├── jax/              # JAX-specific patterns, gotchas, and best practices
└── architecture/     # System design and architectural patterns
```

---

## Creating a Reference Document

Use the template at [../templates/reference_document.md](../templates/reference_document.md):

```bash
cp .agents/templates/reference_document.md .agents/references/{category}/{name}.md
```

Then fill in:

1. **Metadata** - Source URL, date, category, relevance
2. **Summary** - 1-2 paragraph overview of key points
3. **Key Takeaways** - Specific, actionable insights
4. **Applicable To** - Which repositories/areas this affects
5. **Implementation Notes** - How to apply this in our codebase
6. **Examples** - Code snippets demonstrating application
7. **Related Items** - Links to backlog items, other references

---

## When to Add a Reference

Add a reference document when:

- ✅ You discover a valuable external resource that influences design decisions
- ✅ A best practices guide is referenced multiple times in conversations
- ✅ External documentation clarifies a complex technical concept
- ✅ A performance optimization technique should be standardized across repos
- ✅ An architectural pattern from external sources is being adopted

**Don't add** references for:

- ❌ One-off Stack Overflow answers (capture in code comments instead)
- ❌ Official API documentation (link directly in docstrings)
- ❌ Temporary workarounds or hacks

---

## Current References

### Testing

- [pytest_speedup.md](testing/pytest_speedup.md) - Comprehensive pytest optimization guide from awesome-pytest-speedup

### Performance

*No references yet*

### JAX

*No references yet*

### Architecture

*No references yet*

---

## Maintenance

- **Review quarterly** - Check if references are still relevant and up-to-date
- **Archive outdated** - Move superseded references to `../archive/references/`
- **Update links** - Verify external URLs are still valid
- **Cross-reference** - Ensure backlog items link to relevant references
