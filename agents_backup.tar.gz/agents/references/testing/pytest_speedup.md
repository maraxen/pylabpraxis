# Awesome pytest speedup

**Source**: <https://github.com/zupo/awesome-pytest-speedup>  
**Date Added**: 2026-01-08  
**Category**: Testing  
**Relevance**: Provides comprehensive best practices for optimizing pytest execution speed across all repositories in the workspace

---

## Summary

The awesome-pytest-speedup guide is a curated checklist of best practices to speed up pytest test suites. It covers multiple optimization strategies including hardware utilization, collection optimization, parallelization, and test isolation. The guide emphasizes a "measure first" approach using tools like `hyperfine`, `pytest --durations`, and profilers to validate improvements before committing changes.

Key areas covered include: hardware optimization, collection speed, environment variables (`PYTHONDONTWRITEBYTECODE`), disabling unnecessary plugins, selective test execution, network/disk access optimization, database access patterns, and parallel execution using `pytest-xdist` and `pytest-split`.

---

## Key Takeaways

- **Measure First**: Always benchmark before and after changes using `hyperfine` for full suite timing and `pytest --durations 10` for identifying slow tests
- **Parallel Execution**: Use `pytest-xdist` to leverage multiple CPU cores locally; use `pytest-split` for CI parallelization across multiple workers
- **Environment Variables**: Set `PYTHONDONTWRITEBYTECODE=1` to avoid .pyc file generation overhead
- **Collection Optimization**: Minimize imports during collection phase; disable unnecessary built-in plugins
- **Test Isolation**: Optimize database fixtures to avoid redundant setup; consider session-scoped fixtures with proper cleanup
- **Profiling**: Use `pytest-profiling`, `pytest-monitor`, or `pyinstrument` for detailed performance analysis

---

## Applicable To

- [x] PrxteinMPNN
- [x] proxide
- [x] prolix
- [x] proteinsmc
- [x] trex
- [x] projects/asr
- [x] CI/CD
- [x] General development practices

---

## Implementation Notes

### Current State

Test suites across all repositories currently run sequentially on a single CPU core. No standardized pytest configuration exists across repositories.

### Recommended Implementation

1. **Add pytest-xdist to all repositories**:

   ```toml
   [project.optional-dependencies]
   dev = [
       "pytest-xdist",
       # ... other dev dependencies
   ]
   ```

2. **Configure pytest.ini or pyproject.toml**:

   ```ini
   [tool.pytest.ini_options]
   addopts = [
       "-n", "auto",  # Use all available CPU cores
       "--durations=10",  # Show 10 slowest tests
   ]
   ```

3. **Set environment variables in CI**:

   ```yaml
   env:
     PYTHONDONTWRITEBYTECODE: 1
   ```

4. **Profile slow tests**:

   ```bash
   pytest --durations=0 --durations-min=1.0
   ```

### Caveats for JAX Codebases

- JAX compilation caching may interact with parallel test execution
- Session-scoped fixtures that initialize JAX devices need special handling with `pytest-xdist`
- Consider using `pytest-xdist`'s `--dist=loadscope` to keep tests from the same module on the same worker

### Examples

```python
# conftest.py - Handle session-scoped fixtures with pytest-xdist
import pytest
from filelock import FileLock

@pytest.fixture(scope="session")
def shared_resource(tmp_path_factory, worker_id):
    if worker_id == "master":
        # Not running with pytest-xdist
        return setup_resource()
    
    # Running with pytest-xdist
    root_tmp_dir = tmp_path_factory.getbasetemp().parent
    fn = root_tmp_dir / "resource.json"
    
    with FileLock(str(fn) + ".lock"):
        if fn.is_file():
            return load_resource(fn)
        else:
            resource = setup_resource()
            save_resource(resource, fn)
            return resource
```

---

## Related References

- [pytest-xdist documentation](https://pytest-xdist.readthedocs.io/)
- [pytest-split documentation](https://jerry-git.github.io/pytest-split/)
- [pytest profiling guide](https://docs.pytest.org/en/stable/how-to/profiling.html)

---

## Related Backlog Items

- Technical Debt: Pytest Optimization (see [TECHNICAL_DEBT.md](../TECHNICAL_DEBT.md))

---

## Notes

### Priority Actions

1. **Immediate wins** (low effort, high impact):
   - Add `PYTHONDONTWRITEBYTECODE=1` to CI environments
   - Run `pytest --durations=10` to identify slowest tests in each repo
   - Add `pytest-xdist` to dev dependencies

2. **Medium-term improvements**:
   - Refactor slow tests identified by profiling
   - Optimize database fixtures for test isolation
   - Configure `pytest-xdist` with appropriate distribution strategy

3. **Advanced optimizations**:
   - Implement `pytest-split` for CI parallelization
   - Add `pytest-monitor` for continuous performance tracking
   - Profile with `pyinstrument` or `cProfile` for detailed optimization

### Measurement Strategy

Before implementing any optimization:

1. Baseline current test suite execution time
2. Implement single change
3. Measure locally and on CI
4. Commit if improvement is measurable
5. Monitor for a few days to ensure stability
