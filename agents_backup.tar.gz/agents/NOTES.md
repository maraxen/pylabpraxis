# Development Notes

This file captures raw lessons learned, specialized domain knowledge, and "gotchas" discovered during the development process.

**Note to Agents:** Use this file to save knowledge that might be useful for future tasks but isn't yet ready to be codified into [codestyles/](codestyles/). Items here are periodically distilled into the formal documentation system.

---

## 📅 2026-01-07

- (Add your first note here)
- **Docstrings with MathJax**: Always use raw strings (`r"""..."""`) for docstrings containing MathJax/LaTeX to prevent invalid escape sequence warnings (D301).
- **JAX JIT and dtypes**: When passing `jnp.dtype` objects to a JIT-compiled function, they must be marked as `static_argnums` or `static_argnames`. Otherwise, JAX will try to trace them as abstract arrays, leading to a `TypeError: Error interpreting argument as an abstract array`.
- Mixed precision for TREX is functional. Added `jax_log_compiles=1` to detect recompilation.
- JIT static arguments for dtypes are working in `nk_model.py`.

## 📅 2026-01-09

- **2026-01-09**: Completed workspace-wide type hint migration to `jaxtyping`. Defined central `Scalar`, `ScalarFloat`, `PRNGKey`, and `ArrayLike` aliases in each repo's `types.py`.
