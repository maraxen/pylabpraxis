# AtomicSystem Refactor - Phases 1-3

## Objective

Complete the AtomicSystem hierarchical refactor by implementing Rust projection, Prolix integration, and PrxteinMPNN integration. Track progress in `.agents/tasks/ATOMIC_SYSTEM_REFACTOR.md`.

## Context

The hierarchical `AtomicSystem` structure is already implemented:

- `MolecularTopology`, `AtomicState`, `AtomicConstants` in `proxide/core/atomic_system.py`
- `MPNNBatch` dataclass in `proxide/core/projector.py`
- `Protein` decoupled from `AtomicSystem` in `proxide/core/containers.py`

Core proxide tests pass (11/11). Now integrate across the stack.

---

## Phase 1: Rust Projection (oxidize)

Implement `project_to_mpnn_batch()` in `oxidize/src/formats/protein.rs`:

1. Filter atoms by `molecule_type == 0` (protein only)
2. Group by `residue_index` → extract backbone atoms (N, CA, C, O)
3. Compute RBF features using existing `radial_basis.rs`
4. Compute physics features from charges/sigmas/epsilons
5. **Critical**: Ensure feature order matches PrxteinMPNN expectations

Wire the function to Python via PyO3 bindings in `_oxidize.pyi`.

## Phase 2: Prolix Integration

Update `prolix/simulate.py` to accept separate PyTree arguments:

```python
# New signature:
simulate(topology: MolecularTopology, state: AtomicState, constants: AtomicConstants, ...)
```

This enables efficient vmap:

```python
batched_simulate = jax.vmap(simulate, in_axes=(None, 0, None, 0))
```

Topology/constants stay static, only state replicates → memory savings.

## Phase 3: PrxteinMPNN Integration

1. Update `proxide/ops/transforms.py`:
   - `pad_and_collate_proteins()` → output `MPNNBatch`
   - `_pad_protein()` → `_pad_mpnn_batch()`

2. Update dataloader to produce `MPNNBatch` directly

3. Update `trainer.py` to consume `MPNNBatch`

4. Find all `Protein` iterator usages and migrate to `MPNNBatch`

---

## Verification

Run tests (no multiprocessing to avoid server crashes):

```bash
cd /home/marielle/united_workspace

# Proxide
uv run pytest proxide/tests/ -v --tb=short

# PrxteinMPNN
uv run pytest PrxteinMPNN/tests/ -v --tb=short -x

# Prolix
uv run pytest prolix/tests/ -v --tb=short
```

All tests must pass.

---

## On Completion

Update `.agents/tasks/ATOMIC_SYSTEM_REFACTOR.md` marking Phases 1-3 complete.

Then respond in chat with

 the prompt for Phase 4:
> **Phase 4 - ArrayRecord Regeneration**: Regenerate PDB sample ArrayRecord with new MPNNBatch format, regenerate full training dataset, upload updated ArrayRecord and JSONL index to HuggingFace Hub.
