# Agent Prompt: 04_jax_scatter_warning

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started  
**Batch:** [260109](../260109/README.md)  
**Backlog:** [jax_scatter_warning.md](../../backlog/jax_scatter_warning.md)  

---

## Task

Investigate and resolve a `FutureWarning` in JAX related to incompatible types in `scatter` operations.

### Warning Message

```
/home/marielle/united_workspace/.venv/lib/python3.13/site-packages/jax/_src/ops/scatter.py:104: 
FutureWarning: scatter inputs have incompatible types: cannot safely cast value from dtype=float32 
to dtype=int32 with jax_numpy_dtype_promotion=standard. In future JAX releases this will result in an error.
```

### Investigation Steps

1. **Identify Root Cause**: Locate the specific call to `jax.lax.scatter` or wrapping functions (like `.at[].set()`, `jnp.where`) that triggers this warning
2. **Search patterns**: Look for:
   - Array indexing with `.at[indices].set(values)` where types mismatch
   - `jnp.where(condition, float_values, int_array)`
   - Any `scatter` operations mixing int32 targets with float32 sources
3. **Characterize Casting Error**: Determine why a `float32` value is being cast to an `int32` target
4. **Update Implementation**: Correct the types to ensure compatibility

### Likely Locations

Search these files/patterns first:

- `trex/src/trex/` - Core phylogenetics code
- `projects/asr/src/asr/` - ASR implementation
- Any file using `.at[].set()` with potentially mismatched types

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [jax_scatter_warning.md](../../backlog/jax_scatter_warning.md) | Work item tracking |
| [codestyles/jax.md](../../codestyles/jax.md) | JAX best practices |

---

## Project Conventions

- **Commands**: Use `uv run` from workspace root for all Python commands
- **Search**: Use `grep -r "\.at\[" trex/src/ projects/asr/src/` to find scatter patterns
- **Testing**: `uv run pytest trex/tests/ -v` and `uv run pytest projects/asr/tests/ -v`

---

## Verification

1. Run existing tests and scripts to reproduce the warning:

   ```bash
   uv run python projects/asr/scripts/nk_sweep.py --n-vals 50 --k-vals 2 --mutation-rate 0.01
   ```

2. After fix, confirm the warning no longer appears
3. Run tests to ensure no regressions: `uv run pytest trex/tests/ projects/asr/tests/ -v`

---

## On Completion

- [ ] Update backlog item status to ✅ Complete
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md) - move to Completed Items
- [ ] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [JAX DType Promotion JEP](https://jax.readthedocs.io/en/latest/jep/9407-type-promotion.html)
