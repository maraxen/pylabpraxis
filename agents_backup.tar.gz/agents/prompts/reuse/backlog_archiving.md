# Reusable Prompt: Backlog Archiving

Examine .agents/README.md for development context.

**Purpose:** Consolidate completed work, archive backlog items, and clean up development matrix  
**Use when:** End of sprint, quarterly cleanup, or when backlog has accumulated completed items

---

## Prompt

```markdown
Examine .agents/README.md for development context.

## Task

Review completed work, archive backlog items, and clean up the development matrix.

## Instructions

1. **Review Current State**:
   - [DEVELOPMENT_MATRIX.md](.agents/DEVELOPMENT_MATRIX.md) - Identify ✅ Complete or 🟡 In Progress items that are finished
   - [backlog/](.agents/backlog/) - Review item statuses

2. **Identify Items for Archiving**: Collect items that:
   - Are marked ✅ Complete in the matrix
   - Have all checkboxes completed in their backlog file
   - Have been verified and validated

3. **Archive Process**: For each completed item:
   - Move backlog file from `backlog/` to `archive/`
   - Update any internal links in the archived file
   - Move row from "Active Items" to "Completed Items" in DEVELOPMENT_MATRIX.md
   - Add completion date

4. **Consolidate Related Items**: If multiple completed items belong to the same initiative:
   - Create a consolidated archive document summarizing the work
   - Reference individual archived items
   - Update ROADMAP.md to mark milestone as complete if applicable

5. **Archive Old Prompts Directories**: Review `prompts/` for batch directories ready for archiving:
   - Identify prompt batch directories (e.g., `260107/`) where ALL prompts are marked ✅ Complete
   - Verify the batch README.md shows all items completed
   - Move the entire batch directory to `archive/prompts/`
   - Preserve the directory name for historical reference (e.g., `archive/prompts/260107/`)

6. **Update Ongoing Maintenance**: For health audits and recurring items:
   - Update "Last Review" dates in the matrix
   - Reset checkboxes for next review cycle if needed

7. **Ask for clarification and specification** on:
   - Items with ambiguous completion status
   - Whether partial completions should be archived or kept active
   - Consolidation groupings for related items
   - Whether to create summary docs for major milestones
   - Whether prompts batches with some incomplete items should wait or be partially archived

## Output

Provide:
- List of items archived
- List of prompts batch directories archived (moved to `archive/prompts/`)
- Updates to DEVELOPMENT_MATRIX.md (moved to Completed)
- Updates to ROADMAP.md (milestones marked complete)
- Any consolidation documents created
```

---

## Customization

No placeholders required. Run as-is for standard archive review.

---

## Decision Guidelines

Default behaviors for common archiving scenarios. Apply these unless the user specifies otherwise:

### Unchecked Tasks in Completed Items

If an item is marked ✅ Complete in the matrix but has unchecked tasks in the backlog file:

- **Default**: Update checkboxes to reflect actual completion (the matrix is the source of truth)
- Add a note if tasks were skipped or deemed unnecessary

### Matrix/Backlog Status Discrepancies

If the matrix and backlog file show different statuses:

- **Default**: The matrix is the source of truth; sync the backlog status to match
- Update the backlog's `**Status:**` field and mark tasks accordingly

### Partial Prompt Batch Archiving

If a prompt batch has some completed and some incomplete prompts:

- **Default**: Partially archive - move completed prompts to `archive/prompts/{batch}/`
- Keep incomplete prompts in `prompts/{batch}/`
- Update batch README to reflect partial archive status

### Consolidation Documents

When multiple completed items share a theme or milestone:

- **Default**: Create a consolidated archive document summarizing the body of work
- Reference individual archived items
- Good candidates: items completed within the same time period sharing a category (e.g., "Code Quality", "Infrastructure")

### Completed "Ongoing" Items on ROADMAP

For items listed under "Ongoing Maintenance" that are now complete:

- **Default**: Move to "Completed" section with completion date
- Extract recurring elements into maintenance prompts (in `prompts/reuse/maintenance/`)
- Update "Ongoing Maintenance" section to reference maintenance prompts instead

### Maintenance Prompt Extraction

When completing infrastructure/quality items that should be repeated:

- **Default**: Create reusable maintenance prompts in `prompts/reuse/maintenance/`
- Categories include: type checking, linting, docstrings, CI review, docs audit, test coverage, dependency audit, security audit, performance checks

---

## Example Usage

```markdown
Examine .agents/README.md for development context.

## Task

Review completed work, archive backlog items, and clean up the development matrix.

[... full prompt as above ...]
```
