# Reusable Prompts

This directory contains reusable prompt templates for common tasks.

## Usage

1. Copy the relevant prompt template
2. Fill in placeholders (e.g., `{PROJECT}`, `{FILE}`)
3. Dispatch to an agent

## Available Prompts

| Prompt | Purpose |
|:-------|:--------|
| [add_tests.md](add_tests.md) | Add tests for a module |
| [refactor_module.md](refactor_module.md) | Refactor a module following conventions |

---

See [templates/reusable_prompt.md](../../templates/reusable_prompt.md) for the template format.
