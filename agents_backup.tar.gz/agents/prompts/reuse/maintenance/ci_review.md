# Maintenance Prompt: CI Pipeline Review

**Purpose:** Review and update CI/CD pipeline configuration  
**Frequency:** Quarterly  

---

## Prompt

```markdown
Examine .agents/README.md for development context.

## Task

Review CI pipelines across target repositories and ensure they meet current standards.

## Phase 1: Triage and Prioritize

1. **Count Workflow Files Per Repository**:

   Identify the scope of review for each repository:

   ```bash
   echo "=== {REPOSITORY_1} ===" && find {REPOSITORY_1}/.github/workflows -name "*.yml" 2>/dev/null | wc -l
   echo "=== {REPOSITORY_2} ===" && find {REPOSITORY_2}/.github/workflows -name "*.yml" 2>/dev/null | wc -l
   # ... repeat for all target repositories
   ```

1. **List Workflow Files**:

   ```bash
   ls -la {REPOSITORY_1}/.github/workflows/ 2>/dev/null
   ls -la {REPOSITORY_2}/.github/workflows/ 2>/dev/null
   ```

2. **Prioritize by File Count**:

   Start with the repository that has the **fewest workflow files** to build momentum and establish review patterns.

## Phase 2: Categorize and Strategize

For each repository (starting with lowest file count):

1. **Review Workflow Files (Coarse Overview)**:

   Get a quick summary of each workflow:

   ```bash
   # List jobs in each workflow
   for f in {REPOSITORY}/.github/workflows/*.yml; do
     echo "=== $f ===" 
     grep -E "^  [a-z_-]+:" "$f" | head -n 10
   done
   ```

2. **Verify Standard Jobs Exist**:

   | Job | Required | Purpose |
   |:----|:---------|:--------|
   | lint | ✅ | Ruff linting and formatting |
   | type-check | ✅ | `ty` type checking |
   | test | ✅ | pytest with coverage |
   | build | ⚠️ | Maturin build (if Rust components) |

3. **Document Findings**:

   For each repository, note:
   - Missing required jobs
   - Outdated action versions
   - Configuration issues found
   - Pre-commit integration status

4. **Get User Input**:

   ⏸️ PAUSE: Present the findings and proposed updates to the user for approval before making changes.

## Phase 3: Apply Updates

1. **Review Configuration Details** (now go deeper):
   - Python version matrix (should include 3.11, 3.12)
   - Dependency caching (uv cache, pip cache)
   - Timeout limits (reasonable for test suite)
   - Branch triggers (main, develop, PRs)

2. **Verify Pre-commit Integration**:
   - `.pre-commit-config.yaml` exists
   - Hooks match CI checks (ruff, ty)
   - CI optionally runs `pre-commit run --all-files`

3. **Review Secrets and Permissions**:
   - Minimal necessary permissions
   - Secrets referenced but not exposed
   - No hardcoded tokens or credentials

4. **Apply Updates**:
   - Bump action versions (e.g., `actions/checkout@v4`)
   - Update Python versions in matrix
   - Add missing jobs from standard list

## Phase 4: Verify and Document

1. **Verify**:

   Ensure CI configuration is valid:

   ```bash
   # Check YAML syntax
   python -c "import yaml; yaml.safe_load(open('{REPOSITORY}/.github/workflows/ci.yml'))"
   ```

   Confirm CI passes after push (manual verification via GitHub).

2. **Update Health Audit**:
   - Open `.agents/projects/{REPOSITORY}/HEALTH_AUDIT.md`
   - Update the "Other Audits" table row for "CI/CD Review"
   - Update status, date, and add notes about findings

## References

- [Health Audit Template](file:///home/marielle/united_workspace/.agents/templates/project_health_audit.md)
- [codestyles/general.md](file:///home/marielle/united_workspace/.agents/codestyles/general.md)
- GitHub Actions documentation

```

---

## Customization

| Placeholder | Description | Example |
|:------------|:------------|:--------|
| `{REPOSITORY}` | Repository to review | `proxide`, `trex` |
| `{REPOSITORY_1}`, `{REPOSITORY_2}`, etc. | Multiple repositories when running batch triage | `proxide`, `prolix`, `trex` |

---

## Workflow Summary

```

┌─────────────────────────────────────────────────────────────────┐
│ Phase 1: Triage                                                 │
│   • Count workflow files per repo                               │
│   • List workflow files                                         │
│   • Prioritize: fewest files first                              │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 2: Categorize & Strategize (per repo)                     │
│   • Coarse overview of jobs in each workflow                    │
│   • Check for required jobs                                     │
│   • ⏸️  PAUSE: Get user input before proceeding                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 3: Apply Updates                                          │
│   • Review configuration details                                │
│   • Bump action versions                                        │
│   • Add missing jobs                                            │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 4: Verify & Document                                      │
│   • Verify YAML syntax                                          │
│   • Update HEALTH_AUDIT.md                                      │
└─────────────────────────────────────────────────────────────────┘

```
