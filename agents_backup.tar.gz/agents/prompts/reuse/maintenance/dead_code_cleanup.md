# Maintenance Prompt: Dead Code Cleanup

**Purpose:** Remove unused imports, unreachable code, and deprecated features  
**Frequency:** Quarterly  

---

## Prompt

```markdown
Examine .agents/README.md for development context.

## Task

Clean up dead code in target repositories: unused imports, unreachable code, and deprecated features.

## Phase 1: Triage and Prioritize

1. **Run Dead Code Detection on All Target Repositories**:

   Use Ruff to detect unused imports and variables across repositories:

   ```bash
   uv run ruff check {REPOSITORY_1}/src/ --select=F401,F841 > dead_code_{REPOSITORY_1}.log 2>&1
   uv run ruff check {REPOSITORY_2}/src/ --select=F401,F841 > dead_code_{REPOSITORY_2}.log 2>&1
   # ... repeat for all target repositories
   ```

1. **Count Issues Per Repository**:

   ```bash
   tail -n 5 dead_code_*.log
   ```

   Look for the summary showing total violations found.

2. **Prioritize by Issue Count**:

   Start with the repository that has the **fewest issues** to build momentum and clear quick wins.

## Phase 2: Categorize and Strategize

For each repository (starting with lowest issue count):

1. **Review the Full Log**:

   ```bash
   cat dead_code_{REPOSITORY}.log | head -n 100
   ```

2. **Categorize Issues**:

   | Category | Code | Action |
   |:---------|:-----|:-------|
   | Unused imports | F401 | Remove or add `# noqa: F401` if re-export |
   | Unused variables | F841 | Remove or prefix with `_` |
   | Commented-out code | Manual | Remove (it's in git history) |
   | Deprecated features | Manual | Check if deprecation period passed |
   | Unused functions | Manual | Verify not part of public API |

3. **Identify Additional Dead Code** (manual search):

   ```bash
   # Search for commented-out code blocks
   rg "^#.*def |^#.*class |^# .*=" {REPOSITORY}/src/ | head -n 30
   
   # Search for deprecation markers
   rg -i "@deprecated|# TODO: remove|# DEPRECATED" {REPOSITORY}/src/ | head -n 20
   ```

4. **Document Strategy**:

   Before applying fixes, summarize:
   - Count of each issue category
   - Files with most dead code
   - Any patterns (e.g., "old utility module no longer used")

5. **Get User Input**:

   ⏸️ PAUSE: Present the categorization and strategy to the user for approval before proceeding with cleanup.

## Phase 3: Apply Fixes

1. **Unused Imports**:
   - Remove unused imports
   - Keep intentional re-exports (add `# noqa: F401` or use `__all__`)

2. **Unused Variables**:
   - Remove or prefix with `_` if intentionally unused
   - Check if variable should actually be used (bug)

3. **Unreachable Code**:
   - Look for code after `return`, `raise`, `break`, `continue`
   - Check for conditions that are always True/False
   - Review `if False:` or `if True:` guards

4. **Commented-Out Code**:
   - Remove commented-out code blocks
   - Exception: commented alternatives with explanation

5. **Deprecated Features**:
   - Search for `@deprecated` decorators
   - Check for `# TODO: remove`, `# DEPRECATED` comments
   - Review if deprecation period has passed

6. **Unused Functions/Classes**:
   - Identify functions not called anywhere
   - Check if they're part of public API (should keep)
   - Consider if they're used by external code

7. **Stale Test Files**:
   - Tests for removed functionality
   - Skipped tests that should be fixed or removed
   - Test utilities no longer used

## Phase 4: Verify and Document

1. **Verify Changes**:

   ```bash
   uv run pytest {REPOSITORY}/tests/ -v 2>&1 | tail -n 20
   uv run ty check {REPOSITORY}/src/ 2>&1 | tail -n 5
   uv run ruff check {REPOSITORY}/src/ --select=F401,F841 --quiet
   ```

2. **Update Health Audit**:
   - Open `.agents/projects/{REPOSITORY}/HEALTH_AUDIT.md`
   - Update the "Other Audits" table row for "Dead Code"
   - Update status, date, and add notes about findings

## Output

- Files cleaned
- Lines/functions removed
- Any concerns about removal (might be used externally)

## References

- [Health Audit Template](file:///home/marielle/united_workspace/.agents/templates/project_health_audit.md)
- [codestyles/python.md](file:///home/marielle/united_workspace/.agents/codestyles/python.md)

```

---

## Customization

| Placeholder | Description | Example |
|:------------|:------------|:--------|
| `{REPOSITORY}` | Repository to clean | `proxide`, `trex` |
| `{REPOSITORY_1}`, `{REPOSITORY_2}`, etc. | Multiple repositories when running batch triage | `proxide`, `prolix`, `trex` |

---

## Workflow Summary

```

┌─────────────────────────────────────────────────────────────────┐
│ Phase 1: Triage                                                 │
│   • Run ruff --select=F401,F841 on all repos → capture to logs  │
│   • Count issues per repo                                       │
│   • Prioritize: fewest issues first                             │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 2: Categorize & Strategize (per repo)                     │
│   • Review log, categorize by issue type                        │
│   • Manual search for additional dead code                      │
│   • ⏸️  PAUSE: Get user input before proceeding                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 3: Apply Fixes                                            │
│   • Remove unused imports/variables                             │
│   • Clean commented-out code                                    │
│   • Remove deprecated features past retention                   │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 4: Verify & Document                                      │
│   • Run tests and type check                                    │
│   • Update HEALTH_AUDIT.md                                      │
└─────────────────────────────────────────────────────────────────┘

```
