# Maintenance Prompt: Performance Audit

**Purpose:** Check for performance regressions and optimization opportunities  
**Frequency:** As needed (before releases, after major changes)  

---

## Prompt

```markdown
Examine .agents/README.md for development context.

## Task

Audit performance across target repositories, focusing on JAX compilation and runtime efficiency.

## Phase 1: Triage and Prioritize

1. **Count Source Files Per Repository**:

   Identify the scope of review for each repository:

   ```bash
   echo "=== {REPOSITORY_1} ===" && find {REPOSITORY_1}/src -name "*.py" 2>/dev/null | wc -l
   echo "=== {REPOSITORY_2} ===" && find {REPOSITORY_2}/src -name "*.py" 2>/dev/null | wc -l
   # ... repeat for all target repositories
   ```

1. **Identify JAX-Heavy Modules**:

   ```bash
   # Count jax imports per file to identify compute-intensive modules
   for repo in {REPOSITORY_1} {REPOSITORY_2}; do
     echo "=== $repo ==="
     grep -r "import jax\|from jax" $repo/src/ -l 2>/dev/null | wc -l
   done
   ```

2. **Prioritize by File Count**:

   Start with the repository that has the **fewest JAX-heavy files** to build momentum and identify common patterns.

## Phase 2: Categorize and Strategize

For each repository (starting with lowest file count):

1. **Check for Known Hotspots**:

   ```bash
   # Check if hotspot documentation exists
   cat .agents/projects/{REPOSITORY}/RECOMPILATION_HOTSPOTS.md 2>/dev/null | head -n 30
   
   # Search for performance-related TODOs
   rg -n "TODO.*perf|FIXME.*slow|# slow|# optimize" {REPOSITORY}/src/ | head -n 15
   ```

2. **Identify Recompilation Triggers**:

   | Pattern | Issue | Fix |
   |:--------|:------|:----|
   | Dynamic shapes | Shape changes cause recompile | Use padding/masking |
   | Python control flow | Traced differently each time | Use `jax.lax.cond` |
   | Non-static arguments | Different values = different trace | Mark static with `static_argnums` |

3. **Document Strategy**:

   Summarize:
   - Known hotspots from documentation
   - Potential issues found in code search
   - Priority areas to investigate

4. **Get User Input**:

   ⏸️ PAUSE: Present the findings and investigation strategy to the user for approval before profiling.

## Phase 3: Apply Fixes

1. **JAX Compilation Check**:

   Enable compilation logging and run critical code paths:

   ```python
   import jax
   jax.config.update("jax_log_compiles", True)
   # Run critical code paths
   ```

2. **Memory Profiling** (if needed):

   ```python
   import jax
   jax.profiler.start_trace("/tmp/jax-trace")
   # ... run code ...
   jax.profiler.stop_trace()
   ```

3. **Benchmark Critical Paths**:
   - Identify the most frequently called functions
   - Time with `timeit` or `jax.block_until_ready()`
   - Compare against baseline if available

4. **Review Vectorization**:
   - Check for Python loops that could be `vmap`
   - Verify `vmap` is used correctly (not over-vmapping)
   - Consider `pmap` for multi-device workloads

5. **Optimization Opportunities**:
   - Unused computation (computed but not used)
   - Redundant operations (computed multiple times)
   - Suboptimal dtype (float64 when float32 suffices)

## Phase 4: Verify and Document

1. **Verify Fixes**:

   ```bash
   # Ensure optimizations don't break tests
   uv run pytest {REPOSITORY}/tests/ -v 2>&1 | tail -n 20
   ```

2. **Update Documentation**:
   - Update `.agents/projects/{REPOSITORY}/RECOMPILATION_HOTSPOTS.md` if exists
   - Document new findings and fixes

3. **Update Health Audit**:
   - Open `.agents/projects/{REPOSITORY}/HEALTH_AUDIT.md`
   - Update the "Other Audits" table row for "Performance"
   - Update status, date, and add notes about findings

## Output

- Recompilation triggers found
- Memory usage summary
- Performance improvements applied
- Updated hotspot documentation

## References

- [Health Audit Template](file:///home/marielle/united_workspace/.agents/templates/project_health_audit.md)
- [codestyles/jax.md](file:///home/marielle/united_workspace/.agents/codestyles/jax.md)
- [JAX profiling docs](https://jax.readthedocs.io/en/latest/profiling.html)

```

---

## Customization

| Placeholder | Description | Example |
|:------------|:------------|:--------|
| `{REPOSITORY}` | Repository to audit | `proxide`, `trex` |
| `{REPOSITORY_1}`, `{REPOSITORY_2}`, etc. | Multiple repositories when running batch triage | `proxide`, `prolix`, `trex` |

---

## Workflow Summary

```

┌─────────────────────────────────────────────────────────────────┐
│ Phase 1: Triage                                                 │
│   • Count source files per repo                                 │
│   • Identify JAX-heavy modules                                  │
│   • Prioritize: fewest files first                              │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 2: Categorize & Strategize (per repo)                     │
│   • Check for known hotspots                                    │
│   • Search for performance TODOs                                │
│   • ⏸️  PAUSE: Get user input before profiling                   │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 3: Apply Fixes                                            │
│   • Enable compilation logging                                  │
│   • Profile and benchmark                                       │
│   • Apply optimizations                                         │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 4: Verify & Document                                      │
│   • Run tests to verify fixes                                   │
│   • Update RECOMPILATION_HOTSPOTS.md                            │
│   • Update HEALTH_AUDIT.md                                      │
└─────────────────────────────────────────────────────────────────┘

```
