# Maintenance Prompt: Security Audit

**Purpose:** Basic security review for code and configuration  
**Frequency:** Quarterly  

---

## Prompt

```markdown
Examine .agents/README.md for development context.

## Task

Perform a basic security audit across target repositories.

## Phase 1: Triage and Prioritize

1. **Count Files to Review Per Repository**:

   Identify the scope of review for each repository:

   ```bash
   echo "=== {REPOSITORY_1} ===" && find {REPOSITORY_1}/src -name "*.py" 2>/dev/null | wc -l
   echo "=== {REPOSITORY_2} ===" && find {REPOSITORY_2}/src -name "*.py" 2>/dev/null | wc -l
   # ... repeat for all target repositories
   ```

1. **Quick Secret Detection Scan**:

   ```bash
   # Search for common secret patterns
   for repo in {REPOSITORY_1} {REPOSITORY_2}; do
     echo "=== $repo ==="
     grep -rn "api_key\|secret\|password\|token\|credential" $repo/src/ --include="*.py" 2>/dev/null | wc -l
   done
   ```

2. **Prioritize by File Count**:

   Start with the repository that has the **fewest files** to build momentum and establish security review patterns.

## Phase 2: Categorize and Strategize

For each repository (starting with lowest file count):

1. **Detailed Secret Detection**:

   ```bash
   # Search for hardcoded secrets, API keys, tokens
   grep -rn "api_key\|secret\|password\|token\|credential" {REPOSITORY}/src/ --include="*.py" | head -n 20
   
   # Search for common secret patterns
   grep -rn "sk-\|pk_\|AKIA" {REPOSITORY}/ --include="*.py" --include="*.yml" | head -n 10
   ```

2. **Categorize Security Concerns**:

   | Category | Pattern | Severity |
   |:---------|:--------|:---------|
   | Hardcoded secrets | API keys, tokens in code | Critical |
   | Exposed env vars | Secrets logged or printed | High |
   | Unsafe deserialization | `pickle.load` from untrusted | High |
   | Path traversal | User input in file paths | Medium |
   | Overly permissive files | 777/666 permissions | Medium |

3. **Document Findings**:

   Summarize:
   - Issues found by severity
   - Files requiring review
   - Configuration concerns

4. **Get User Input**:

   ⏸️ PAUSE: Present the security findings and remediation strategy to the user for approval before making changes.

## Phase 3: Apply Fixes

1. **Environment Variable Usage**:
   - Secrets should come from environment variables
   - Check `.env.example` doesn't contain real values
   - Verify `.gitignore` excludes `.env` files

2. **File Permissions**:
   - No overly permissive file modes (777, 666)
   - Scripts should be 755, not 777
   - Config files should not be world-readable

3. **Dependency Security**:
   - Run dependency audit (see dependency_audit.md)
   - Check for known vulnerabilities
   - Review new dependencies for trustworthiness

4. **Input Validation**:
   - Review file parsing for path traversal
   - Check for unsafe deserialization (pickle from untrusted sources)
   - Verify user inputs are validated

5. **CI/CD Security**:
   - Secrets are not logged
   - Minimal permissions in workflows
   - No self-hosted runners without security review

6. **Documentation**:
   - Security-relevant configuration is documented
   - Known limitations are disclosed
   - Contact for security issues is provided

## Phase 4: Verify and Document

1. **Re-run Secret Detection**:

   ```bash
   grep -rn "api_key\|secret\|password\|token\|credential" {REPOSITORY}/src/ --include="*.py" | head -n 10
   ```

2. **Update Health Audit**:
   - Open `.agents/projects/{REPOSITORY}/HEALTH_AUDIT.md`
   - Update the "Other Audits" table row for "Security"
   - Update status, date, and add notes about findings

## Output

- Issues found (categorized by severity)
- Fixes applied
- Recommendations for future

## References

- [Health Audit Template](file:///home/marielle/united_workspace/.agents/templates/project_health_audit.md)
- OWASP guidelines
- GitHub security best practices

```

---

## Customization

| Placeholder | Description | Example |
|:------------|:------------|:--------|
| `{REPOSITORY}` | Repository to audit | `proxide`, `trex` |
| `{REPOSITORY_1}`, `{REPOSITORY_2}`, etc. | Multiple repositories when running batch triage | `proxide`, `prolix`, `trex` |

---

## Workflow Summary

```

┌─────────────────────────────────────────────────────────────────┐
│ Phase 1: Triage                                                 │
│   • Count files per repo                                        │
│   • Quick secret detection scan                                 │
│   • Prioritize: fewest files first                              │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 2: Categorize & Strategize (per repo)                     │
│   • Detailed secret detection                                   │
│   • Categorize by severity                                      │
│   • ⏸️  PAUSE: Get user input before proceeding                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 3: Apply Fixes                                            │
│   • Move secrets to env vars                                    │
│   • Fix permissions                                             │
│   • Address input validation                                    │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 4: Verify & Document                                      │
│   • Re-run secret detection                                     │
│   • Update HEALTH_AUDIT.md                                      │
└─────────────────────────────────────────────────────────────────┘

```
