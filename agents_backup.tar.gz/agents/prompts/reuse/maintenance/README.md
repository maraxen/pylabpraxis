# Maintenance Prompts

Reusable prompts for recurring repository health checks and maintenance tasks.

---

## Overview

These prompts are designed for periodic execution across all repositories. Run them as part of regular health audits or when specific issues are detected.

**All prompts follow a standardized four-phase workflow:**

```
┌─────────────────────────────────────────────────────────────────┐
│ Phase 1: Triage                                                 │
│   • Run checks across ALL target repositories                   │
│   • Capture output to log files                                 │
│   • Use tail to get counts (limit context flooding)             │
│   • Prioritize: fewest issues first                             │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 2: Categorize & Strategize (per repo)                     │
│   • Coarse-grained inspection (head -n 100)                     │
│   • Categorize issues by type                                   │
│   • Document fix strategy                                       │
│   • ⏸️  PAUSE: Get user input before proceeding                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 3: Apply Fixes                                            │
│   • Execute following documented strategy                       │
│   • For tests: target specific files/submodules (no full runs)  │
│   • For manual audits: work through files systematically        │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 4: Verify & Document                                      │
│   • Verify with quiet/summary flags                             │
│   • Update HEALTH_AUDIT.md                                      │
└─────────────────────────────────────────────────────────────────┘
```

### Prioritization Strategy

| Audit Type | Prioritization Metric |
|:-----------|:----------------------|
| **Tool-based** (ruff, ty, pytest) | Fewest errors/failures first |
| **Manual inspection** (docs, security, DRY) | Fewest files to review first |

---

## Available Prompts

| Prompt | Purpose | Frequency | Type |
|:-------|:--------|:----------|:-----|
| [type_checking.md](type_checking.md) | `ty` type checking with JAX type hints | Per-audit | Tool |
| [linting.md](linting.md) | Ruff linting resolution | Per-audit | Tool |
| [test_coverage.md](test_coverage.md) | Testing coverage analysis | Per-audit | Tool |
| [docstring_audit.md](docstring_audit.md) | Docstring standardization, comment cleanup | Per-audit | Manual |
| [todo_audit.md](todo_audit.md) | Migrate TODOs to technical debt tracking | Per-audit | Hybrid |
| [ci_review.md](ci_review.md) | CI pipeline health check | Quarterly | Manual |
| [docs_audit.md](docs_audit.md) | Documentation completeness and accuracy | Quarterly | Manual |
| [dependency_audit.md](dependency_audit.md) | Dependency freshness and security | Quarterly | Tool |
| [security_audit.md](security_audit.md) | Basic security review | Quarterly | Manual |
| [performance_audit.md](performance_audit.md) | Performance regression checks | As needed | Manual |
| [dead_code_cleanup.md](dead_code_cleanup.md) | Unused code, deprecated features | Quarterly | Tool |
| [dry_audit.md](dry_audit.md) | Identify and consolidate repeated code/logic | Quarterly | Manual |

---

## Usage

### Full Health Audit

Execute all per-audit prompts for a repository:

```
Run health audit for {REPOSITORY}:
1. type_checking.md
2. linting.md
3. docstring_audit.md
4. test_coverage.md
5. todo_audit.md
```

### Quarterly Review

Add quarterly prompts to the above:

```
6. ci_review.md
7. docs_audit.md
8. dependency_audit.md
9. security_audit.md
10. dead_code_cleanup.md
11. dry_audit.md
```

### Cross-Repository Audit

For multi-repository audits, each prompt's Phase 1 supports batch triage:

```bash
# Example: Type check all repos, then work through fewest-first
uv run ty check proxide/src/ > ty_proxide.log 2>&1
uv run ty check prolix/src/ > ty_prolix.log 2>&1
uv run ty check trex/src/ > ty_trex.log 2>&1
tail -n 5 ty_*.log  # See totals
```

---

## Key Principles

1. **Limit context flooding**: Use `tail` for summaries, `head -n N` for review
2. **Fewest-first prioritization**: Build momentum with quick wins
3. **Pause for feedback**: Always get user approval before Phase 3
4. **Targeted execution**: During fixes, avoid codebase-wide runs
5. **Document before executing**: Strategy should be clear before changes

---

## Updating These Prompts

When completing infrastructure work that should be repeated:

1. Extract the recurring elements into a new maintenance prompt
2. Follow the four-phase workflow pattern
3. Add to this README with correct Type (Tool/Manual/Hybrid)
4. Reference from the corresponding backlog item

See [backlog_archiving.md](../backlog_archiving.md) for archiving guidelines.
