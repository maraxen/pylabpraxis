# Maintenance Prompt: Dependency Audit

**Purpose:** Review dependency freshness, security, and compatibility  
**Frequency:** Quarterly  

---

## Prompt

```markdown
Examine .agents/README.md for development context.

## Task

Audit dependencies across target repositories for freshness, security, and compatibility.

## Phase 1: Triage and Prioritize

1. **Extract Dependencies from All Target Repositories**:

   Capture dependency information to log files for analysis:

   ```bash
   cat {REPOSITORY_1}/pyproject.toml | grep -A 100 "dependencies" > deps_{REPOSITORY_1}.log
   cat {REPOSITORY_2}/pyproject.toml | grep -A 100 "dependencies" > deps_{REPOSITORY_2}.log
   # ... repeat for all target repositories
   ```

1. **Run Security Scan on All Repositories**:

   ```bash
   cd {REPOSITORY_1} && uv run pip-audit > audit_{REPOSITORY_1}.log 2>&1
   cd {REPOSITORY_2} && uv run pip-audit > audit_{REPOSITORY_2}.log 2>&1
   # ... repeat for all target repositories
   ```

2. **Count Issues Per Repository**:

   ```bash
   tail -n 10 audit_*.log
   ```

   Look for the summary showing vulnerabilities found.

3. **Prioritize by Issue Count**:

   Start with the repository that has the **fewest issues/dependencies** to build momentum and identify shared patterns.

## Phase 2: Categorize and Strategize

For each repository (starting with lowest issue count):

1. **Review Dependencies**:

   ```bash
   cat deps_{REPOSITORY}.log | head -n 50
   ```

2. **Review Security Audit**:

   ```bash
   cat audit_{REPOSITORY}.log
   ```

3. **Categorize by Type**:

   | Category | Action |
   |:---------|:-------|
   | Core (jax, numpy) | Check compatibility, align versions across repos |
   | Build (maturin, setuptools) | Update if new features needed |
   | Dev (pytest, ruff) | Keep current for new features |
   | Optional | Consider removing if unused |
   | Vulnerable | Prioritize update or removal |

4. **JAX-Specific Checks**:
   - JAX version consistent across all repos
   - jaxlib matches jax version
   - Backend extras (cuda, tpu) are optional, not required
   - jaxtyping version compatible

5. **Document Strategy**:

   Before applying updates, summarize:
   - Outdated packages by category
   - Security issues requiring immediate action
   - Version alignment needs across repos

6. **Get User Input**:

   ⏸️ PAUSE: Present the audit findings and update strategy to the user for approval before proceeding.

## Phase 3: Apply Updates

1. **Update Strategy**:
   - Pin major versions for stability: `jax>=0.4.0,<0.5.0`
   - Allow patch updates: `numpy>=1.26.0`
   - Lock exact versions in `uv.lock`

2. **Apply Updates**:

   ```bash
   # Update pyproject.toml with new version constraints
   # Then sync
   uv sync
   ```

3. **Test After Each Major Update**:

   Target test specific modules affected by the updated dependency:

   ```bash
   uv run pytest {REPOSITORY}/tests/affected_module/ -v
   ```

## Phase 4: Verify and Document

1. **Final Verification**:

   ```bash
   uv sync
   uv run pytest {REPOSITORY}/tests/ -v 2>&1 | tail -n 20
   ```

2. **Re-run Security Audit**:

   ```bash
   uv run pip-audit 2>&1 | tail -n 10
   ```

3. **Update Health Audit**:
   - Open `.agents/projects/{REPOSITORY}/HEALTH_AUDIT.md`
   - Update the "Dependency Issues" section with audit results
   - Document any version conflicts or remaining issues
   - Update the "Last Updated" date

## Output

- List of outdated dependencies
- Security issues found
- Updates applied
- Compatibility notes

## References

- [Health Audit Template](file:///home/marielle/united_workspace/.agents/templates/project_health_audit.md)
- [JAX installation docs](https://github.com/google/jax#installation)
- Repository's `pyproject.toml`

```

---

## Customization

| Placeholder | Description | Example |
|:------------|:------------|:--------|
| `{REPOSITORY}` | Repository to audit | `proxide`, `trex` |
| `{REPOSITORY_1}`, `{REPOSITORY_2}`, etc. | Multiple repositories when running batch triage | `proxide`, `prolix`, `trex` |

---

## Workflow Summary

```

┌─────────────────────────────────────────────────────────────────┐
│ Phase 1: Triage                                                 │
│   • Extract dependencies from all repos → capture to logs       │
│   • Run pip-audit on all repos                                  │
│   • Prioritize: fewest issues first                             │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 2: Categorize & Strategize (per repo)                     │
│   • Review dependencies and security audit                      │
│   • Categorize by type and urgency                              │
│   • ⏸️  PAUSE: Get user input before proceeding                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 3: Apply Updates                                          │
│   • Update version constraints                                  │
│   • Test affected modules after each update                     │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 4: Verify & Document                                      │
│   • Final sync and test run                                     │
│   • Re-run security audit                                       │
│   • Update HEALTH_AUDIT.md                                      │
└─────────────────────────────────────────────────────────────────┘

```
