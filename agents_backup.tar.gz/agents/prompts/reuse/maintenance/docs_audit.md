# Maintenance Prompt: Documentation Audit

**Purpose:** Verify documentation completeness and accuracy  
**Frequency:** Quarterly  

---

## Prompt

```markdown
Examine .agents/README.md for development context.

## Task

Audit documentation across target repositories to ensure completeness and accuracy.

## Phase 1: Triage and Prioritize

1. **Count Documentation Files Per Repository**:

   Identify the scope of review for each repository:

   ```bash
   echo "=== {REPOSITORY_1} ===" && find {REPOSITORY_1} -name "*.md" -o -name "*.rst" 2>/dev/null | wc -l
   echo "=== {REPOSITORY_2} ===" && find {REPOSITORY_2} -name "*.md" -o -name "*.rst" 2>/dev/null | wc -l
   # ... repeat for all target repositories
   ```

1. **List Key Documentation Files**:

   ```bash
   ls -la {REPOSITORY}/README.md {REPOSITORY}/docs/ 2>/dev/null
   ```

2. **Prioritize by File Count**:

   Start with the repository that has the **fewest documentation files** to build momentum and establish review patterns.

## Phase 2: Categorize and Strategize

For each repository (starting with lowest file count):

1. **Quick README Scan**:

   ```bash
   head -n 50 {REPOSITORY}/README.md
   ```

2. **Create Audit Checklist**:

   **README Review**:
   - [ ] Project description is current
   - [ ] Installation instructions work
   - [ ] Quick start example runs successfully
   - [ ] API overview matches current structure
   - [ ] Links are not broken
   - [ ] Badges are current (CI status, version)

   **API Documentation**:
   - [ ] All public modules have docstrings
   - [ ] All public functions have docstrings
   - [ ] Type hints are present and accurate
   - [ ] Examples are runnable

   **Architecture Documentation** (if applicable):
   - [ ] High-level design is documented
   - [ ] Module relationships are clear
   - [ ] Data flow is explained

3. **Identify Stale Content Patterns**:

   ```bash
   # Check for references to potentially removed features
   rg -i "deprecated|removed|old|legacy" {REPOSITORY}/README.md {REPOSITORY}/docs/ 2>/dev/null | head -n 20
   ```

4. **Document Findings**:

   Summarize:
   - Documentation gaps identified
   - Stale content found
   - Broken links detected
   - Priority items to address

5. **Get User Input**:

   ⏸️ PAUSE: Present the audit findings and proposed updates to the user for approval before making changes.

## Phase 3: Apply Fixes

1. **Check for Stale Content**:
   - References to removed features
   - Deprecated function examples
   - Old version numbers
   - Incorrect file paths

2. **Cross-Reference Validation**:
   - [ ] TECHNICAL_DEBT.md is current
   - [ ] Links to other repos are valid
   - [ ] Reference to .agents/ docs are correct

3. **Generate Missing Docs**:
   - Add docstrings to undocumented public API
   - Create/update architecture docs if needed
   - Add usage examples for complex features

4. **Fix Issues in Priority Order**:
   - Critical: broken functionality examples
   - High: missing public API docs
   - Medium: stale references
   - Low: style consistency

## Phase 4: Verify and Document

1. **Verify Links**:

   ```bash
   # Check for broken internal links
   rg -o '\[.*\]\(.*\.md\)' {REPOSITORY}/README.md | head -n 20
   ```

2. **Update Health Audit**:
   - Open `.agents/projects/{REPOSITORY}/HEALTH_AUDIT.md`
   - Update the "Other Audits" table row for "Documentation"
   - Update status, date, and add notes about findings

## Output

Document any gaps found and fixes applied.

## References

- [Health Audit Template](file:///home/marielle/united_workspace/.agents/templates/project_health_audit.md)
- [codestyles/python.md](file:///home/marielle/united_workspace/.agents/codestyles/python.md) (Docstring Format)
- [.agents/projects/{repo}/](file:///home/marielle/united_workspace/.agents/projects/)

```

---

## Customization

| Placeholder | Description | Example |
|:------------|:------------|:--------|
| `{REPOSITORY}` | Repository to audit | `proxide`, `trex` |
| `{REPOSITORY_1}`, `{REPOSITORY_2}`, etc. | Multiple repositories when running batch triage | `proxide`, `prolix`, `trex` |

---

## Workflow Summary

```

┌─────────────────────────────────────────────────────────────────┐
│ Phase 1: Triage                                                 │
│   • Count documentation files per repo                          │
│   • List key doc files                                          │
│   • Prioritize: fewest files first                              │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 2: Categorize & Strategize (per repo)                     │
│   • Quick README scan                                           │
│   • Create audit checklist                                      │
│   • ⏸️  PAUSE: Get user input before proceeding                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 3: Apply Fixes                                            │
│   • Fix stale content                                           │
│   • Validate cross-references                                   │
│   • Generate missing docs                                       │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 4: Verify & Document                                      │
│   • Verify links                                                │
│   • Update HEALTH_AUDIT.md                                      │
└─────────────────────────────────────────────────────────────────┘

```
