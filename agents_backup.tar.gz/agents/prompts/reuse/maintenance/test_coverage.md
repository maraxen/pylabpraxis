# Maintenance Prompt: Test Coverage

**Purpose:** Analyze test coverage and identify gaps  
**Frequency:** Per repository health audit  

---

## Prompt

```markdown
Examine .agents/README.md for development context.

## Task

Run tests on target repositories, resolve failures, and address critical coverage gaps.

## Phase 1: Triage and Prioritize

1. **Run Tests on All Target Repositories (Background)**:

   Execute pytest on each repository in the background, capturing output to log files:

   ```bash
   uv run pytest {REPOSITORY_1}/tests/ --tb=short > pytest_{REPOSITORY_1}.log 2>&1 &
   uv run pytest {REPOSITORY_2}/tests/ --tb=short > pytest_{REPOSITORY_2}.log 2>&1 &
   # ... repeat for all target repositories
   wait  # Wait for all background jobs
   ```

   **For Rust** (if applicable):

   ```bash
   cargo test --manifest-path {REPOSITORY}/oxidize/Cargo.toml 2>&1 | tee cargo_test_{REPOSITORY}.log
   ```

1. **Count Failures Per Repository**:

   Print the tail of each log to identify test results summary:

   ```bash
   tail -n 10 pytest_*.log
   ```

   Look for the summary line showing passed/failed/skipped counts.

2. **Prioritize by Failure Count**:

   Start with the repository that has the **fewest failures** to build momentum and clear quick wins.

## Phase 2: Categorize and Strategize

For each repository (starting with lowest failure count):

1. **Review Failures Only**:

   Use pytest's failure reporting to review just the failed tests:

   ```bash
   # Extract failure summary from log
   grep -A 20 "FAILED\|ERROR" pytest_{REPOSITORY}.log | head -n 50
   ```

   Or run targeted failure review:

   ```bash
   uv run pytest {REPOSITORY}/tests/ --tb=short --no-header -q 2>&1 | head -n 50
   ```

2. **Categorize Failures**:

   | Category | Pattern | Action |
   |:---------|:--------|:-------|
   | Import errors | `ImportError`, `ModuleNotFoundError` | Fix imports or dependencies |
   | Type errors | `TypeError`, `AttributeError` | Check API changes |
   | Assertion failures | `AssertionError` | Investigate logic or expected values |
   | Fixture issues | `fixture not found` | Check fixture scope/availability |
   | Skipped tests | `@pytest.mark.skip` | Review if skip is still valid |

3. **Document Strategy**:

   Before applying fixes, summarize:
   - Count of each failure category
   - Proposed fix approach for each category
   - Identify related failures (same root cause)

4. **Get User Input**:

   ⏸️ PAUSE: Present the categorization and strategy to the user for approval before proceeding with fixes.

## Phase 3: Apply Fixes (Targeted Testing)

**Important**: After the initial codebase-wide run, do NOT run full test suites until final verification. Target tests specifically as you resolve problems.

1. **Target Individual Test Files**:

   ```bash
   uv run pytest {REPOSITORY}/tests/path/to/test_file.py -v
   ```

2. **Target Submodules**:

   ```bash
   uv run pytest {REPOSITORY}/tests/submodule/ -v
   ```

3. **Target Individual Tests**:

   ```bash
   uv run pytest {REPOSITORY}/tests/test_file.py::test_function_name -v
   ```

4. **Use Verbosity Appropriately**:

   | Flag | Use Case |
   |:-----|:---------|
   | `-v` | See test names as they run |
   | `-vv` | See full assertion diffs |
   | `--tb=short` | Compact tracebacks |
   | `--tb=long` | Full tracebacks for debugging |
   | `-x` | Stop on first failure |
   | `--lf` | Run only last failed tests |

5. **Fix Priority Order**:

   | Priority | Category | Reason |
   |:---------|:---------|:-------|
   | High | Import/setup failures | Blocks other tests |
   | High | Core algorithm tests | Mathematical correctness critical |
   | Medium | API tests | User-facing stability |
   | Medium | I/O tests | Data integrity important |
   | Lower | Edge case tests | Address after main paths work |

## Phase 4: Verify and Document

1. **Final Codebase-Wide Verification**:

   Only after all targeted fixes are complete, run the full suite:

   ```bash
   uv run pytest {REPOSITORY}/tests/ -v 2>&1 | tail -n 20
   ```

2. **Run Coverage Report** (optional):

   ```bash
   uv run pytest {REPOSITORY}/tests/ --cov={REPOSITORY}/src/ --cov-report=term-missing 2>&1 | tail -n 30
   ```

3. **Update Health Audit**:
   - Open `.agents/projects/{REPOSITORY}/HEALTH_AUDIT.md`
   - Update the "Test Failures" section with current test results
   - Document coverage metrics and any remaining gaps
   - Update the "Last Updated" date

## Test Writing Guidelines

When adding missing tests:

- Focus on uncovered critical paths first
- Include edge cases (empty inputs, boundary values)
- Test error conditions raise appropriate exceptions
- For JAX code: test shapes, dtypes, and jit compatibility
- For Rust code: Add unit tests in modules (`#[test]`) or integration tests in `tests/`

## References

- [Health Audit Template](file:///home/marielle/united_workspace/.agents/templates/project_health_audit.md)
- [codestyles/python.md](file:///home/marielle/united_workspace/.agents/codestyles/python.md)
- [codestyles/jax.md](file:///home/marielle/united_workspace/.agents/codestyles/jax.md) (testing JAX code)

```

---

## Customization

| Placeholder | Description | Example |
|:------------|:------------|:--------|
| `{REPOSITORY}` | Repository to test | `proxide`, `trex` |
| `{REPOSITORY_1}`, `{REPOSITORY_2}`, etc. | Multiple repositories when running batch triage | `proxide`, `prolix`, `trex` |

---

## Workflow Summary

```

┌─────────────────────────────────────────────────────────────────┐
│ Phase 1: Triage                                                 │
│   • Run pytest on all repos (background) → capture to logs      │
│   • Count failures per repo (tail)                              │
│   • Prioritize: fewest failures first                           │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 2: Categorize & Strategize (per repo)                     │
│   • Review failures (grep/head)                                 │
│   • Categorize by failure type                                  │
│   • ⏸️  PAUSE: Get user input before proceeding                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 3: Apply Fixes (TARGETED)                                 │
│   • Target individual tests/files/submodules                    │
│   • NO codebase-wide runs during resolution                     │
│   • Use appropriate verbosity flags                             │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 4: Verify & Document                                      │
│   • Final codebase-wide run (only at end)                       │
│   • Update HEALTH_AUDIT.md                                      │
└─────────────────────────────────────────────────────────────────┘

```
