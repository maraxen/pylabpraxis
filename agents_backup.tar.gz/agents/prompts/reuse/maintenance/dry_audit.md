# Maintenance Prompt: DRY Audit

**Purpose:** Identify and refactor repeated code, duplicated logic, and consolidation opportunities  
**Frequency:** Quarterly  

---

## Prompt

```markdown
Examine .agents/README.md for development context.

## Task

Perform a DRY (Don't Repeat Yourself) audit across target repositories: identify repeated code, duplicated logic, and opportunities for consolidation.

## Phase 1: Triage and Prioritize

1. **Count Source Files Per Repository**:

   Identify the scope of review for each repository:

   ```bash
   echo "=== {REPOSITORY_1} ===" && find {REPOSITORY_1}/src -name "*.py" 2>/dev/null | wc -l
   echo "=== {REPOSITORY_2} ===" && find {REPOSITORY_2}/src -name "*.py" 2>/dev/null | wc -l
   # ... repeat for all target repositories
   ```

1. **Quick Duplicate Function Detection**:

   ```bash
   # Find potential duplicate function signatures
   grep -rh "def " {REPOSITORY_1}/src/ 2>/dev/null | sed 's/(.*//' | sort | uniq -c | sort -rn | head -n 10
   grep -rh "def " {REPOSITORY_2}/src/ 2>/dev/null | sed 's/(.*//' | sort | uniq -c | sort -rn | head -n 10
   ```

2. **Prioritize by File Count**:

   Start with the repository that has the **fewest source files** to build momentum and establish refactoring patterns.

## Phase 2: Categorize and Strategize

For each repository (starting with lowest file count):

1. **Search for Duplicate Patterns**:

   ```bash
   # Find potential duplicate function signatures
   grep -r "def " {REPOSITORY}/src/ | cut -d: -f2 | sort | uniq -c | sort -rn | head -n 20
   
   # Look for DRY-related TODOs
   rg -n "TODO.*DRY|FIXME.*duplicate|# repeated" {REPOSITORY}/src/ | head -n 10
   ```

2. **Categorize Duplication Types**:

   | Category | Pattern | Priority |
   |:---------|:--------|:---------|
   | Duplicate code blocks | Near-identical code in multiple files | High |
   | Repeated logic | Similar validation/transform sequences | Medium |
   | Utility operations | String/path/array manipulation repeated | Medium |
   | Magic numbers/strings | Same literals in multiple places | Low |

3. **Candidate Analysis**:

   For each duplication found, assess:
   - **Frequency**: How many times is it repeated?
   - **Complexity**: Is extraction worth the abstraction cost?
   - **Stability**: Is this logic stable or still evolving?
   - **Cohesion**: Does grouping make semantic sense?

4. **Document Strategy**:

   Summarize:
   - Duplications found with locations
   - Proposed refactoring approach for each
   - Anti-patterns to avoid

5. **Get User Input**:

   ⏸️ PAUSE: Present the findings and refactoring strategy to the user for approval before making changes.

## Phase 3: Apply Fixes

1. **Refactoring Strategies**:

   a. **Extract Helper Functions**:
      - Move repeated logic into module-local `_helper()` functions
      - Keep helpers private unless needed externally

   b. **Create Utility Modules**:
      - For cross-module repetition, create `{REPOSITORY}/src/{package}/utils/` modules
      - Common candidates: `io_utils.py`, `validation.py`, `transforms.py`

   c. **Consolidate into Base Classes**:
      - If classes share repeated methods, consider inheritance or mixins
      - Use composition over inheritance when appropriate

   d. **Parameterize Variations**:
      - If code differs only in literal values, parameterize
      - Use configuration or factory patterns for complex variations

   e. **Create Shared Constants**:
      - Repeated magic numbers/strings → named constants
      - Common regex patterns → compiled Pattern objects

2. **Apply Changes Incrementally**:
   - One refactoring at a time
   - Test after each change

## Phase 4: Verify and Document

1. **Verification**:

   ```bash
   # Ensure refactoring doesn't break tests
   uv run pytest {REPOSITORY}/tests/ -v 2>&1 | tail -n 20
   
   # Verify type checking still passes
   uv run ty check {REPOSITORY}/src/ 2>&1 | tail -n 5
   
   # Verify linting
   uv run ruff check {REPOSITORY}/src/ --quiet
   ```

2. **Update Health Audit**:
   - Open `.agents/projects/{REPOSITORY}/HEALTH_AUDIT.md`
   - Update the "DRY Audit" row in "Other Audits"
   - Mark items as complete and add notes

## Output

Report the following:

1. **Duplications Found**:

   | Location 1 | Location 2 | Pattern | Lines | Priority |
   |:-----------|:-----------|:--------|:------|:---------|
   | `path/file1.py:L10-20` | `path/file2.py:L30-40` | Validation logic | 10 | High |

2. **Refactoring Actions Taken**:
   - Describe each consolidation performed
   - List new helper functions/modules created
   - Note any intentional duplications kept (with justification)

3. **Deferred Items**:
   - Duplications identified but not addressed (with rationale)
   - Potential future consolidation opportunities

## Anti-Patterns to Avoid

- **Over-abstraction**: Don't extract code that's only repeated twice if it reduces readability
- **Premature generalization**: Wait for 3+ occurrences before abstracting
- **Coupling unrelated logic**: Keep semantic boundaries clear
- **Breaking encapsulation**: Don't expose internal helpers unnecessarily

## References

- [Health Audit Template](file:///home/marielle/united_workspace/.agents/templates/project_health_audit.md)
- [codestyles/python.md](file:///home/marielle/united_workspace/.agents/codestyles/python.md)

```

---

## Customization

| Placeholder | Description | Example |
|:------------|:------------|:--------|
| `{REPOSITORY}` | Repository to audit | `proxide`, `trex`, `prolix` |
| `{REPOSITORY_1}`, `{REPOSITORY_2}`, etc. | Multiple repositories when running batch triage | `proxide`, `prolix`, `trex` |
| `{package}` | Package name within src | `proxide`, `trex` |

---

## Workflow Summary

```

┌─────────────────────────────────────────────────────────────────┐
│ Phase 1: Triage                                                 │
│   • Count source files per repo                                 │
│   • Quick duplicate function detection                          │
│   • Prioritize: fewest files first                              │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 2: Categorize & Strategize (per repo)                     │
│   • Search for duplicate patterns                               │
│   • Assess: frequency, complexity, stability, cohesion          │
│   • ⏸️  PAUSE: Get user input before proceeding                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 3: Apply Fixes                                            │
│   • Extract helpers, create utility modules                     │
│   • Apply changes incrementally                                 │
│   • Test after each change                                      │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 4: Verify & Document                                      │
│   • Run tests and type check                                    │
│   • Update HEALTH_AUDIT.md                                      │
└─────────────────────────────────────────────────────────────────┘

```
