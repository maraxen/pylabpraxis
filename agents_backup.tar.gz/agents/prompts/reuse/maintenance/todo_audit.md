# Maintenance Prompt: TODO Audit

**Purpose:** Identify TODO/FIXME/HACK comments and migrate actionable items to technical debt tracking  
**Frequency:** Per repository health audit  

---

## Prompt

```markdown
Examine .agents/README.md for development context.

## Task

Audit target repositories for TODO, FIXME, HACK, and similar inline comments. Migrate actionable items to `.agents/TECHNICAL_DEBT.md` and clean up stale or resolved TODOs.

## Phase 1: Triage and Prioritize

1. **Count TODOs Per Repository**:

   Run a quick count across all target repositories:

   ```bash
   echo "=== {REPOSITORY_1} ===" && rg -c -i "(TODO|FIXME|HACK|XXX)" {REPOSITORY_1}/src/ --glob '*.py' 2>/dev/null | awk -F: '{sum+=$2} END {print sum}'
   echo "=== {REPOSITORY_2} ===" && rg -c -i "(TODO|FIXME|HACK|XXX)" {REPOSITORY_2}/src/ --glob '*.py' 2>/dev/null | awk -F: '{sum+=$2} END {print sum}'
   # ... repeat for all target repositories
   ```

   For Rust (if applicable):

   ```bash
   echo "=== {REPOSITORY}/oxidize ===" && rg -c -i "(TODO|FIXME|HACK|XXX)" {REPOSITORY}/oxidize/src/ --glob '*.rs' 2>/dev/null | awk -F: '{sum+=$2} END {print sum}'
   ```

1. **Prioritize by TODO Count**:

   Start with the repository that has the **fewest TODOs** to build momentum and establish categorization patterns.

## Phase 2: Categorize and Strategize

For each repository (starting with lowest TODO count):

1. **Search for TODOs**:

   ```bash
   rg -i "(TODO|FIXME|HACK|XXX|NOTE:.*fix|NOTE:.*todo)" {REPOSITORY}/src/ --glob '*.py' --glob '*.rs' -C 2 | head -n 100
   ```

2. **Categorize Each Item**:

   | Category | Action |
   |:---------|:-------|
   | **Stale/Resolved** | TODO references completed work or no longer applies → Remove it |
   | **Quick Fix** | Can be addressed in <10 minutes → Fix now and remove TODO |
   | **Technical Debt** | Requires significant work → Migrate to `TECHNICAL_DEBT.md` |
   | **Blocked** | Depends on external factors → Add note and keep TODO |
   | **Documentation** | Needs clarification, not a code change → Update docs or remove |

3. **Common Patterns**:

   | Pattern | Likely Action |
   |:--------|:--------------|
   | `# TODO: implement X` | Tech debt if significant, quick fix if trivial |
   | `# FIXME: this is broken` | High priority, investigate immediately |
   | `# HACK: workaround for X` | Tech debt - document why and plan proper fix |
   | `# XXX: review this` | Investigate, may be stale |
   | `# TODO(name): ...` | Check if person is still active, may be stale |
   | `# NOTE: should also...` | Often hidden TODOs, evaluate |

4. **Document Strategy**:

   Summarize:
   - Count by category
   - TODOs to migrate to tech debt
   - Quick fixes to apply
   - Stale TODOs to remove

5. **Get User Input**:

   ⏸️ PAUSE: Present the categorization and proposed actions to the user for approval before proceeding.

## Phase 3: Apply Fixes

1. **For Technical Debt Items**:

   Add to `.agents/TECHNICAL_DEBT.md` under **Active Items** using this format:

   ```markdown
   ## [Descriptive Item Name]

   - **Issue**: [What the TODO describes]
   - **Impact**: [Why this matters]
   - **Proposed Solution**: [High-level approach from TODO context]
   - **Priority**: High | Medium | Low
   - **Related**: [Link to source file(s)]
   ```

   Include:
   - Clear, descriptive title (not just "Fix TODO in file.py")
   - Context from surrounding code
   - Priority based on impact assessment

2. **Clean Up**:
   - Remove stale TODOs that no longer apply
   - Remove TODOs after fixing quick issues
   - Consolidate duplicate TODOs into single tech debt items
   - For migrated TODOs, optionally leave a brief reference:

     ```python
     # See TECHNICAL_DEBT.md: "Item Name"
     ```

     Or remove entirely if the tech debt item is self-documenting.

3. **TODO Quality Guidelines**:

   When migrating TODOs to technical debt, ensure:
   - **Specificity**: Vague TODOs like "fix this" should be investigated and made specific
   - **Context**: Include enough context that someone unfamiliar can understand the issue
   - **Actionability**: Each item should have a clear path to resolution
   - **Priority**: Assign based on:
     - **High**: Affects correctness, security, or blocks other work
     - **Medium**: Improves maintainability, performance, or developer experience
     - **Low**: Nice-to-have improvements, style consistency

## Phase 4: Verify and Document

1. **Re-count TODOs**:

   ```bash
   rg -c -i "(TODO|FIXME|HACK|XXX)" {REPOSITORY}/src/ --glob '*.py' 2>/dev/null | awk -F: '{sum+=$2} END {print sum}'
   ```

2. **Update Health Audit**:
   - Open `.agents/projects/{REPOSITORY}/HEALTH_AUDIT.md`
   - Update the "TODO Audit" row in "Other Audits" section
   - Document count of TODOs found, migrated, and removed

## Output Example

After running this audit, you might have:

- **Found**: 15 TODOs
- **Removed (stale)**: 4
- **Fixed (quick)**: 3
- **Migrated to tech debt**: 5
- **Kept (blocked/valid)**: 3

## References

- [TECHNICAL_DEBT.md](file:///home/marielle/united_workspace/.agents/TECHNICAL_DEBT.md)
- [Health Audit Template](file:///home/marielle/united_workspace/.agents/templates/project_health_audit.md)

```

---

## Customization

| Placeholder | Description | Example |
|:------------|:------------|:--------|
| `{REPOSITORY}` | Repository to audit | `proxide`, `trex`, `prolix`, `proteinsmc` |
| `{REPOSITORY_1}`, `{REPOSITORY_2}`, etc. | Multiple repositories when running batch triage | `proxide`, `prolix`, `trex` |

---

## Workflow Summary

```

┌─────────────────────────────────────────────────────────────────┐
│ Phase 1: Triage                                                 │
│   • Count TODOs per repo                                        │
│   • Prioritize: fewest TODOs first                              │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 2: Categorize & Strategize (per repo)                     │
│   • Search for TODOs with context                               │
│   • Categorize: stale, quick fix, tech debt, blocked            │
│   • ⏸️  PAUSE: Get user input before proceeding                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 3: Apply Fixes                                            │
│   • Migrate tech debt items to TECHNICAL_DEBT.md                │
│   • Apply quick fixes                                           │
│   • Remove stale TODOs                                          │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 4: Verify & Document                                      │
│   • Re-count TODOs                                              │
│   • Update HEALTH_AUDIT.md                                      │
└─────────────────────────────────────────────────────────────────┘

```
