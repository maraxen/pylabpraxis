# Maintenance Prompt: Type Checking

**Purpose:** Run `ty` type checker and resolve any type errors  
**Frequency:** Per repository health audit  

---

## Prompt

```markdown
Examine .agents/README.md for development context.

## Task

Run type checking with `ty` on target repositories and resolve any errors.

## Phase 1: Triage and Prioritize

1. **Run Type Checker on All Target Repositories**:

   Execute `ty` on each repository and capture output to log files for analysis:

   ```bash
   uv run ty check {REPOSITORY_1}/src/ > ty_{REPOSITORY_1}.log 2>&1
   uv run ty check {REPOSITORY_2}/src/ > ty_{REPOSITORY_2}.log 2>&1
   # ... repeat for all target repositories
   ```

   **For Rust** (if applicable):

   ```bash
   cargo check --manifest-path {REPOSITORY}/oxidize/Cargo.toml 2>&1 | tee cargo_{REPOSITORY}.log
   ```

1. **Count Diagnostics Per Repository**:

   Print the tail of each log to identify the total number of diagnostics:

   ```bash
   tail -n 5 ty_*.log
   ```

   Look for the "Found N diagnostics" line at the end of each log.

2. **Prioritize by Error Count**:

   Start with the repository that has the **fewest errors** to build momentum and clear quick wins. This also helps identify common patterns that may apply to other repositories.

## Phase 2: Categorize and Strategize

For each repository (starting with lowest error count):

1. **Review the Full Log**:

   ```bash
   cat ty_{REPOSITORY}.log | head -n 100  # or view in editor
   ```

2. **Categorize Errors** into these types:
   - **Python**:
     - `invalid-argument-type` - Type mismatch in function calls
     - `unresolved-reference` - Missing imports or undefined names
     - `invalid-return-type` - Return value doesn't match signature
     - `possibly-missing-attribute` - Accessing attribute that may not exist
     - `unknown-argument` - Unknown keyword argument in function call
     - Import errors (missing stubs)
     - Generic array types needing jaxtyping
   - **Rust**:
     - Compilation errors
     - Type mismatches
     - Borrow checker errors

3. **Document Strategy**:

   Before applying fixes, summarize:
   - Count of each error category
   - Proposed fix approach for each category
   - Any patterns (e.g., "all `invalid-argument-type` errors are from `space.distance` calls needing `jnp.asarray()`")

4. **Get User Input**:

   Pause and present the categorization and strategy to the user for approval before proceeding with fixes.

## Phase 3: Apply Fixes

Follow these guidelines:

### JAX Type Hints (from type_hint_modernization)

- Use `jaxtyping` annotations instead of generic `jax.Array` or `jnp.ndarray`
- Define common shapes in `{repo}/src/{package}/types.py`:

  ```python
  from jaxtyping import Array, Float, Int, Bool
  
  Scalar = Float[Array, ""]
  ScalarFloat = Float[Array, ""]
  BatchedArray = Float[Array, "batch ..."]
  ```

- Use descriptive dimension names: `"batch nodes features"` not `"B N F"`
- **Avoid inline complex type definitions.** Always define types in `types.py` and import them.
  - **Bad:** `def foo(x: Float[Array, "batch dim"]) -> ...`
  - **Good:** `def foo(x: BatchDimArray) -> ...`
- **Prefer specific annotated types over `ArrayLike`** in function signatures where shape info is known.
  - **Bad:** `def foo(x: ArrayLike) -> ...` (if x has a specific shape)
  - **Good:** `def foo(x: Coordinates) -> ...`

### Common Fix Patterns

| Error Type | Typical Fix |
|:-----------|:------------|
| `invalid-argument-type` (Array vs ndarray) | Wrap with `jnp.asarray()` |
| `invalid-argument-type` (None possible) | Add assertion or narrow type with `if x is not None` |
| `unresolved-reference` | Add import or define missing symbol |
| `invalid-return-type` | Update return annotation or fix return value |
| `possibly-missing-attribute` | Add None check or use `hasattr()` |
| `unknown-argument` | Add `# type: ignore[unknown-argument]` if valid dynamic kwargs |

### Type Alias Consolidation

- Check for duplicate type definitions across modules
- Consolidate to `types.py` and re-export
- Update imports throughout the codebase

## Phase 4: Verify and Document

1. **Verify**:

   ```bash
   uv run ty check {REPOSITORY}/src/ --quiet
   ```

   Or for quick confirmation:

   ```bash
   uv run ty check {REPOSITORY}/src/ 2>&1 | tail -n 3
   ```

2. **Update Health Audit**:
   - Open `.agents/projects/{REPOSITORY}/HEALTH_AUDIT.md`
   - Update the "Type Checking Issues" section with current status
   - Document any remaining errors in the "Outstanding Issues" table
   - Update the "Last Updated" date

## References

- [Health Audit Template](file:///home/marielle/united_workspace/.agents/templates/project_health_audit.md)
- [codestyles/python.md](file:///home/marielle/united_workspace/.agents/codestyles/python.md)
- [codestyles/jax.md](file:///home/marielle/united_workspace/.agents/codestyles/jax.md)

```

---

## Customization

| Placeholder | Description | Example |
|:------------|:------------|:--------|
| `{REPOSITORY}` | Repository to check | `proxide`, `trex`, `prolix`, `united_workspace` |
| `{REPOSITORY_1}`, `{REPOSITORY_2}`, etc. | Multiple repositories when running batch triage | `proxide`, `prolix`, `trex` |

---

## Workflow Summary

```

┌─────────────────────────────────────────────────────────────────┐
│ Phase 1: Triage                                                 │
│   • Run ty on all repos → capture to logs                       │
│   • Count diagnostics per repo                                  │
│   • Prioritize: fewest errors first                             │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 2: Categorize & Strategize (per repo)                     │
│   • Review log, categorize error types                          │
│   • Document fix approach                                       │
│   • ⏸️  PAUSE: Get user input before proceeding                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 3: Apply Fixes                                            │
│   • Apply fixes following guidelines                            │
│   • Use common fix patterns                                     │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 4: Verify & Document                                      │
│   • Verify with ty check --quiet                                │
│   • Update HEALTH_AUDIT.md                                      │
└─────────────────────────────────────────────────────────────────┘

```
