# Maintenance Prompt: Linting

**Purpose:** Run Ruff linting and resolve violations  
**Frequency:** Per repository health audit  

---

## Prompt

```markdown
Examine .agents/README.md for development context.

## Task

Run Ruff linting on target repositories and resolve all violations.

## Phase 1: Triage and Prioritize

1. **Run Linter on All Target Repositories**:

   Execute Ruff on each repository and capture output to log files for analysis:

   **Python**:
   ```bash
   uv run ruff check {REPOSITORY_1}/src/ {REPOSITORY_1}/tests/ > ruff_{REPOSITORY_1}.log 2>&1
   uv run ruff check {REPOSITORY_2}/src/ {REPOSITORY_2}/tests/ > ruff_{REPOSITORY_2}.log 2>&1
   # ... repeat for all target repositories
   ```

   **Rust** (if applicable):

   ```bash
   cargo clippy --manifest-path {REPOSITORY}/oxidize/Cargo.toml -- -D warnings 2>&1 | tee clippy_{REPOSITORY}.log
   ```

1. **Count Violations Per Repository**:

   Print the tail of each log to identify the total number of issues:

   ```bash
   tail -n 5 ruff_*.log
   ```

   Look for the summary line showing total violations found.

2. **Prioritize by Violation Count**:

   Start with the repository that has the **fewest violations** to build momentum and clear quick wins. This also helps identify common patterns that may apply to other repositories.

## Phase 2: Categorize and Strategize

For each repository (starting with lowest violation count):

1. **Review the Full Log**:

   ```bash
   cat ruff_{REPOSITORY}.log | head -n 100  # or view in editor
   ```

2. **Categorize Issues**:

   | Category | Codes | Action |
   |:---------|:------|:-------|
   | Unused imports | F401 | Remove or add `# noqa: F401` if re-export |
   | Undefined names | F821 | Fix missing imports or definitions |
   | Unused variables | F841 | Remove or prefix with `_` |
   | Type annotation issues | ANN* | Add type hints per type_checking.md |
   | Import order | I* | Auto-fixed |
   | Complexity | C901 | Consider refactoring if warranted |

3. **Document Strategy**:

   Before applying fixes, summarize:
   - Count of each error category
   - Proposed fix approach for each category
   - Any patterns (e.g., "all F401 errors are in `__init__.py` re-exports")

4. **Get User Input**:

   ⏸️ PAUSE: Present the categorization and strategy to the user for approval before proceeding with fixes.

## Phase 3: Apply Fixes

1. **Auto-fix Safe Violations**:

   ```bash
   uv run ruff check --fix {REPOSITORY}/src/ {REPOSITORY}/tests/
   ```

2. **Handle Remaining Issues Manually**:
   - Remove unused imports
   - Keep intentional re-exports (add `# noqa: F401` or use `__all__`)
   - Remove or prefix unused variables with `_`
   - Check if variable should actually be used (bug)

3. **Handle Exceptions**:
   - Add `# noqa: CODE` only when truly necessary
   - Document why in a comment if suppressing
   - Consider adjusting `ruff.toml` for project-wide exceptions

4. **Format Code**:

   **Python**:

   ```bash
   uv run ruff format {REPOSITORY}/src/ {REPOSITORY}/tests/
   ```

   **Rust**:

   ```bash
   cargo fmt --manifest-path {REPOSITORY}/oxidize/Cargo.toml
   ```

## Phase 4: Verify and Document

1. **Verify**:

   ```bash
   uv run ruff check {REPOSITORY}/src/ {REPOSITORY}/tests/ --quiet
   ```

   Or for quick confirmation:

   ```bash
   uv run ruff check {REPOSITORY}/src/ {REPOSITORY}/tests/ 2>&1 | tail -n 3
   ```

2. **Update Health Audit**:
   - Open `.agents/projects/{REPOSITORY}/HEALTH_AUDIT.md`
   - Update the "Linting Issues" section with current status
   - Document any remaining issues in the "Outstanding Issues" table
   - Update the "Last Updated" date

## References

- [Health Audit Template](file:///home/marielle/united_workspace/.agents/templates/project_health_audit.md)
- [codestyles/python.md](file:///home/marielle/united_workspace/.agents/codestyles/python.md)
- Repository's `ruff.toml` or `pyproject.toml` [tool.ruff] section

```

---

## Customization

| Placeholder | Description | Example |
|:------------|:------------|:--------|
| `{REPOSITORY}` | Repository to lint | `proxide`, `trex` |
| `{REPOSITORY_1}`, `{REPOSITORY_2}`, etc. | Multiple repositories when running batch triage | `proxide`, `prolix`, `trex` |

---

## Workflow Summary

```

┌─────────────────────────────────────────────────────────────────┐
│ Phase 1: Triage                                                 │
│   • Run ruff on all repos → capture to logs                     │
│   • Count violations per repo                                   │
│   • Prioritize: fewest violations first                         │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 2: Categorize & Strategize (per repo)                     │
│   • Review log, categorize by error code                        │
│   • Document fix approach                                       │
│   • ⏸️  PAUSE: Get user input before proceeding                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 3: Apply Fixes                                            │
│   • Auto-fix safe violations                                    │
│   • Handle remaining issues manually                            │
│   • Format code                                                 │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 4: Verify & Document                                      │
│   • Verify with ruff check --quiet                              │
│   • Update HEALTH_AUDIT.md                                      │
└─────────────────────────────────────────────────────────────────┘

```
