# Maintenance Prompt: Docstring Audit

**Purpose:** Standardize docstrings and remove excess inline comments  
**Frequency:** Per repository health audit  

---

## Prompt

```markdown
Examine .agents/README.md for development context.

## Task

Audit and standardize docstrings across target repositories, removing excess inline comments.

## Phase 1: Triage and Prioritize

1. **Count Python Files Per Repository**:

   Identify the scope of review for each repository:

   ```bash
   echo "=== {REPOSITORY_1} ===" && find {REPOSITORY_1}/src -name "*.py" 2>/dev/null | wc -l
   echo "=== {REPOSITORY_2} ===" && find {REPOSITORY_2}/src -name "*.py" 2>/dev/null | wc -l
   # ... repeat for all target repositories
   ```

1. **Run Docstring Linter** (if available):

   ```bash
   uv run pydocstyle {REPOSITORY_1}/src/ --count 2>&1 | tail -n 5
   uv run pydocstyle {REPOSITORY_2}/src/ --count 2>&1 | tail -n 5
   ```

2. **Prioritize by File Count**:

   Start with the repository that has the **fewest Python files** to build momentum and establish patterns.

## Phase 2: Categorize and Strategize

For each repository (starting with lowest file count):

1. **Identify Files Needing Updates**:

   ```bash
   # Find public functions without docstrings (rough heuristic)
   rg "^def [^_]" {REPOSITORY}/src/ -l | head -n 20
   
   # Find files with many inline comments
   for f in $(find {REPOSITORY}/src -name "*.py" | head -n 10); do
     count=$(grep -c "^[[:space:]]*#" "$f" 2>/dev/null || echo 0)
     echo "$count $f"
   done | sort -rn | head -n 10
   ```

2. **Categorize Issues**:

   | Category | Pattern | Priority |
   |:---------|:--------|:---------|
   | Missing docstrings | Public functions without `"""` | High |
   | Wrong format | Docstrings not following standard | Medium |
   | Excess comments | >10 inline comments in a function | Medium |
   | Commented-out code | `# old_code()` blocks | Low |

3. **Document Strategy**:

   Summarize:
   - Files with most issues
   - Common patterns observed
   - Priority order for fixes

4. **Get User Input**:

   ⏸️ PAUSE: Present the findings and proposed approach to the user for approval before making changes.

## Phase 3: Apply Fixes

1. **Apply Standard Docstring Format**:

   ```python
   def function_name(arg1: Type1, arg2: Type2) -> ReturnType:
       """Imperative summary describing what the function does.
       
       Process:
           1. First step description
           2. Second step with shape info: (batch, nodes, features)
           3. Mathematical operation
       
       MathJax:
           $$result = \sum_{i} weight_i \cdot input_i$$
       
       NOTES:
           Any detailed explanations moved from inline comments.
           Implementation-specific details go here.
       
       Args:
           arg1: Description of first argument.
           arg2: Description of second argument.
       
       Returns:
           Description of return value with shape if applicable.
       
       Example:
           >>> result = function_name(x, y)
           >>> result.shape
           (10, 3)
       """
   ```

2. **Comment Cleanup Guidelines**:
   - Move implementation explanations to docstring `NOTES:` section
   - Keep only truly necessary inline comments (non-obvious hacks, workarounds)
   - Remove comments that just restate what the code does
   - Remove commented-out code

3. **Priority Order**:
   - Public API functions first
   - Complex mathematical implementations
   - I/O functions
   - Internal utilities (brief docstrings OK)

## Phase 4: Verify and Document

1. **Verify**:

   ```bash
   uv run pydocstyle {REPOSITORY}/src/ 2>&1 | tail -n 10
   ```

2. **Update Health Audit**:
   - Open `.agents/projects/{REPOSITORY}/HEALTH_AUDIT.md`
   - Update the "Other Audits" table row for "Docstrings"
   - Update status, date, and add notes about findings

## References

- [Health Audit Template](file:///home/marielle/united_workspace/.agents/templates/project_health_audit.md)
- [codestyles/python.md](file:///home/marielle/united_workspace/.agents/codestyles/python.md) (Docstring Format section)
- [.agents/README.md](file:///home/marielle/united_workspace/.agents/README.md) (Documentation Standards)

```

---

## Customization

| Placeholder | Description | Example |
|:------------|:------------|:--------|
| `{REPOSITORY}` | Repository to audit | `proxide`, `trex` |
| `{REPOSITORY_1}`, `{REPOSITORY_2}`, etc. | Multiple repositories when running batch triage | `proxide`, `prolix`, `trex` |

---

## Workflow Summary

```

┌─────────────────────────────────────────────────────────────────┐
│ Phase 1: Triage                                                 │
│   • Count Python files per repo                                 │
│   • Run pydocstyle for issue counts                             │
│   • Prioritize: fewest files first                              │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 2: Categorize & Strategize (per repo)                     │
│   • Identify files needing updates                              │
│   • Categorize by issue type                                    │
│   • ⏸️  PAUSE: Get user input before proceeding                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 3: Apply Fixes                                            │
│   • Apply standard docstring format                             │
│   • Clean up excess comments                                    │
│   • Priority: public API first                                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ Phase 4: Verify & Document                                      │
│   • Run pydocstyle verification                                 │
│   • Update HEALTH_AUDIT.md                                      │
└─────────────────────────────────────────────────────────────────┘

```
