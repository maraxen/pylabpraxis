# Agent Prompt: 04_health_audits

Examine .agents/README.md for development context.

**Status:** 🟢 Not Started  
**Batch:** [260108](README.md)  
**Backlog:** [health_audit_*.md](../../backlog/)  

---

## Task

Execute health audits across all 5 repositories to ensure they meet project-standard linting, testing, and type checking requirements.

### Repositories (in dependency order)

1. **proxide** - foundational, changes ripple to all
2. **prolix** - depends on proxide
3. **PrxteinMPNN** - depends on proxide, prolix
4. **trex** - standalone
5. **proteinsmc** - depends on PrxteinMPNN

### Per-Repository Checklist

For each repository, complete:

#### Linting (Ruff)

- [ ] Run `uv run ruff check src/ --fix`
- [ ] Resolve remaining manual fixes
- [ ] Verify zero linting errors

#### Testing (pytest)

- [ ] Run `uv run pytest tests/ -v`
- [ ] Validate all tests pass
- [ ] Note any test coverage gaps

#### Type Checking (ty)

- [ ] Run `uv run ty check`
- [ ] Resolve static type errors
- [ ] Verify `jaxtyping` consistency

---

## Context Files

| File | Purpose |
|:-----|:--------|
| [health_audit_proxide.md](../../backlog/health_audit_proxide.md) | proxide audit tracking |
| [health_audit_prolix.md](../../backlog/health_audit_prolix.md) | prolix audit tracking |
| [health_audit_prxteinmpnn.md](../../backlog/health_audit_prxteinmpnn.md) | PrxteinMPNN audit tracking |
| [health_audit_trex.md](../../backlog/health_audit_trex.md) | trex audit tracking |
| [health_audit_proteinsmc.md](../../backlog/health_audit_proteinsmc.md) | proteinsmc audit tracking |

---

## Project Conventions

- **Commands**: Use `uv run` for all Python commands (run from workspace root)
- **Linting**: `uv run ruff check {repo}/src/ --fix`
- **Testing**: `uv run pytest {repo}/tests/ -v`
- **Type Check**: `uv run ty check`

See [codestyles/python.md](../../codestyles/python.md) for Python conventions.

---

## On Completion

For each repository:

- [ ] Update corresponding `health_audit_{repo}.md` with:
  - Mark checklist items complete
  - Update "Last Review" date to 2026-01-08
- [ ] Update [DEVELOPMENT_MATRIX.md](../../DEVELOPMENT_MATRIX.md) "Ongoing Maintenance" table
- [ ] Mark this prompt complete in batch README

---

## References

- [.agents/README.md](../../README.md) - Environment overview
- [codestyles/python.md](../../codestyles/python.md) - Python style guide
- [codestyles/jax.md](../../codestyles/jax.md) - JAX style guide
