# Prompt Batch: [YYMMDD] - [Brief Description]

**Status:** 🟡 In Progress | ✅ All Complete
**Created:** YYYY-MM-DD

---

## Overview

[Description of what this batch of prompts accomplishes]

---

## Prompts

### 1. [Prompt Title]

**Status:** 🟢 Not Started | 🟡 In Progress | ✅ Complete
**Depends on:** None | Prompt N

```
[Prompt content here]
```

**Expected outcome:** [What should be accomplished]

---

### 2. [Prompt Title]

**Status:** 🟢 Not Started
**Depends on:** Prompt 1

```
[Prompt content here]
```

**Expected outcome:** [What should be accomplished]

---

## Completion Checklist

- [ ] All prompts executed
- [ ] `DEVELOPMENT_MATRIX.md` updated
- [ ] `status.json` GPU released (if applicable)
- [ ] Tests passing

---

> **Archive Note:** When all items above are complete, update Status to "✅ All Complete" and this folder can be moved to `archive/`.
