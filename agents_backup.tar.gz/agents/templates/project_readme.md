# [Project Name] Agent Guidelines

Project-specific conventions and quick reference for AI agents.

---

## Overview

[Brief description of the project's purpose]

## Architecture

```
src/{package}/
├── module1/     # Description
├── module2/     # Description
└── utils/       # Shared utilities
```

## Key Files

| File | Purpose |
|:-----|:--------|
| `src/.../file.py` | Description |

## Common Tasks

### Running Tests

```bash
uv run pytest tests/ -v
```

### Building / Installing

```bash
# If applicable
uv sync
```

## Conventions

- [Project-specific conventions]
- [Coding patterns unique to this project]

## Integration Points

| Dependency | Usage |
|:-----------|:------|
| proxide | ... |

## Technical Debt

See [TECHNICAL_DEBT.md](TECHNICAL_DEBT.md) for known issues.
