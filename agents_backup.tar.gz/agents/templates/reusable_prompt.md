# Reusable Prompt: [Name]

Examine .agents/README.md for development context.

**Purpose:** [What this prompt accomplishes]
**Use when:** [Conditions for using this prompt]

---

## Prompt

```
[Reusable prompt content here. Use placeholders like {PROJECT} or {FILE} for customization]
```

---

## Customization

| Placeholder | Description | Example |
|:------------|:------------|:--------|
| `{PROJECT}` | Target project | proxide |
| `{FILE}` | Target file | src/core/protein.py |

---

## Example Usage

```
[Example of the prompt with placeholders filled in]
```
