# Backlog Item Template

**Status:** 🟢 Planned | 🟡 In Progress | 🔴 Blocked | ✅ Complete
**Difficulty:** 🔴 Complex | 🟡 Intricate | 🟢 Easy Win
**Projects:** [list affected projects]
**Created:** YYYY-MM-DD

---

## Goal

[One paragraph describing what this work accomplishes]

## Phases

### Phase 1: [Name]

- [ ] Task 1
- [ ] Task 2

### Phase 2: [Name]

- [ ] Task 1
- [ ] Task 2

---

## Notes

[Any additional context, decisions, blockers]

## References

- [Link to relevant files or docs]
