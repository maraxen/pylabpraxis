# Technical Debt

Quick-capture space for technical debt items before formal backlog creation.

---

## Template

Use this format when adding new items:

```markdown
## [Item Name]

- **Issue**: Brief description of the problem
- **Impact**: How this affects development/performance
- **Proposed Solution**: High-level approach
- **Priority**: High | Medium | Low
- **Related**: Links to relevant code or docs
```

When ready to formalize, create a backlog item using [templates/backlog_item.md](templates/backlog_item.md) and add to [DEVELOPMENT_MATRIX.md](DEVELOPMENT_MATRIX.md).

---

## Active Items

## Prolix Codebase Audit

- **Issue**: Prolix codebase has accumulated significant code quality issues requiring a comprehensive review:
  - **Excessive inline comments** replacing proper abstractions (e.g., `# Origin weights`, `# X weights`, `# Y weights` instead of named fields or dataclasses)
  - **Magic array indices** throughout (e.g., `param_row[3:6]`, `def_row[1], def_row[2], def_row[3]`) with no semantic meaning
  - **Missing data structures**: Raw arrays/tuples used where `NamedTuple`, `dataclass`, or structured arrays would improve readability
  - **Type hint issues** and poor type inference patterns (especially in `simulate.py`)
  - **Hardcoded constants** scattered throughout modules
  - **Code organization**: Large files that could benefit from modular decomposition
- **Impact**:
  - Severely reduced maintainability and readability
  - High cognitive load for contributors to understand array semantics
  - Bugs from incorrect index access are easy to introduce and hard to catch
  - Type checker struggles with untyped array slicing
- **Proposed Solution**:
  - **Phase 1: Data Structure Audit**
    - Identify all magic-index patterns across the codebase
    - Define proper `NamedTuple` or `@dataclass` structures for each
    - Create `types.py` definitions where missing
  - **Phase 2: Comment Cleanup**
    - Remove comments that explain "what" when proper naming would suffice
    - Keep comments that explain "why" for non-obvious decisions
    - Replace inline explanatory comments with proper abstractions
  - **Phase 3: Module-Specific Refactoring**
    - `simulate.py`: Type hints, constants extraction, modular decomposition
    - `physics/virtual_sites.py`: Replace index-based access with named structures
    - `physics/settle.py`: Similar cleanup
    - `physics/pme.py`: Review TODOs and logic validation
  - **Phase 4: Type Hint Modernization**
    - Apply `jaxtyping` throughout
    - Consolidate type definitions
    - Enable `ty` checking (currently excluded)
- **Priority**: High
- **Related**:
  - [prolix/src/prolix/simulate.py](../prolix/src/prolix/simulate.py) (excluded from ty check)
  - [prolix/src/prolix/physics/](../prolix/src/prolix/physics/)
  - [prompts/reuse/maintenance/type_checking.md](prompts/reuse/maintenance/type_checking.md)
  - [prompts/reuse/maintenance/docstring_audit.md](prompts/reuse/maintenance/docstring_audit.md)

## Reference Documentation System

- **Issue**: No centralized location for tracking external reference documents, best practices guides, and technical resources that inform development decisions
- **Impact**: Reference materials are scattered across conversations, browser bookmarks, and ad-hoc notes; difficult to maintain institutional knowledge
- **Proposed Solution**:
  - Create `.agents/references/` directory structure
  - Develop a reference document template for capturing external resources with context
  - Update README.md to document the references system
  - Migrate existing reference materials (e.g., pytest speedup guide)
- **Priority**: Medium
- **Related**: [README.md](README.md), [templates/](templates/)

## Pytest Optimization

- **Issue**: Test suites run sequentially on a single CPU core, wasting available parallelization opportunities; no standardized pytest best practices across repositories
- **Impact**: Slow test execution times locally and in CI; inefficient use of multi-core hardware; longer feedback loops during development
- **Proposed Solution**:
  - Implement `pytest-xdist` for parallel test execution across all repositories
  - Apply best practices from [awesome-pytest-speedup](https://github.com/zupo/awesome-pytest-speedup):
    - Enable `PYTHONDONTWRITEBYTECODE=1`
    - Optimize collection speed
    - Disable unnecessary built-in plugins
    - Profile with `pytest --durations` to identify slow tests
    - Consider `pytest-split` for CI parallelization
  - Document pytest configuration standards in `codestyles/python.md`
  - Add pytest configuration to `.agents/templates/` for new projects
- **Priority**: Medium
- **Related**: CI workflows, [codestyles/python.md](codestyles/python.md), <https://github.com/zupo/awesome-pytest-speedup>

## Markdown Linting Standards

- **Issue**: Inconsistent markdown formatting across `.agents` documentation, templates, and repository READMEs causes readability issues and linting warnings
- **Impact**: Reduced readability of project documentation; lack of standardized formatting for tables, headers, and lists
- **Proposed Solution**:
  - Adopt GFM (GitHub Flavored Markdown) standards
  - Fix existing lint issues in `.agents` archive and templates
  - Add `markdownlint` to pre-commit hooks or CI workflows
  - Standardize table formatting (alignment syntax)
- **Priority**: Low
- **Related**: [.agents/templates/](.agents/templates/), Repository READMEs

## Type Ignore Usage Audit

- **Issue**: Widespread use of `# type: ignore` bypasses type safety checks and potentially masks real bugs
- **Impact**: Reduced confidence in type checker results, potential runtime errors, inaccurate IDE autocompletion
- **Proposed Solution**:
  - Audit all `# type: ignore` occurrences across repositories
  - Replace blanket ignores with specific error codes (e.g., `# type: ignore[attr-defined]`)
  - Fix underlying type issues where possible (using `cast`, assertions, or proper type definitions)
  - Document instances where ignores are unavoidable
- **Priority**: Medium
- **Related**: [prompts/reuse/maintenance/type_checking.md](prompts/reuse/maintenance/type_checking.md)

---

## Recently Migrated (2026-01-07)

The following items were migrated to formal tracking:

| Item | Backlog |
|:-----|:--------|
| Noising Integration | [noising_integration.md](backlog/noising_integration.md) |
| Mixed Precision for TREX | [mixed_precision_trex.md](backlog/mixed_precision_trex.md) |
| Type Hint Modernization | [type_hint_modernization.md](backlog/type_hint_modernization.md) |
| Docstring Standardization | [docstring_standardization.md](backlog/docstring_standardization.md) |
| JAX Recompilation Audit | [jax_recompilation_audit.md](backlog/jax_recompilation_audit.md) |
| JAX Dependency Management | [jax_dependency_management.md](backlog/jax_dependency_management.md) |
| Proxide Monorepo | [proxide_monorepo.md](backlog/proxide_monorepo.md) |
| Pre-commit Hooks | [precommit_hooks.md](backlog/precommit_hooks.md) |
| Health Audits (5 repos) | See [DEVELOPMENT_MATRIX.md](DEVELOPMENT_MATRIX.md#ongoing-maintenance) |

*Previously tracked items (Unify NK/Potts, JAX Scatter Warning) already in matrix.*
