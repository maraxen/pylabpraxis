make proxide and oxidize a monorepo with only proxide

asr
    dashboard hover tooltips on things like accuracy (the exact metric being used)

    why is parameter sweep so slow... need to make sure recompilations are not triggered inside any kind of loop/minimize potential recomps. we could make n_leaves and n_states dynamic if we keep a static max size and just use masking
