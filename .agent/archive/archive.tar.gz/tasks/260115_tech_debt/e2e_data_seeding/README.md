# E2E Data Seeding Fix

**Status**: 🔵 Inspecting
**Priority**: P2
**Difficulty**: Medium

---

## Issue

Chart validation tests (`medium-priority-capture.spec.ts`) fail because the mock database is not reliably seeded with protocol runs when `resetdb=true` is used. This prevents the "Capture Charts" test from finding protocol cards to execute.

**Impact**: Cannot automatically validate charts/visualizations in E2E pipeline.

---

## Phase 1: Inspection

- [ ] Trace `SqliteService.seedDefaultRuns()` logic
- [ ] Check if `generate_browser_db.py` creates protocol runs
- [ ] Verify IndexedDB seeding path in browser mode

---

## Files to Investigate

- `praxis/web-client/src/app/core/services/sqlite.service.ts`
- `scripts/generate_browser_db.py`
- `praxis/web-client/e2e/specs/medium-priority-capture.spec.ts`

---

## Related

- TECHNICAL_DEBT.md (E2E Testing section)
