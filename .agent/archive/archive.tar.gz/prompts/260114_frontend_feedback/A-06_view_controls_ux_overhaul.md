# Agent Prompt: View Controls UX Overhaul - Compact Horizontal Filter Bar

Examine `.agents/README.md` for development context.

**Status:** 🟢 Not Started
**Priority:** P1
**Batch:** [260114_frontend_feedback](./README.md)
**Difficulty:** 🔴 Complex
**Type:** 🟢 Implementation
**Dependencies:** A-01 (Shared View Controls), A-05 (FilterChip Deprecation)
**Backlog Reference:** Group A - View Controls Standardization

---

## 1. The Task

Redesign `ViewControlsComponent` from a **vertical stacked dropdown layout** to a **compact horizontal filter bar** with active filter chips, URL state synchronization, and mobile bottom sheet support.

### User Feedback

> "The view controls interface could be greatly improved in terms of UX. Following modern best practices for filtering and browsing databases."

### Problem Statement

Current issues identified:

| Issue | Impact |
|:------|:-------|
| **Vertical stacking consumes ~200px** of screen space before content is visible | 🔴 High |
| **No visibility of active filters** at a glance | 🔴 High |
| **"None" placeholder clutter** below each dropdown | 🟡 Medium |
| **No URL state sync** - can't share filtered views with colleagues | 🔴 High |
| **No result count feedback** | 🟡 Medium |

### Goals

1. **Compact Horizontal Layout**: Single row with `+ Add Filter` button and inline filter chips
2. **Preserve Existing Controls**: Keep View Type Toggle (card/list/table), Group By, and Sort controls fully functional
3. **Active Filter Chips**: Show applied filters as removable chips below the bar
4. **URL Synchronization**: All state (filters, view type, group by, sort) syncs to URL query params
5. **Result Count**: Display matching item count (e.g., "24 machines")
6. **Mobile Bottom Sheet**: On mobile, collapse all filters into a "Filters (3)" button that opens a bottom sheet
7. **Multi-select Behavior**: Popovers don't auto-close on selection (checkbox toggle pattern)

---

## 2. Technical Implementation Strategy

### Architecture Overview

```mermaid
graph TD
    subgraph ViewControlsComponent
        HB[Horizontal Bar]
        FC[Filter Chips Row]
        BS[BottomSheet - Mobile]
    end
    
    subgraph New Subcomponents
        AFP[AddFilterPopoverComponent]
        AFC[ActiveFilterChipComponent]
    end
    
    subgraph Existing Components
        PS[PraxisSelectComponent]
        PM[PraxisMultiselectComponent]
    end
    
    HB --> AFP
    FC --> AFC
    AFP --> PM
    BS --> PM
```

### Phase 1: Update Type Definitions

**File:** `view-controls.types.ts`

Add new interfaces to support the chip architecture and URL sync:

```typescript
export interface FilterConfig {
  key: string;
  label: string;
  type: 'multiselect' | 'select' | 'toggle';
  options?: FilterOption[];
  icon?: string;           // NEW: Icon for the filter chip
  pinned?: boolean;        // NEW: If true, show inline in bar (not in "+ Add Filter")
  urlParam?: string;       // NEW: Override URL param name (defaults to key)
}

export interface ActiveFilter {
  filterId: string;
  label: string;
  values: unknown[];
  displayText: string;     // e.g., "Status: Online, Idle"
}

export interface ViewControlsConfig {
  // ... existing fields ...
  enableUrlSync?: boolean;          // NEW: Sync state to URL query params
  urlParamPrefix?: string;          // NEW: Prefix for URL params (e.g., "filter_")
  showResultCount?: boolean;        // NEW: Display matching item count
  collapseMobileAt?: number;        // NEW: Breakpoint for mobile collapse (default: 768)
}

export interface ViewControlsState {
  // ... existing fields ...
  resultCount?: number;             // NEW: Current matching item count
}
```

### Phase 2: Refactor ViewControlsComponent Template

**File:** `view-controls.component.ts`

Replace current vertical layout with horizontal bar:

```html
<div class="view-controls-container">
  <!-- Row 1: Search + Actions -->
  <div class="controls-row-primary">
    <!-- Search -->
    <div class="search-wrapper">...</div>
    
    <!-- View Type Toggle -->
    <app-view-type-toggle ...></app-view-type-toggle>
    
    <!-- Group By -->
    <app-group-by-select ...></app-group-by-select>
    
    <!-- Pinned Filters (Status, Category) -->
    @for (filter of pinnedFilters; track filter.key) {
      <app-praxis-multiselect
        [label]="filter.label"
        [options]="filter.options"
        [value]="state.filters[filter.key]"
        (valueChange)="onFilterChange(filter.key, $event)"
      ></app-praxis-multiselect>
    }
    
    <!-- + Add Filter Button (opens popover with remaining filters) -->
    @if (unpinnedFilters.length > 0) {
      <button mat-stroked-button [matMenuTriggerFor]="filterMenu" class="add-filter-btn">
        <mat-icon>add</mat-icon>
        Add Filter
      </button>
      <mat-menu #filterMenu="matMenu" class="filter-popover-menu">
        @for (filter of unpinnedFilters; track filter.key) {
          <div class="filter-menu-item" (click)="$event.stopPropagation()">
            <span class="filter-label">{{ filter.label }}</span>
            <app-praxis-multiselect
              [options]="filter.options"
              [value]="state.filters[filter.key]"
              (valueChange)="onFilterChange(filter.key, $event)"
            ></app-praxis-multiselect>
          </div>
        }
      </mat-menu>
    }
    
    <!-- Sort -->
    <div class="sort-controls">...</div>
    
    <!-- Result Count -->
    @if (config.showResultCount && state.resultCount !== undefined) {
      <span class="result-count">{{ state.resultCount }} items</span>
    }
  </div>
  
  <!-- Row 2: Active Filter Chips (only when filters are active) -->
  @if (activeFilters.length > 0) {
    <div class="active-filters-row">
      <span class="active-label">Active:</span>
      @for (filter of activeFilters; track filter.filterId) {
        <span class="filter-chip">
          {{ filter.displayText }}
          <mat-icon class="chip-remove" (click)="removeFilter(filter.filterId)">close</mat-icon>
        </span>
      }
      <button mat-button class="clear-all-link" (click)="clearAll()">Clear all</button>
    </div>
  }
</div>
```

### Phase 3: URL State Synchronization

**New File:** `view-controls-url.service.ts` (or integrate into component)

```typescript
@Injectable()
export class ViewControlsUrlService {
  constructor(private router: Router, private route: ActivatedRoute) {}
  
  // Read filter state from URL on init
  readFromUrl(config: ViewControlsConfig): Partial<ViewControlsState> {
    const params = this.route.snapshot.queryParams;
    const filters: Record<string, unknown[]> = {};
    
    config.filters?.forEach(f => {
      const paramName = f.urlParam || f.key;
      const value = params[paramName];
      if (value) {
        filters[f.key] = Array.isArray(value) ? value : value.split(',');
      }
    });
    
    return {
      filters,
      search: params['q'] || '',
      groupBy: params['groupBy'] || null,
      sortBy: params['sortBy'] || '',
      sortOrder: params['sortOrder'] as 'asc' | 'desc' || 'asc',
    };
  }
  
  // Sync state changes to URL
  syncToUrl(state: ViewControlsState, config: ViewControlsConfig): void {
    const queryParams: Record<string, string | null> = {};
    
    // Flatten filters to URL params
    config.filters?.forEach(f => {
      const paramName = f.urlParam || f.key;
      const values = state.filters[f.key];
      queryParams[paramName] = values?.length ? values.join(',') : null;
    });
    
    if (state.search) queryParams['q'] = state.search;
    if (state.groupBy) queryParams['groupBy'] = state.groupBy;
    if (state.sortBy) queryParams['sortBy'] = state.sortBy;
    if (state.sortOrder !== 'asc') queryParams['sortOrder'] = state.sortOrder;
    
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams,
      queryParamsHandling: 'merge',
      replaceUrl: true
    });
  }
}
```

### Phase 4: Mobile Bottom Sheet

**New File:** `view-controls-mobile-sheet.component.ts`

```typescript
@Component({
  selector: 'app-view-controls-mobile-sheet',
  template: `
    <div class="mobile-filter-sheet">
      <div class="sheet-header">
        <h3>Filters</h3>
        <button mat-icon-button (click)="close()">
          <mat-icon>close</mat-icon>
        </button>
      </div>
      
      <div class="sheet-content">
        @for (filter of filters; track filter.key) {
          <div class="filter-section">
            <label>{{ filter.label }}</label>
            <app-praxis-multiselect
              [options]="filter.options"
              [value]="state.filters[filter.key]"
              (valueChange)="onFilterChange(filter.key, $event)"
            ></app-praxis-multiselect>
          </div>
        }
      </div>
      
      <div class="sheet-footer">
        <button mat-button (click)="clearAll()">Reset</button>
        <button mat-flat-button color="primary" (click)="apply()">
          Apply ({{ resultCount }})
        </button>
      </div>
    </div>
  `
})
export class ViewControlsMobileSheetComponent { ... }
```

### Phase 5: Computed Properties for Filter Organization

In `ViewControlsComponent`:

```typescript
// Filters pinned to the bar (always visible)
get pinnedFilters(): FilterConfig[] {
  return this.config.filters?.filter(f => f.pinned) || [];
}

// Filters in the "+ Add Filter" menu
get unpinnedFilters(): FilterConfig[] {
  return this.config.filters?.filter(f => !f.pinned) || [];
}

// Active filters for chip display
get activeFilters(): ActiveFilter[] {
  const result: ActiveFilter[] = [];
  
  for (const [key, values] of Object.entries(this.state.filters)) {
    if (!values || (Array.isArray(values) && values.length === 0)) continue;
    
    const config = this.config.filters?.find(f => f.key === key);
    if (!config) continue;
    
    const displayValues = (Array.isArray(values) ? values : [values])
      .map(v => config.options?.find(o => o.value === v)?.label || String(v))
      .join(', ');
    
    result.push({
      filterId: key,
      label: config.label,
      values: Array.isArray(values) ? values : [values],
      displayText: `${config.label}: ${displayValues}`
    });
  }
  
  return result;
}
```

---

## 3. Context & References

**Primary Files to Modify:**

| Path | Description |
|:-----|:------------|
| `praxis/web-client/src/app/shared/components/view-controls/view-controls.component.ts` | Main component refactor (503 lines) |
| `praxis/web-client/src/app/shared/components/view-controls/view-controls.types.ts` | Add new interfaces (57 lines) |
| `praxis/web-client/src/app/shared/components/view-controls/view-controls.component.spec.ts` | Update tests (109 lines) |

**Files to Create:**

| Path | Description |
|:-----|:------------|
| `praxis/web-client/src/app/shared/components/view-controls/view-controls-mobile-sheet.component.ts` | Mobile bottom sheet |

**Reference Files (Read-Only):**

| Path | Description |
|:-----|:------------|
| `praxis/web-client/src/app/shared/components/praxis-select/praxis-select.component.ts` | Select pattern (152 lines) |
| `praxis/web-client/src/app/shared/components/praxis-multiselect/praxis-multiselect.component.ts` | Multiselect pattern (198 lines) |
| `praxis/web-client/src/app/features/assets/assets.component.ts` | URL query param pattern (lines 229-248, 282-288) |
| `praxis/web-client/src/app/features/assets/components/machine-list/machine-list.component.ts` | Consumer of ViewControls |

**Related Prompts:**

| Prompt | Relationship |
|:-------|:-------------|
| `A-01_shared_view_controls.md` | Original component creation |
| `A-05_deprecate_filter_chips.md` | Deprecated FilterChip in favor of PraxisSelect/Multiselect |

---

## 4. Constraints & Conventions

- **Commands**: Use `npm` for Angular tasks.
- **Frontend Path**: `praxis/web-client`
- **Styling**: Use existing design tokens from `styles/themes/`. Create new CSS in component styles.
- **State**: Use Angular Signals for reactive state (existing pattern).
- **URL Sync**: Use `Router.navigate()` with `queryParamsHandling: 'merge'` and `replaceUrl: true`.
- **Mobile**: Use `MatBottomSheet` from `@angular/material/bottom-sheet` (new import).
- **Testing**: Tests use `vitest` - see existing spec file.

### Sharp Bits / Known Complexities

1. **URL ↔ State Race Condition**: On init, read URL → set state → don't immediately sync back to URL (infinite loop prevention)
2. **Multiselect Popover Behavior**: MatSelect doesn't auto-close on selection (this is already the behavior), but the "+ Add Filter" MatMenu will close. Need to use `MenuPositionX` and `(click)="$event.stopPropagation()"` to keep it open.
3. **Mobile Detection**: Use `BreakpointObserver` from `@angular/cdk/layout` for responsive behavior.
4. **Filter Config Migration**: Existing consumers specify `type: 'multiselect'` but no `pinned: true`. Default to pinning first 2 filters for MVP.

---

## 5. Verification Plan

**Definition of Done:**

1. Filters display in horizontal bar layout (not stacked vertically)
2. **View Type Toggle** (card/list/table) works and persists selection
3. **Group By** dropdown works and syncs to URL (`?groupBy=status`)
4. **Sort By** dropdown + direction toggle work and sync to URL (`?sortBy=name&sortOrder=desc`)
5. Active filters appear as removable chips below the bar
6. Filter state syncs to URL (copy URL → paste → same filters applied)
7. Mobile view shows "Filters (N)" button that opens bottom sheet
8. All existing tests pass

**Test Commands:**

```bash
cd praxis/web-client
npx tsc --noEmit
npm run build
npm run test -- --include='**/view-controls/**'
```

**Manual Verification:**

1. Navigate to `http://localhost:4200/app/assets?type=machine`
2. Apply Status filter → verify chip appears below bar
3. Apply Category filter → verify URL updates (e.g., `?type=machine&status=online&category=pipette`)
4. Copy URL → open in new tab → verify same filters are applied
5. Resize browser to mobile width (<768px) → verify "Filters" button appears
6. Click "Filters" button → verify bottom sheet opens with all filters
7. Clear filters → verify URL params are removed

---

## On Completion

- [ ] Commit changes with message: `feat(view-controls): horizontal filter bar with URL sync and mobile bottom sheet`
- [ ] Update `A-01_shared_view_controls.md` to reference new architecture
- [ ] Update `GROUP_A_view_controls_init.md` with completion status
- [ ] Mark this prompt complete in batch README
- [ ] Set status in this document to 🟢 Completed

---

## References

- `.agents/README.md` - Environment overview
- `.agents/codestyles/typescript.md` - TypeScript conventions
- `GROUP_A_view_controls_init.md` - Parent initiative
- [Linear Filtering UX](https://linear.app) - Design inspiration
- [GitHub Issues Filter](https://github.com) - Chip pattern reference
