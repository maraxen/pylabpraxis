# Agent Prompt: Migrate Resource + ResourceDefinition to SQLModel

Examine `.agents/README.md` for development context.

**Status:** 🟢 Not Started
**Priority:** P2
**Batch:** [260110](./README.md)
**Backlog Reference:** [sqlmodel_codegen_refactor.md](../../backlog/sqlmodel_codegen_refactor.md)
**Phase:** 2.3 — Model Migration: Resource
**Parallelizable:** ⚠️ Can run in parallel with P2_04 (Machine) after P2_03 (Asset) completes

---

## 1. The Task

Unify `Resource` and `ResourceDefinition` models from separate ORM and Pydantic definitions into SQLModel domain models. `Resource` inherits polymorphically from `Asset`.

**User Value:** Single source of truth for Resource schema (plates, tips, labware) with automatic API type generation.

---

## 2. Technical Implementation Strategy

### Current Architecture

**ORM** (`praxis/backend/models/orm/resource.py`):
- `ResourceOrm(AssetOrm)` — Polymorphic child of Asset
- `ResourceDefinitionOrm(PLRTypeDefinitionOrm)` — Catalog of resource types

**Key ResourceOrm Fields:**
- Inherits: `asset_type`, `name`, `fqn`, `location`, `plr_state`, `plr_definition`
- Own: `status`, `resource_definition_accession_id`, `deck_accession_id`, `deck_position_name`
- JSON: `properties_json`, `dimensions_json`
- Consumable tracking: `quantity`, `current_volume_ul`, `max_volume_ul`

**Key ResourceDefinitionOrm Fields:**
- `resource_type`, `is_consumable`, `nominal_volume_ul`
- `manufacturer`, `material`, `ordering`
- Dimensions: `size_x_mm`, `size_y_mm`, `size_z_mm`
- JSON: `plr_definition_details_json`

**Pydantic** (`praxis/backend/models/pydantic_internals/resource.py`):
- `ResourceBase`, `ResourceCreate`, `ResourceResponse`, `ResourceUpdate`
- `ResourceDefinitionBase`, `ResourceDefinitionCreate`, `ResourceDefinitionResponse`, `ResourceDefinitionUpdate`
- Helper models: `ResourceCategoriesResponse`, `ResourceTypeInfo`, `ResourceInventoryDataIn/Out`

### Target Architecture

Create `praxis/backend/models/domain/resource.py`:

```python
from praxis.backend.models.domain.asset import Asset
from praxis.backend.models.enums import AssetType, ResourceStatusEnum

class ResourceBase(AssetBase):
    """Shared fields for Resource CRUD schemas."""
    status: ResourceStatusEnum = Field(default=ResourceStatusEnum.AVAILABLE)
    resource_definition_accession_id: uuid.UUID | None = None
    deck_accession_id: uuid.UUID | None = None
    deck_position_name: str | None = None

class Resource(Asset, table=True):
    """Resource ORM - polymorphic child of Asset."""
    status: ResourceStatusEnum = Field(...)
    resource_definition_accession_id: uuid.UUID | None = Field(
        default=None,
        foreign_key="resource_definition_catalog.accession_id",
    )
    # Consumable tracking
    quantity: int | None = Field(default=None)
    current_volume_ul: float | None = Field(default=None)
    max_volume_ul: float | None = Field(default=None)
    
    # JSON fields
    dimensions_json: dict[str, Any] | None = json_field(default=None)
    
    __mapper_args__: ClassVar[dict] = {
        "polymorphic_identity": AssetType.RESOURCE,
    }
```

---

## 3. Context & References

**Primary Files to Create:**

| Path | Description |
|:-----|:------------|
| `praxis/backend/models/domain/resource.py` | Unified Resource + ResourceDefinition SQLModel |

**Primary Files to Modify:**

| Path | Description |
|:-----|:------------|
| `praxis/backend/models/domain/__init__.py` | Export Resource models |

**Files to Deprecate (Do NOT delete yet):**

| Path | Description |
|:-----|:------------|
| `praxis/backend/models/orm/resource.py` | Legacy ORM (432 lines) |
| `praxis/backend/models/pydantic_internals/resource.py` | Legacy Pydantic |

**Reference Files (Read-Only):**

| Path | Pattern Source |
|:-----|:---------------|
| `praxis/backend/models/orm/resource.py` | Full ORM definition |
| `praxis/backend/models/pydantic_internals/resource.py` | Pydantic schemas |
| `praxis/backend/models/enums/resource.py` | `ResourceStatusEnum` |
| `praxis/backend/api/resources.py` | API router |
| `tests/models/test_orm/test_resource_orm.py` | ORM tests |
| `tests/models/test_orm/test_resource_definition_orm.py` | Definition tests |
| `tests/models/test_pydantic/test_resource_pydantic.py` | Pydantic tests |

---

## 4. Constraints & Conventions

- **Commands**: Use `uv run` for Python commands.
- **Backend Path**: `praxis/backend`
- **JSON fields**: `properties_json`, `dimensions_json` use `json_field()` helper
- **Consumable logic**: Preserve `quantity`, `current_volume_ul`, `max_volume_ul` semantics

### Sharp Bits / Technical Debt

1. **Complex relationships**: Resource links to Deck, DeckPosition, MachineDefinition, etc.
2. **Helper models**: `ResourceInventoryDataIn/Out`, `ResourceTypeInfo` may need special handling
3. **Enum values**: `ResourceStatusEnum` must match database values exactly

---

## 5. Verification Plan

**Definition of Done:**

1. Domain model imports successfully:
   ```bash
   uv run python -c "from praxis.backend.models.domain.resource import Resource, ResourceDefinition, ResourceCreate, ResourceRead; print('OK')"
   ```

2. Polymorphic inheritance works:
   ```bash
   uv run python -c "
   from sqlmodel import SQLModel, create_engine, Session
   from praxis.backend.models.domain.asset import Asset
   from praxis.backend.models.domain.resource import Resource
   from praxis.backend.models.enums import AssetType
   
   engine = create_engine('sqlite:///:memory:')
   SQLModel.metadata.create_all(engine)
   
   with Session(engine) as s:
       r = Resource(name='plate_1', fqn='plates.Corning96Well')
       s.add(r)
       s.commit()
       assert r.asset_type == AssetType.RESOURCE
       print(f'Resource created with asset_type={r.asset_type}')
   "
   ```

3. Existing tests still pass:
   ```bash
   uv run pytest tests/models/test_orm/test_resource_orm.py tests/models/test_orm/test_resource_definition_orm.py -x -q
   uv run pytest tests/models/test_pydantic/test_resource_pydantic.py tests/models/test_pydantic/test_resource_definition_pydantic.py -x -q
   ```

4. New domain tests pass:
   ```bash
   uv run pytest tests/models/test_domain/test_resource_sqlmodel.py -v
   ```

---

## 6. Implementation Steps

1. **Audit ResourceOrm fields** (all fields from 432-line file):
   - Status, foreign keys, consumable tracking, JSON fields
   - Relationships to Deck, ResourceDefinition, MachineDefinition

2. **Audit ResourceDefinitionOrm fields**:
   - Catalog fields, dimensions, PLR definition details

3. **Create domain/resource.py**:
   - Import `Asset` from domain.asset
   - Import enums

4. **Implement ResourceDefinitionBase + ResourceDefinition(table=True)**:
   - `__tablename__ = "resource_definition_catalog"`
   - All catalog fields

5. **Implement ResourceBase + Resource(Asset, table=True)**:
   - Polymorphic identity for `RESOURCE`
   - All Resource-specific fields
   - Consumable tracking fields

6. **Implement CRUD schemas**:
   - `ResourceCreate`, `ResourceRead`, `ResourceUpdate`
   - `ResourceDefinitionCreate`, `ResourceDefinitionRead`, `ResourceDefinitionUpdate`

7. **Handle helper models**:
   - Decide if `ResourceInventoryDataIn/Out` stay as plain Pydantic or become SQLModel

8. **Export from domain/__init__.py**

9. **Create test file**:
   - `tests/models/test_domain/test_resource_sqlmodel.py`

---

## 7. Field Mapping Reference

### Resource Fields (from ORM)

| ORM Field | SQLModel Field | Notes |
|:----------|:---------------|:------|
| `status` | `status: ResourceStatusEnum` | Default AVAILABLE |
| `resource_definition_accession_id` | FK to `resource_definition_catalog` | |
| `deck_accession_id` | FK to `decks` | Nullable |
| `deck_position_name` | `str \| None` | Position on deck |
| `quantity` | `int \| None` | For consumables |
| `current_volume_ul` | `float \| None` | Current fill level |
| `max_volume_ul` | `float \| None` | Capacity |
| `dimensions_json` | `json_field()` | PLR dimensions |
| ... | ... | Complete from ORM |

### ResourceDefinition Fields (from ORM)

| ORM Field | SQLModel Field | Notes |
|:----------|:---------------|:------|
| `resource_type` | `str \| None` | Human-readable type |
| `is_consumable` | `bool` | Default False |
| `nominal_volume_ul` | `float \| None` | |
| `manufacturer` | `str \| None` | |
| `material` | `str \| None` | |
| `ordering` | `str \| None` | Ordering info |
| `size_x_mm`, `size_y_mm`, `size_z_mm` | `float \| None` | |
| `plr_definition_details_json` | `json_field()` | |
| ... | ... | Complete from ORM |

---

## On Completion

- [ ] Commit changes with message: `feat(models): migrate Resource + ResourceDefinition to SQLModel`
- [ ] Update backlog item status in `sqlmodel_codegen_refactor.md` (Phase 2.3 → Done)
- [ ] Mark this prompt complete in batch README

---

## References

- `.agents/README.md` - Environment overview
- `.agents/backlog/sqlmodel_codegen_refactor.md` - Full migration plan
- `P2_03_migrate_asset_base.md` - Asset base migration (prerequisite)
