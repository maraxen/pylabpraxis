# Playground Issues

## 📁 Archived Items

See: [ui_ux_improvements_jan_2026.md](../archive/ui_ux_improvements_jan_2026.md)

- P1: Initialization Flow Broken
- P2: Inventory Filter Styling
- P2: Category Structure

---

## P2: WebUSB/Polyfill Audit

**Status**: Resolved
**Difficulty**: Hard

### Problem

Need to audit the polyfill/webusb based communication to ensure it works correctly.

### Context

- Various polyfills are used for hardware communication
- Unclear if all paths are correctly implemented

### Tasks

- [x] Document current polyfill implementation
- [x] Audit WebUSB communication paths
- [x] Test with simulated and real hardware
- [x] Document any limitations

---

---

---

## P2: Resource Filters Broken

**Status**: Resolved
**Difficulty**: Medium

### Problem

In asset selection and resource filtering, none of the filters are working and they look different from filters in other tabs.

### Tasks

- [x] Investigate filter binding issues
- [x] Align styling with other filter components
- [x] Test all filter combinations

---

## P2: Browser Tab Categories Blank

**Status**: Resolved
**Difficulty**: Medium

### Problem

For the browser add tab in playground inventory, once you go to categories it shows a blank area.

### Tasks

- [x] Debug category view rendering
- [x] Check data binding for category list
- [x] Verify component initialization
