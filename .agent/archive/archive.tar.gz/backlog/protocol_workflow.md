# Protocol Workflow Issues

## 📁 Archived Items

See: [ui_ux_improvements_jan_2026.md](../archive/ui_ux_improvements_jan_2026.md)

- P1: Well Selection Not Triggering
- P2: Protocol Dialog Asset Classification

---

## P1: Asset Filtering Not Working

**Status**: Resolved
**Difficulty**: Medium

### Problem

Autofill and asset selection is not filtered to the appropriate PyLabRobot class.

### Context

- When selecting assets for protocol execution, incompatible resources may appear
- Filter should respect PLR class hierarchy

### Tasks

- [x] Review asset selection logic in protocol workflow
- [x] Verify PLR class filtering in `AssetManager` or `ProtocolService`
- [x] Ensure type compatibility checks are applied

---

## P2: Protocol Description Formatting

**Status**: Resolved
**Difficulty**: Easy

### Problem

Spacing and formatting of protocol description could be improved.

### Tasks

- [x] Review protocol description display component
- [x] Improve typography and spacing
- [x] Ensure consistent styling with rest of UI

---

## P2: Protocol Library Filters

**Status**: Resolved
**Difficulty**: Medium

### Problem

No filters are implemented in the protocol library.

### Tasks

- [x] Implement filter chips for protocol library
- [x] Filter by: author, tags, resource requirements
- [x] Search functionality for protocol names
