# Data Visualization Issues

**Created**: 2026-01-09
**Priority**: P2

---

## P2: Dashboard Not Responding to Selects

**Status**: Resolved
**Difficulty**: Medium

### Problem

The data visualization dashboard needs to actually respond to the selects we have for the x and y axis.

### Context

- Axis selectors are present in UI
- Changes to selectors don't update the visualization
- Likely a binding or subscription issue

### Tasks

- [x] Debug selector → chart data binding
- [x] Verify reactive subscription chain
- [x] Test with different data configurations
- [x] Add loading/error states for data fetching

---

## P2: Sample Data Seeding

**Status**: Resolved
**Difficulty**: Medium

### Problem

We should ship with some functional log well data outputs in the browser database proceeding from simulated runs.

### Context

- New users see empty visualizations
- Demo data helps users understand capabilities
- Simulated runs should produce viewable data

### Tasks

- [x] Define sample dataset structure
- [x] Create seed data from representative simulated runs
- [x] Include varied well data (volumes, concentrations, etc.)
- [x] Add to browser mode initialization
- [x] Document sample data in user guide
