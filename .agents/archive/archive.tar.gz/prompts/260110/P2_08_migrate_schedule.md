# Agent Prompt: Migrate Schedule + Reservation Entities to SQLModel

Examine `.agents/README.md` for development context.

**Status:** 🟢 Not Started
**Priority:** P2
**Batch:** [260110](./README.md)
**Backlog Reference:** [sqlmodel_codegen_refactor.md](../../backlog/sqlmodel_codegen_refactor.md)
**Phase:** 3.2 — Model Migration: Scheduling
**Parallelizable:** ⚠️ Can run in parallel with P2_07 (ProtocolRun) after Phase 2

---

## 1. The Task

Unify `Schedule`, `ScheduleEntry`, `ScheduleHistory`, and `AssetReservation` models from separate ORM and Pydantic definitions into SQLModel domain models. These models support protocol scheduling and asset reservation.

**User Value:** Single source of truth for scheduling system with automatic API type generation.

---

## 2. Technical Implementation Strategy

### Current Architecture

**ORM** (`praxis/backend/models/orm/schedule.py`):
- `ScheduleEntryOrm` — Scheduled protocol execution slot
- `ScheduleHistoryOrm` — History of schedule changes
- `AssetReservationOrm` — Asset reservations for scheduled runs
- `SchedulerMetricsView` — Materialized view for metrics

**Key Relationships:**
```
ScheduleEntryOrm (schedule slot)
    └── ProtocolRunOrm (actual execution)
    └── AssetReservationOrm[] (reserved assets)
    └── ScheduleHistoryOrm[] (change history)

AssetReservationOrm
    └── AssetOrm (the reserved asset)
    └── ScheduleEntryOrm (which schedule)
```

**Pydantic** (`praxis/backend/models/pydantic_internals/scheduler.py`):
- `ScheduleEntryResponse`, `ScheduleHistoryResponse`
- `ScheduleProtocolRequest`, `CancelScheduleRequest`
- `ScheduleListRequest`, `ScheduleListResponse`, `ScheduleListFilters`
- `ResourceReservationStatus`, `ScheduleStatusResponse`
- `SchedulerMetricsResponse`, `SchedulerSystemStatusResponse`
- `ScheduleAnalysisResponse`, `SchedulePriorityUpdateRequest`

---

## 3. Context & References

**Primary Files to Create:**

| Path | Description |
|:-----|:------------|
| `praxis/backend/models/domain/schedule.py` | Unified Schedule domain models |

**Primary Files to Modify:**

| Path | Description |
|:-----|:------------|
| `praxis/backend/models/domain/__init__.py` | Export Schedule models |

**Files to Deprecate (Do NOT delete yet):**

| Path | Description |
|:-----|:------------|
| `praxis/backend/models/orm/schedule.py` | Legacy ORM |
| `praxis/backend/models/pydantic_internals/scheduler.py` | Legacy Pydantic |

**Reference Files (Read-Only):**

| Path | Pattern Source |
|:-----|:---------------|
| `praxis/backend/models/orm/schedule.py` | Full ORM definition |
| `praxis/backend/models/pydantic_internals/scheduler.py` | Pydantic schemas |
| `praxis/backend/api/scheduler.py` | API router |
| `tests/models/test_orm/test_schedule_entry_orm.py` | Entry tests |
| `tests/models/test_orm/test_schedule_history_orm.py` | History tests |
| `tests/models/test_orm/test_asset_reservation_orm.py` | Reservation tests |
| `tests/api/test_scheduler_api.py` | API tests |
| `tests/factories_schedule.py` | Schedule test factories |

---

## 4. Constraints & Conventions

- **Commands**: Use `uv run` for Python commands.
- **Backend Path**: `praxis/backend`
- **AssetReservation relationship**: Links to unified `Asset` from Phase 2.1
- **Materialized View**: `SchedulerMetricsView` may need special handling (read-only)

### Sharp Bits / Technical Debt

1. **Materialized view**: `SchedulerMetricsView` is read-only, not a regular table
2. **DateTime handling**: Schedule entries have complex time windows
3. **Status enums**: Multiple status fields with different enum types
4. **Request/Response models**: Many Pydantic models are API-only (not tables)

---

## 5. Verification Plan

**Definition of Done:**

1. All schedule models import successfully:
   ```bash
   uv run python -c "
   from praxis.backend.models.domain.schedule import (
       ScheduleEntry, ScheduleHistory, AssetReservation,
       ScheduleEntryCreate, ScheduleEntryRead
   )
   print('OK')
   "
   ```

2. Asset reservation relationship works:
   ```bash
   uv run python -c "
   from sqlmodel import SQLModel, create_engine, Session
   from praxis.backend.models.domain.asset import Asset
   from praxis.backend.models.domain.schedule import ScheduleEntry, AssetReservation
   
   engine = create_engine('sqlite:///:memory:')
   SQLModel.metadata.create_all(engine)
   
   with Session(engine) as s:
       asset = Asset(name='machine_1', fqn='machines.Test')
       entry = ScheduleEntry(name='schedule_1')
       reservation = AssetReservation(
           name='res_1',
           asset=asset,
           schedule_entry=entry,
       )
       s.add_all([asset, entry, reservation])
       s.commit()
       print(f'AssetReservation links asset={asset.name} to entry={entry.name}')
   "
   ```

3. Existing tests still pass:
   ```bash
   uv run pytest tests/models/test_orm/test_schedule_entry_orm.py tests/models/test_orm/test_asset_reservation_orm.py -x -q
   uv run pytest tests/api/test_scheduler_api.py -x -q
   ```

4. New domain tests pass:
   ```bash
   uv run pytest tests/models/test_domain/test_schedule_sqlmodel.py -v
   ```

---

## 6. Implementation Steps

1. **Audit all schedule ORM models**:
   - ScheduleEntryOrm fields and relationships
   - ScheduleHistoryOrm for audit trail
   - AssetReservationOrm linking assets to schedules
   - SchedulerMetricsView (materialized view, special case)

2. **Create domain/schedule.py**:
   - Import base classes and enums
   - Import Asset for relationship

3. **Implement AssetReservation**:
   - Base + table model
   - FK to Asset (from domain.asset)
   - FK to ScheduleEntry
   - Time window fields

4. **Implement ScheduleEntry**:
   - Base + table model
   - FK to ProtocolRun
   - Relationship to reservations
   - Scheduling fields (priority, time windows)

5. **Implement ScheduleHistory**:
   - Base + table model
   - FK to ScheduleEntry
   - Change tracking fields

6. **Handle SchedulerMetricsView**:
   - Keep as read-only SQLAlchemy view definition
   - Or create Pydantic-only response model

7. **Implement request/response schemas**:
   - Keep API-only models as plain Pydantic (not table=True)
   - `ScheduleProtocolRequest`, `CancelScheduleRequest`, etc.

8. **Export from domain/__init__.py**

9. **Create test file**:
    - `tests/models/test_domain/test_schedule_sqlmodel.py`

---

## On Completion

- [ ] Commit changes with message: `feat(models): migrate Schedule + Reservation entities to SQLModel`
- [ ] Update backlog item status in `sqlmodel_codegen_refactor.md` (Phase 3.2 → Done)
- [ ] Mark this prompt complete in batch README

---

## References

- `.agents/README.md` - Environment overview
- `.agents/backlog/sqlmodel_codegen_refactor.md` - Full migration plan
- `P2_03_migrate_asset_base.md` - Asset base (AssetReservation references Asset)
