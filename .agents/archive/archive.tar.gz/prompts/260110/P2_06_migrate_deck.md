# Agent Prompt: Migrate Deck + DeckDefinition + DeckPositionDefinition to SQLModel

Examine `.agents/README.md` for development context.

**Status:** 🟢 Not Started
**Priority:** P2
**Batch:** [260110](./README.md)
**Backlog Reference:** [sqlmodel_codegen_refactor.md](../../backlog/sqlmodel_codegen_refactor.md)
**Phase:** 2.4 — Model Migration: Deck
**Parallelizable:** ⚠️ Can run after P2_03 (Asset), ideally after P2_04/P2_05 for consistency

---

## 1. The Task

Unify `Deck`, `DeckDefinition`, and `DeckPositionDefinition` models from separate ORM and Pydantic definitions into SQLModel domain models. These models represent the physical deck layout of liquid handlers.

**User Value:** Single source of truth for deck configuration with automatic API type generation.

---

## 2. Technical Implementation Strategy

### Current Architecture

**ORM** (`praxis/backend/models/orm/deck.py`):
- `DeckOrm(Base)` — Instance of a physical deck
- `DeckDefinitionOrm(PLRTypeDefinitionOrm)` — Catalog definition of deck types
- `DeckPositionDefinitionOrm(Base)` — Position slots on a deck definition

**Key Relationships:**
```
DeckDefinitionOrm (catalog)
    └── DeckPositionDefinitionOrm[] (positions like "A1", "B1")
    └── MachineDefinitionOrm (which machine uses this deck)

DeckOrm (instance)
    └── DeckDefinitionOrm (type reference)
    └── MachineOrm (which machine this deck belongs to)
    └── ResourceOrm[] (resources placed on this deck)
```

**Pydantic** (`praxis/backend/models/pydantic_internals/deck.py`):
- `DeckBase`, `DeckCreate`, `DeckResponse`, `DeckUpdate`
- `DeckTypeDefinitionCreate`, `DeckTypeDefinitionResponse`, `DeckTypeDefinitionUpdate`
- `DeckPositionDefinitionBase`, `DeckPositionDefinitionCreate`, `DeckPositionDefinitionResponse`
- `PositioningConfig` — Nested model for position configuration

### Target Architecture

Create `praxis/backend/models/domain/deck.py`:

```python
class DeckPositionDefinitionBase(PraxisBase):
    """Position slot on a deck definition."""
    position_name: str
    size_x_mm: float | None = None
    size_y_mm: float | None = None
    size_z_mm: float | None = None
    offset_x_mm: float | None = None
    offset_y_mm: float | None = None
    offset_z_mm: float | None = None

class DeckPositionDefinition(DeckPositionDefinitionBase, table=True):
    __tablename__ = "deck_position_definitions"
    deck_definition_accession_id: uuid.UUID = Field(
        foreign_key="deck_definition_catalog.accession_id",
    )
    deck_definition: "DeckDefinition" = Relationship(back_populates="positions")

class DeckDefinitionBase(PraxisBase):
    """Deck type definition (catalog)."""
    size_x_mm: float | None = None
    size_y_mm: float | None = None
    size_z_mm: float | None = None

class DeckDefinition(DeckDefinitionBase, table=True):
    __tablename__ = "deck_definition_catalog"
    positions: list[DeckPositionDefinition] = Relationship(
        back_populates="deck_definition",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    machine_definition: "MachineDefinition | None" = Relationship(...)

class Deck(PraxisBase, table=True):
    __tablename__ = "decks"
    deck_definition_accession_id: uuid.UUID | None = Field(...)
    machine_accession_id: uuid.UUID | None = Field(...)
    current_state_json: dict[str, Any] | None = json_field()
```

### Nested Relationships

DeckPositionDefinition is a child of DeckDefinition. When creating a DeckDefinition, positions should be creatable inline:

```python
class DeckDefinitionCreate(DeckDefinitionBase):
    positions: list[DeckPositionDefinitionCreate] = []
```

---

## 3. Context & References

**Primary Files to Create:**

| Path | Description |
|:-----|:------------|
| `praxis/backend/models/domain/deck.py` | Unified Deck models |

**Primary Files to Modify:**

| Path | Description |
|:-----|:------------|
| `praxis/backend/models/domain/__init__.py` | Export Deck models |

**Files to Deprecate (Do NOT delete yet):**

| Path | Description |
|:-----|:------------|
| `praxis/backend/models/orm/deck.py` | Legacy ORM |
| `praxis/backend/models/pydantic_internals/deck.py` | Legacy Pydantic |

**Reference Files (Read-Only):**

| Path | Pattern Source |
|:-----|:---------------|
| `praxis/backend/models/orm/deck.py` | Full ORM with relationships |
| `praxis/backend/models/pydantic_internals/deck.py` | Pydantic schemas |
| `praxis/backend/api/decks.py` | API router |
| `tests/models/test_orm/test_deck_orm.py` | ORM tests |
| `tests/models/test_pydantic/test_deck_pydantic.py` | Pydantic tests |
| `tests/api/test_decks.py` | API tests |

---

## 4. Constraints & Conventions

- **Commands**: Use `uv run` for Python commands.
- **Backend Path**: `praxis/backend`
- **Nested creation**: Support creating DeckDefinition with inline positions
- **Cascade deletes**: DeckPositionDefinitions cascade-delete with DeckDefinition

### Sharp Bits / Technical Debt

1. **Three related models**: Deck, DeckDefinition, DeckPositionDefinition all need migration
2. **Nested relationships**: Creating definition with positions requires careful SQLModel handling
3. **Bidirectional relationships**: Machine ↔ Deck, DeckDefinition ↔ DeckPositionDefinition
4. **PositioningConfig**: Nested Pydantic model for API only (not a table)

---

## 5. Verification Plan

**Definition of Done:**

1. All three models import successfully:
   ```bash
   uv run python -c "
   from praxis.backend.models.domain.deck import (
       Deck, DeckDefinition, DeckPositionDefinition,
       DeckCreate, DeckDefinitionCreate, DeckPositionDefinitionCreate
   )
   print('OK')
   "
   ```

2. Nested creation works:
   ```bash
   uv run python -c "
   from sqlmodel import SQLModel, create_engine, Session
   from praxis.backend.models.domain.deck import DeckDefinition, DeckPositionDefinition
   
   engine = create_engine('sqlite:///:memory:')
   SQLModel.metadata.create_all(engine)
   
   with Session(engine) as s:
       dd = DeckDefinition(
           name='test_deck_def',
           fqn='decks.TestDeck',
           size_x_mm=500,
       )
       pos = DeckPositionDefinition(
           name='A1',
           position_name='A1',
           deck_definition=dd,
       )
       s.add(dd)
       s.add(pos)
       s.commit()
       print(f'DeckDefinition created with {len(dd.positions)} positions')
   "
   ```

3. Existing tests still pass:
   ```bash
   uv run pytest tests/models/test_orm/test_deck_orm.py -x -q
   uv run pytest tests/models/test_pydantic/test_deck_pydantic.py -x -q
   uv run pytest tests/api/test_decks.py -x -q
   ```

4. New domain tests pass:
   ```bash
   uv run pytest tests/models/test_domain/test_deck_sqlmodel.py -v
   ```

---

## 6. Implementation Steps

1. **Audit all three ORM models**:
   - DeckOrm fields and relationships
   - DeckDefinitionOrm fields and relationships
   - DeckPositionDefinitionOrm fields and relationships

2. **Create domain/deck.py**:
   - Import base classes
   - Plan model order (positions first, then definition, then deck)

3. **Implement DeckPositionDefinition**:
   - Base + table model
   - FK to deck_definition
   - Position geometry fields

4. **Implement DeckDefinition**:
   - Base + table model
   - Relationship to positions (one-to-many)
   - Relationship to machine_definition

5. **Implement Deck**:
   - Base + table model
   - FKs to deck_definition, machine
   - State JSON field

6. **Implement all CRUD schemas**:
   - Create/Read/Update for each model
   - Support nested position creation in DeckDefinitionCreate

7. **Export from domain/__init__.py**

8. **Create test file**:
   - `tests/models/test_domain/test_deck_sqlmodel.py`
   - Test nested creation, cascades, serialization

---

## On Completion

- [ ] Commit changes with message: `feat(models): migrate Deck + DeckDefinition + DeckPositionDefinition to SQLModel`
- [ ] Update backlog item status in `sqlmodel_codegen_refactor.md` (Phase 2.4 → Done)
- [ ] Mark this prompt complete in batch README

---

## References

- `.agents/README.md` - Environment overview
- `.agents/backlog/sqlmodel_codegen_refactor.md` - Full migration plan
- `P2_03_migrate_asset_base.md` - Asset base migration
